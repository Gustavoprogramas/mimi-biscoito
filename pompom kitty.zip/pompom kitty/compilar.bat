@echo off
cd /d "%~dp0"
where javac >nul 2>nul
if not %errorlevel%==0 (
  echo Precisa de um JDK instalado - javac. Baixe em https://adoptium.net
  pause
  exit /b
)
if exist classes rmdir /s /q classes
mkdir classes
javac -encoding UTF-8 -d classes codigo-fonte\doce\*.java
if errorlevel 1 (
  echo Erro ao compilar!
  pause
  exit /b
)
echo Main-Class: doce.Main> manifest.txt
jar cfm MimiBiscoito.jar manifest.txt -C classes .
del manifest.txt
rmdir /s /q classes
echo Pronto! MimiBiscoito.jar atualizado.
pause

@echo off
cd /d "%~dp0"
set OPCOES=-Xms128m -XX:+UseG1GC -XX:MaxGCPauseMillis=4 -Dsun.java2d.d3d=true
where javaw >nul 2>nul
if %errorlevel%==0 (
  start "" javaw %OPCOES% -jar "MimiBiscoito.jar"
  exit /b
)
where java >nul 2>nul
if %errorlevel%==0 (
  java %OPCOES% -jar "MimiBiscoito.jar"
  exit /b
)
echo.
echo   Nao encontrei o Java neste computador :(
echo   Baixe e instale o Java (gratis) em: https://adoptium.net
echo   Depois e so abrir o Jogar.bat de novo.
echo.
pause

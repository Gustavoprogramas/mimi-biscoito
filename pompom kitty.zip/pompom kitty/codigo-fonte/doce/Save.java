package doce;

import java.io.*;
import java.util.Properties;

/** Progresso salvo em ~/.mimi_biscoito.properties */
public final class Save {
    private Save() {}

    public static int unlocked = 1;
    public static int[] best = new int[32];      // coracoes (0-3) por fase
    public static int[] bestTime = new int[32];  // em ticks, 0 = nunca
    public static boolean muted = false;
    public static String lastIp = "26.";
    public static int port = 7777;
    public static int fpsCap = 0;          // 0 = ilimitado
    public static boolean showFps = false;
    public static boolean smooth = true;   // desenho suave em alta resolucao

    private static File file() {
        return new File(System.getProperty("user.home"), ".mimi_biscoito.properties");
    }

    public static void load() {
        Properties p = new Properties();
        try (InputStream in = new FileInputStream(file())) {
            p.load(in);
            unlocked = Integer.parseInt(p.getProperty("unlocked", "1"));
            muted = Boolean.parseBoolean(p.getProperty("muted", "false"));
            lastIp = p.getProperty("lastIp", "26.");
            port = Integer.parseInt(p.getProperty("port", "7777"));
            fpsCap = Integer.parseInt(p.getProperty("fpsCap", "0"));
            showFps = Boolean.parseBoolean(p.getProperty("showFps", "false"));
            smooth = Boolean.parseBoolean(p.getProperty("smooth", "true"));
            for (int i = 0; i < best.length; i++) {
                best[i] = Integer.parseInt(p.getProperty("best" + i, "0"));
                bestTime[i] = Integer.parseInt(p.getProperty("time" + i, "0"));
            }
        } catch (Exception ignored) {
        }
        Sfx.muted = muted;
    }

    public static void store() {
        Properties p = new Properties();
        p.setProperty("unlocked", "" + unlocked);
        p.setProperty("muted", "" + muted);
        p.setProperty("lastIp", lastIp);
        p.setProperty("port", "" + port);
        p.setProperty("fpsCap", "" + fpsCap);
        p.setProperty("showFps", "" + showFps);
        p.setProperty("smooth", "" + smooth);
        for (int i = 0; i < best.length; i++) {
            p.setProperty("best" + i, "" + best[i]);
            p.setProperty("time" + i, "" + bestTime[i]);
        }
        try (OutputStream out = new FileOutputStream(file())) {
            p.store(out, "Mimi & Biscoito - progresso");
        } catch (Exception ignored) {
        }
    }

    public static void finished(int level, int hearts, int time) {
        best[level] = Math.max(best[level], hearts);
        if (bestTime[level] == 0 || time < bestTime[level]) bestTime[level] = time;
        unlocked = Math.max(unlocked, Math.min(Levels.count(), level + 2));
        store();
    }
}

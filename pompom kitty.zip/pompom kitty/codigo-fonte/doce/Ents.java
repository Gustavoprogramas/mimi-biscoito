package doce;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/** Objetos das fases. Cada um sabe se atualizar e se serializar para a rede. */
public final class Ents {
    private Ents() {}

    public abstract static class Ent {
        public int x, y, w, h;
        public void update(World wd) {}
        public void write(DataOutputStream o) throws IOException {}
        public void read(DataInputStream i) throws IOException {}
        public boolean overlaps(int ax, int ay, int aw, int ah) {
            return ax < x + w && ax + aw > x && ay < y + h && ay + ah > y;
        }
    }

    /** Algo solido que se move/aparece (elevador, portao, biscoito que quebra). */
    public abstract static class Solid extends Ent {
        public boolean collidable = true;
        public boolean solid() { return collidable; }
    }

    /** Plataforma que vai ate um alvo quando o canal liga (ou fica indo e voltando). */
    public static class Elevator extends Solid {
        public final int ch, hx, hy, tx, ty;
        public final boolean mover;
        public int dir = 1, pause = 0, color, px, py;
        public Elevator(int x, int y, int w, int ch, int dx, int dy, boolean mover) {
            this.x = hx = x; this.y = hy = y; this.w = w; this.h = 8;
            this.ch = ch; this.tx = x + dx * World.TS; this.ty = y + dy * World.TS; this.mover = mover;
        }
        @Override public void update(World wd) {
            int gx, gy;
            if (mover) {
                if (ch >= 0 && !wd.chan[ch]) return;
                if (pause > 0) { pause--; return; }
                gx = dir > 0 ? tx : hx; gy = dir > 0 ? ty : hy;
                if (x == gx && y == gy) { dir = -dir; pause = 40; return; }
            } else {
                boolean on = ch >= 0 && wd.chan[ch];
                gx = on ? tx : hx; gy = on ? ty : hy;
            }
            int sx = Integer.signum(gx - x), sy = Integer.signum(gy - y);
            if (sx != 0) wd.stepSolid(this, sx, 0);
            if (sy != 0) wd.stepSolid(this, 0, sy);
        }
        @Override public void write(DataOutputStream o) throws IOException { o.writeShort(x); o.writeShort(y); }
        @Override public void read(DataInputStream i) throws IOException { x = i.readShort(); y = i.readShort(); }
    }

    /** Portao de bala: abre (sobe) quando o canal liga. inv = fecha quando liga. */
    public static class Gate extends Solid {
        public final int ch, fullH;
        public final boolean inv;
        public int ph;
        public Gate(int x, int y, int w, int h, int ch, boolean inv) {
            this.x = x; this.y = y; this.w = w; this.h = h; this.fullH = h; this.ch = ch; this.inv = inv;
        }
        @Override public boolean solid() { return collidable && h > 0; }
        @Override public void update(World wd) {
            boolean open = (ch >= 0 && wd.chan[ch]) ^ inv;
            if (open) h = Math.max(0, h - 2);
            else if (h < fullH) {
                int nh = Math.min(fullH, h + 2);
                if (!wd.anyActorIn(x, y, w, nh)) h = nh;
            }
        }
        @Override public void write(DataOutputStream o) throws IOException { o.writeShort(h); }
        @Override public void read(DataInputStream i) throws IOException { h = i.readShort(); }
    }

    /** Biscoito crocante: quebra pouco depois de pisar e volta depois. */
    public static class Crumble extends Solid {
        public int state = 0, t = 0; // 0 inteiro, 1 tremendo, 2 quebrado
        public Crumble(int x, int y) { this.x = x; this.y = y; this.w = World.TS; this.h = World.TS; }
        @Override public boolean solid() { return collidable && state != 2; }
        @Override public void update(World wd) {
            if (state == 0) {
                if (wd.anyActorRiding(this)) { state = 1; t = 34; }
            } else if (state == 1) {
                if (--t <= 0) {
                    state = 2; t = 200;
                    wd.event(Sfx.CRUMBLE, x + 8, y + 8, World.P_CRUMBS);
                }
            } else if (state == 2) {
                if (--t <= 0) {
                    if (!wd.anyActorIn(x, y, w, h)) { state = 0; wd.event(-1, x + 8, y + 8, World.P_SPARK); }
                    else t = 10;
                }
            }
        }
        @Override public void write(DataOutputStream o) throws IOException { o.writeByte(state); o.writeShort(t); }
        @Override public void read(DataInputStream i) throws IOException { state = i.readByte(); t = i.readShort(); }
    }

    /** Botao de pressao. only: -1 qualquer um/caixa, 0 so Mimi, 1 so Biscoito. timed > 0 = segundos ligado. */
    public static class Button extends Ent {
        public final int ch, only, timed;
        public boolean pressed, ceiling;
        public int t;
        public Button(int x, int y, int ch, int only, int timed) {
            this.x = x; this.y = y; this.w = World.TS; this.h = World.TS; this.ch = ch; this.only = only; this.timed = timed;
        }
        public boolean active() { return pressed || t > 0; }
        @Override public void update(World wd) {
            boolean was = pressed;
            pressed = wd.buttonPressed(this);
            if (pressed && !was) wd.event(Sfx.CLICK, x + 8, y + 14, 0);
            if (timed > 0) {
                if (pressed) t = timed * 60;
                else if (t > 0) { t--; if (t % 30 == 0 && t > 0) wd.event(Sfx.SELECT, x + 8, y + 12, 0); }
            }
        }
        @Override public void write(DataOutputStream o) throws IOException { o.writeBoolean(pressed); o.writeShort(t); }
        @Override public void read(DataInputStream i) throws IOException { pressed = i.readBoolean(); t = i.readShort(); }
    }

    /** Alavanca: aperte BAIXO/S em cima dela para virar. */
    public static class Lever extends Ent {
        public final int ch;
        public boolean on;
        public int anim;
        public Lever(int x, int y, int ch, boolean on) { this.x = x; this.y = y; this.w = World.TS; this.h = World.TS; this.ch = ch; this.on = on; }
        @Override public void update(World wd) { if (anim > 0) anim--; }
        @Override public void write(DataOutputStream o) throws IOException { o.writeBoolean(on); }
        @Override public void read(DataInputStream i) throws IOException { on = i.readBoolean(); }
    }

    /** Ventilador de algodao-doce: corrente de ar para cima. */
    public static class Fan extends Ent {
        public final int ch;
        public int zoneTop;
        public boolean on = true;
        public Fan(int x, int y, int w, int ch) { this.x = x; this.y = y; this.w = w; this.h = World.TS; this.ch = ch; }
        @Override public void update(World wd) { on = ch < 0 || wd.chan[ch]; }
        @Override public void write(DataOutputStream o) throws IOException { o.writeBoolean(on); }
        @Override public void read(DataInputStream i) throws IOException { on = i.readBoolean(); }
    }

    /** Portal arco-iris: leva ate o par com o mesmo numero. */
    public static class Portal extends Ent {
        public final int id;
        public Portal other;
        public Portal(int x, int y, int id) { this.x = x; this.y = y; this.w = World.TS; this.h = World.TS; this.id = id; }
    }

    /** Orbe que inverte a gravidade de quem tocar. */
    public static class Orb extends Ent {
        public Orb(int x, int y) { this.x = x + 2; this.y = y + 2; this.w = 12; this.h = 12; }
    }

    /** Lanterna (fases escuras): acende ao encostar. */
    public static class Lantern extends Ent {
        public boolean lit;
        public Lantern(int x, int y) { this.x = x + 3; this.y = y; this.w = 10; this.h = 16; }
        @Override public void write(DataOutputStream o) throws IOException { o.writeBoolean(lit); }
        @Override public void read(DataInputStream i) throws IOException { lit = i.readBoolean(); }
    }

    /** Doce coletavel: 0 morango (Mimi), 1 cookie (Biscoito), 2 estrela (os dois). */
    public static class Gem extends Ent {
        public final int kind;
        public boolean got;
        public Gem(int x, int y, int kind) { this.x = x + 3; this.y = y + 3; this.w = 10; this.h = 10; this.kind = kind; }
        @Override public void write(DataOutputStream o) throws IOException { o.writeBoolean(got); }
        @Override public void read(DataInputStream i) throws IOException { got = i.readBoolean(); }
    }

    /** Porta de saida de cada personagem (2 tiles de altura). */
    public static class Door extends Ent {
        public final int kind;
        public boolean occupied;
        public int open; // 0..16
        public Door(int x, int y, int kind) { this.x = x; this.y = y - World.TS; this.w = World.TS; this.h = World.TS * 2; this.kind = kind; }
        @Override public void write(DataOutputStream o) throws IOException { o.writeBoolean(occupied); o.writeByte(open); }
        @Override public void read(DataInputStream i) throws IOException { occupied = i.readBoolean(); open = i.readByte(); }
    }

    /** Plaquinha de dica escrita no cenario. */
    public static class Text extends Ent {
        public final String text;
        public Text(int x, int y, String t) { this.x = x; this.y = y; this.text = t; }
    }

    // =====================================================================
    // Mecanicas dos mundos novos
    // =====================================================================

    /** Chave: qualquer um pega e leva na cabeca; abre o cadeado do mesmo numero. */
    public static class Key extends Ent {
        public final int group;
        public int state = 0, carrier = -1; // 0 no chao, 1 carregada, 2 usada
        public final int homeX, homeY;
        /** deep = chave no fundo de uma poca (so quem pode entrar na poca alcanca). */
        public Key(int x, int y, int group, boolean deep) {
            this.x = homeX = x + (deep ? 11 : 3); this.y = homeY = y + (deep ? 9 : 3); this.w = 10; this.h = 10; this.group = group;
        }
        @Override public void write(DataOutputStream o) throws IOException { o.writeByte(state); o.writeByte(carrier); }
        @Override public void read(DataInputStream i) throws IOException { state = i.readByte(); carrier = i.readByte(); }
    }

    /** Cadeado: parede que some quando alguem chega com a chave certa. */
    public static class Lock extends Solid {
        public final int group;
        public boolean open;
        public int fade;
        public Lock(int x, int y, int w, int h, int group) { this.x = x; this.y = y; this.w = w; this.h = h; this.group = group; }
        @Override public boolean solid() { return collidable && !open; }
        @Override public void update(World wd) { if (open && fade < 20) fade++; }
        @Override public void write(DataOutputStream o) throws IOException { o.writeBoolean(open); }
        @Override public void read(DataInputStream i) throws IOException { open = i.readBoolean(); }
    }

    /** Bloco do relogio: aparece e some no ritmo (fase 0 ou 1), com um respiro em que os dois existem. */
    public static class Beat extends Solid {
        public static final int CYCLE = 240;
        public final int phase;
        public boolean on;
        public Beat(int x, int y, int w, int phase) { this.x = x; this.y = y; this.w = w; this.h = World.TS; this.phase = phase; }
        public static boolean wants(int phase, int time) {
            int t = time % CYCLE;
            return phase == 0 ? t < 140 : (t >= 120 || t < 20);
        }
        /** Quantos ticks faltam pra sumir (para piscar de aviso); grande se nao vai sumir logo. */
        public static int left(int phase, int time) {
            int t = time % CYCLE;
            if (phase == 0) return t < 140 ? 140 - t : 999;
            if (t >= 120) return CYCLE - t + 20;
            return t < 20 ? 20 - t : 999;
        }
        @Override public boolean solid() { return collidable && on; }
        @Override public void update(World wd) {
            boolean want = wants(phase, wd.time);
            if (want && !on) {
                if (!wd.anyActorIn(x, y, w, h)) on = true;
            } else if (!want) on = false;
        }
        @Override public void write(DataOutputStream o) throws IOException { o.writeBoolean(on); }
        @Override public void read(DataInputStream i) throws IOException { on = i.readBoolean(); }
    }

    /** Bolha de lava de chocolate: pula da poca de tempos em tempos (depende so do relogio da fase). */
    public static class Blob extends Ent {
        public final int baseY, period, offset, height;
        /** Colocada na celula logo ACIMA da poca: sai da superficie da poca. */
        public Blob(int x, int y, int period, int offset, int heightTiles) {
            this.x = x + 3; this.baseY = y + World.TS + 2; this.y = baseY; this.w = 10; this.h = 10;
            this.period = period; this.offset = offset; this.height = heightTiles * World.TS;
        }
        /** Altura atual acima da poca (0 = escondida). */
        public int lift(int time) {
            int t = Math.floorMod(time + offset, period);
            int air = 56;
            if (t >= air) return 0;
            return (int) Math.round(height * Math.sin(Math.PI * t / air));
        }
        public boolean visible(int time) { return lift(time) > 4; }
        @Override public void update(World wd) { y = baseY - lift(wd.time); }
    }

    /** Laser: raio que corta quem encostar. modo 0 = desliga com o canal, 1 = liga com o canal, 2 = pisca sozinho. */
    public static class Laser extends Ent {
        public final int dir, ch, mode, period, offset; // dir 0 dir,1 esq,2 baixo,3 cima
        public boolean on;
        public int bx, by, bw, bh; // retangulo do raio (calculado)
        public Laser(int x, int y, int dir, int ch, int mode, int period, int offset) {
            this.x = x; this.y = y; this.w = World.TS; this.h = World.TS;
            this.dir = dir; this.ch = ch; this.mode = mode; this.period = period; this.offset = offset;
        }
        @Override public void update(World wd) { wd.updateLaser(this); }
    }

    /** Orbe de troca: quem encosta troca de lugar com o amigo (so funciona uma vez). */
    public static class Swap extends Ent {
        public boolean used;
        public Swap(int x, int y) { this.x = x + 2; this.y = y + 2; this.w = 12; this.h = 12; }
        @Override public void write(DataOutputStream o) throws IOException { o.writeBoolean(used); }
        @Override public void read(DataInputStream i) throws IOException { used = i.readBoolean(); }
    }
}

package doce;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Rede simples por TCP (funciona em LAN, Radmin VPN, Hamachi...).
 * O anfitriao (host) roda a fisica; o convidado manda os botoes apertados e recebe o estado.
 */
public final class Net {
    private Net() {}

    public static final int VERSION = 4;

    // Mensagens
    public static final byte HELLO = 1, WELCOME = 2, REJECT = 3, LOBBY = 4, INPUT = 5, START = 6, STATE = 7,
        PAUSE = 8, PAUSE_REQ = 9, MAP = 10, TO_LOBBY = 11, BYE = 12, PING = 13, MENU_SEL = 14;

    public static volatile Conn conn;
    private static volatile ServerSocket server;
    public static volatile String status = "";

    /** Uma conexao com mensagens enquadradas (tamanho + bytes). */
    public static final class Conn {
        private final Socket s;
        private final DataOutputStream out;
        private final DataInputStream in;
        private final ConcurrentLinkedQueue<byte[]> queue = new ConcurrentLinkedQueue<>();
        public volatile boolean closed = false;
        public final String remote;
        public volatile long lastRecv = System.currentTimeMillis();

        Conn(Socket s) throws IOException {
            this.s = s;
            s.setTcpNoDelay(true);
            s.setKeepAlive(true);
            out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream(), 8192));
            in = new DataInputStream(new BufferedInputStream(s.getInputStream(), 8192));
            remote = s.getInetAddress().getHostAddress();
            Thread t = new Thread(this::readLoop, "net-read");
            t.setDaemon(true);
            t.start();
        }

        private void readLoop() {
            try {
                while (!closed) {
                    int len = in.readInt();
                    if (len < 0 || len > 1 << 20) throw new IOException("mensagem invalida");
                    byte[] b = new byte[len];
                    in.readFully(b);
                    lastRecv = System.currentTimeMillis();
                    queue.add(b);
                }
            } catch (IOException e) {
                // fim da conexao
            } finally {
                closed = true;
                try { s.close(); } catch (IOException ignored) {}
            }
        }

        public byte[] poll() { return queue.poll(); }

        public synchronized void send(byte[] b) {
            if (closed) return;
            try {
                out.writeInt(b.length);
                out.write(b);
                out.flush();
            } catch (IOException e) {
                close();
            }
        }

        public void close() {
            closed = true;
            try { s.close(); } catch (IOException ignored) {}
        }
    }

    /** Ajudante para montar mensagens. */
    public static final class Msg {
        private final ByteArrayOutputStream bo = new ByteArrayOutputStream(256);
        public final DataOutputStream o = new DataOutputStream(bo);
        public Msg(byte type) { try { o.writeByte(type); } catch (IOException ignored) {} }
        public Msg b(int v) { try { o.writeByte(v); } catch (IOException ignored) {} return this; }
        public Msg i(int v) { try { o.writeInt(v); } catch (IOException ignored) {} return this; }
        public Msg z(boolean v) { try { o.writeBoolean(v); } catch (IOException ignored) {} return this; }
        public byte[] bytes() { return bo.toByteArray(); }
        public void send() { Conn c = conn; if (c != null) c.send(bytes()); }
    }

    public static DataInputStream reader(byte[] b) {
        return new DataInputStream(new ByteArrayInputStream(b));
    }

    // ------------------------------------------------------------ anfitriao
    public static void host(int port) {
        closeAll();
        status = "Abrindo a sala...";
        Thread t = new Thread(() -> {
            try {
                ServerSocket ss = new ServerSocket();
                ss.setReuseAddress(true);
                ss.bind(new InetSocketAddress(port));
                server = ss;
                status = "Esperando o amigo entrar...";
                while (!ss.isClosed()) {
                    Socket s = ss.accept();
                    if (conn != null && !conn.closed) { // ja tem alguem
                        s.close();
                        continue;
                    }
                    Conn c = new Conn(s);
                    conn = c;
                    status = "Amigo conectado: " + c.remote;
                }
            } catch (IOException e) {
                if (server != null) status = "Erro ao abrir a porta " + port + ": " + e.getMessage();
            }
        }, "net-accept");
        t.setDaemon(true);
        t.start();
    }

    // ------------------------------------------------------------ convidado
    public static void join(String ip, int port) {
        closeAll();
        status = "Conectando em " + ip + ":" + port + "...";
        Thread t = new Thread(() -> {
            try {
                Socket s = new Socket();
                s.connect(new InetSocketAddress(ip.trim(), port), 6000);
                conn = new Conn(s);
                status = "Conectado!";
            } catch (Exception e) {
                status = "Não deu pra conectar: " + simplify(e);
            }
        }, "net-connect");
        t.setDaemon(true);
        t.start();
    }

    private static String simplify(Exception e) {
        if (e instanceof SocketTimeoutException) return "tempo esgotado";
        if (e instanceof ConnectException) return "conexão recusada";
        if (e instanceof UnknownHostException) return "IP inválido";
        String m = e.getMessage();
        return m == null ? e.getClass().getSimpleName() : m;
    }

    public static void closeAll() {
        Conn c = conn;
        if (c != null) {
            try { c.send(new Msg(BYE).bytes()); } catch (Exception ignored) {}
            c.close();
        }
        conn = null;
        ServerSocket ss = server;
        server = null;
        if (ss != null) try { ss.close(); } catch (IOException ignored) {}
    }

    public static boolean connected() {
        Conn c = conn;
        return c != null && !c.closed;
    }

    /** Lista os IPs desta maquina; o do Radmin (26.x.x.x) vem primeiro. */
    public static List<String> localIps() {
        List<String> radmin = new ArrayList<>(), other = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> it = NetworkInterface.getNetworkInterfaces();
            for (NetworkInterface ni : Collections.list(it)) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!(a instanceof Inet4Address)) continue;
                    String ip = a.getHostAddress();
                    String name = (ni.getDisplayName() + " " + ni.getName()).toLowerCase();
                    if (ip.startsWith("26.") || name.contains("radmin")) radmin.add(ip + "  (Radmin)");
                    else other.add(ip);
                }
            }
        } catch (Exception ignored) {
        }
        radmin.addAll(other);
        if (radmin.isEmpty()) radmin.add("127.0.0.1");
        return radmin;
    }
}

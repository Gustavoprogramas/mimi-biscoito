package doce;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.HashMap;
import java.util.Map;

/** Fonte pixel 5x7 desenhada a mao, com acentos do portugues. */
public final class PixelFont {
    private static final Map<Character, boolean[][]> G = new HashMap<>();
    private static final Map<Character, int[]> BOUNDS = new HashMap<>();
    public static final int H = 7;
    public static final int LINE = 11;

    private static void put(char c, String rows) {
        String[] r = rows.split(" ");
        boolean[][] b = new boolean[7][5];
        for (int y = 0; y < 7; y++)
            for (int x = 0; x < 5; x++)
                b[y][x] = r[y].charAt(x) == '#';
        G.put(c, b);
        int l = 5, rt = -1;
        for (int y = 0; y < 7; y++)
            for (int x = 0; x < 5; x++)
                if (b[y][x]) { l = Math.min(l, x); rt = Math.max(rt, x); }
        boolean fixed = Character.isLetterOrDigit(c) || c == '♥' || c == '★' || c == '*' || c == '%' || c == '&';
        if (fixed || rt < 0) BOUNDS.put(c, new int[]{0, 5});
        else BOUNDS.put(c, new int[]{l, rt - l + 1});
    }

    static {
        put('A', ".###. #...# #...# ##### #...# #...# #...#");
        put('B', "####. #...# #...# ####. #...# #...# ####.");
        put('C', ".###. #...# #.... #.... #.... #...# .###.");
        put('D', "####. #...# #...# #...# #...# #...# ####.");
        put('E', "##### #.... #.... ####. #.... #.... #####");
        put('F', "##### #.... #.... ####. #.... #.... #....");
        put('G', ".###. #...# #.... #.### #...# #...# .####");
        put('H', "#...# #...# #...# ##### #...# #...# #...#");
        put('I', ".###. ..#.. ..#.. ..#.. ..#.. ..#.. .###.");
        put('J', "..### ...#. ...#. ...#. ...#. #..#. .##..");
        put('K', "#...# #..#. #.#.. ##... #.#.. #..#. #...#");
        put('L', "#.... #.... #.... #.... #.... #.... #####");
        put('M', "#...# ##.## #.#.# #.#.# #...# #...# #...#");
        put('N', "#...# #...# ##..# #.#.# #..## #...# #...#");
        put('O', ".###. #...# #...# #...# #...# #...# .###.");
        put('P', "####. #...# #...# ####. #.... #.... #....");
        put('Q', ".###. #...# #...# #...# #.#.# #..#. .##.#");
        put('R', "####. #...# #...# ####. #.#.. #..#. #...#");
        put('S', ".#### #.... #.... .###. ....# ....# ####.");
        put('T', "##### ..#.. ..#.. ..#.. ..#.. ..#.. ..#..");
        put('U', "#...# #...# #...# #...# #...# #...# .###.");
        put('V', "#...# #...# #...# #...# #...# .#.#. ..#..");
        put('W', "#...# #...# #...# #.#.# #.#.# #.#.# .#.#.");
        put('X', "#...# #...# .#.#. ..#.. .#.#. #...# #...#");
        put('Y', "#...# #...# .#.#. ..#.. ..#.. ..#.. ..#..");
        put('Z', "##### ....# ...#. ..#.. .#... #.... #####");
        put('0', ".###. #...# #..## #.#.# ##..# #...# .###.");
        put('1', "..#.. .##.. ..#.. ..#.. ..#.. ..#.. .###.");
        put('2', ".###. #...# ....# ...#. ..#.. .#... #####");
        put('3', "####. ....# ....# .###. ....# ....# ####.");
        put('4', "...#. ..##. .#.#. #..#. ##### ...#. ...#.");
        put('5', "##### #.... ####. ....# ....# #...# .###.");
        put('6', "..##. .#... #.... ####. #...# #...# .###.");
        put('7', "##### ....# ...#. ..#.. .#... .#... .#...");
        put('8', ".###. #...# #...# .###. #...# #...# .###.");
        put('9', ".###. #...# #...# .#### ....# ...#. .##..");
        put('.', "..... ..... ..... ..... ..... ..... ..#..");
        put(',', "..... ..... ..... ..... ..... ..#.. .#...");
        put(':', "..... ..... ..#.. ..... ..... ..#.. .....");
        put(';', "..... ..... ..#.. ..... ..... ..#.. .#...");
        put('!', "..#.. ..#.. ..#.. ..#.. ..#.. ..... ..#..");
        put('?', ".###. #...# ....# ...#. ..#.. ..... ..#..");
        put('-', "..... ..... ..... .###. ..... ..... .....");
        put('+', "..... ..... ..#.. .###. ..#.. ..... .....");
        put('=', "..... ..... ##### ..... ##### ..... .....");
        put('_', "..... ..... ..... ..... ..... ..... #####");
        put('/', "....# ...#. ...#. ..#.. .#... .#... #....");
        put('(', "...#. ..#.. .#... .#... .#... ..#.. ...#.");
        put(')', ".#... ..#.. ...#. ...#. ...#. ..#.. .#...");
        put('\'', "..#.. ..#.. ..... ..... ..... ..... .....");
        put('"', ".#.#. .#.#. ..... ..... ..... ..... .....");
        put('<', "...#. ..#.. .#... #.... .#... ..#.. ...#.");
        put('>', ".#... ..#.. ...#. ....# ...#. ..#.. .#...");
        put('%', "##..# ##.#. ...#. ..#.. .#... .#.## #..##");
        put('*', "..... #.#.# .###. ##### .###. #.#.# .....");
        put('♥', "..... .#.#. ##### ##### .###. ..#.. .....");
        put('★', "..#.. ..#.. ##### .###. .###. .#.#. #...#");
        put('←', "..... ..#.. .#... ##### .#... ..#.. .....");
        put('→', "..... ..#.. ...#. ##### ...#. ..#.. .....");
        put('↑', "..#.. .###. #.#.# ..#.. ..#.. ..#.. .....");
        put('↓', "..#.. ..#.. ..#.. #.#.# .###. ..#.. .....");
        put('#', ".#.#. ##### .#.#. .#.#. ##### .#.#. .....");
        put('&', ".##.. #..#. #.#.. .#... #.#.# #..#. .##.#");
        put(' ', "..... ..... ..... ..... ..... ..... .....");
        BOUNDS.put(' ', new int[]{0, 3});
    }

    private PixelFont() {}

    private static final String ACC_SRC = "ÁÀÂÃÉÈÊÍÌÎÓÒÔÕÚÙÛÇÄËÏÖÜ";
    private static final String ACC_BASE = "AAAAEEEIIIOOOOUUUCAEIOU";
    private static final String ACC_KIND = "agctagcagcagctagcdeeeee"; // a=agudo g=grave c=circ t=til d=cedilha e=trema

    private static char baseOf(char c) {
        int i = ACC_SRC.indexOf(c);
        return i >= 0 ? ACC_BASE.charAt(i) : c;
    }

    private static char accentOf(char c) {
        int i = ACC_SRC.indexOf(c);
        return i >= 0 ? ACC_KIND.charAt(i) : 0;
    }

    private static int[] bounds(char c) {
        int[] b = BOUNDS.get(c);
        return b != null ? b : BOUNDS.get('?');
    }

    public static int width(String s) { return width(s, 1); }

    public static int width(String s, int scale) {
        s = s.toUpperCase();
        int w = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = baseOf(s.charAt(i));
            w += (bounds(c)[1] + 1) * scale;
        }
        return Math.max(0, w - scale);
    }

    public static void draw(Graphics2D g, String s, int x, int y, Color col) { draw(g, s, x, y, col, 1); }

    // ---- cache: cada texto vira uma imagem pronta (desenhar pixel a pixel todo quadro pesa)
    private static final Map<String, java.awt.image.BufferedImage> CACHE = new HashMap<>();

    public static void warmUp() {
        for (String s : new String[]{"0123456789", "ABCDEFGHIJKLMNOPQRSTUVWXYZ"}) width(s);
    }

    public static void draw(Graphics2D g, String s, int x, int y, Color col, int sc) {
        if (s == null || s.isEmpty()) return;
        int rgb = col.getRGB() | 0xff000000, alpha = col.getAlpha();
        if (alpha == 0) return;
        String key = sc + "|" + rgb + "|" + s;
        java.awt.image.BufferedImage img = CACHE.get(key);
        if (img == null) {
            int w = width(s, sc);
            if (w <= 0) return;
            img = new java.awt.image.BufferedImage(w + sc, 11 * sc, java.awt.image.BufferedImage.TYPE_INT_ARGB);
            Graphics2D ig = img.createGraphics();
            drawRaw(ig, s, 0, 2 * sc, new Color(rgb, true), sc);
            ig.dispose();
            if (CACHE.size() > 600) CACHE.clear();
            CACHE.put(key, img);
        }
        if (alpha < 255) { // texto meio transparente: mesma imagem, so muda a opacidade
            java.awt.Composite old = g.getComposite();
            g.setComposite(java.awt.AlphaComposite.getInstance(java.awt.AlphaComposite.SRC_OVER, alpha / 255f));
            g.drawImage(img, x, y - 2 * sc, null);
            g.setComposite(old);
        } else g.drawImage(img, x, y - 2 * sc, null);
    }

    private static void drawRaw(Graphics2D g, String s, int x, int y, Color col, int sc) {
        g.setColor(col);
        s = s.toUpperCase();
        int cx = x;
        for (int i = 0; i < s.length(); i++) {
            char raw = s.charAt(i);
            char c = baseOf(raw);
            boolean[][] gl = G.get(c);
            if (gl == null) gl = G.get('?');
            int[] bd = bounds(c);
            for (int yy = 0; yy < 7; yy++)
                for (int xx = 0; xx < bd[1]; xx++)
                    if (gl[yy][xx + bd[0]]) g.fillRect(cx + xx * sc, y + yy * sc, sc, sc);
            char acc = accentOf(raw);
            if (acc != 0) drawAccent(g, acc, cx, y, sc);
            cx += (bd[1] + 1) * sc;
        }
    }

    private static void px(Graphics2D g, int x, int y, int sc) { g.fillRect(x, y, sc, sc); }

    private static void drawAccent(Graphics2D g, char k, int x, int y, int sc) {
        int t = y - 2 * sc;
        switch (k) {
            case 'a': px(g, x + 3 * sc, t, sc); px(g, x + 2 * sc, t + sc, sc); break;
            case 'g': px(g, x + sc, t, sc); px(g, x + 2 * sc, t + sc, sc); break;
            case 'c': px(g, x + 2 * sc, t, sc); px(g, x + sc, t + sc, sc); px(g, x + 3 * sc, t + sc, sc); break;
            case 't': px(g, x + sc, t, sc); px(g, x + 2 * sc, t, sc); px(g, x + 4 * sc, t, sc);
                      px(g, x, t + sc, sc); px(g, x + 3 * sc, t + sc, sc); break;
            case 'e': px(g, x + sc, t, sc); px(g, x + 3 * sc, t, sc); break;
            case 'd': px(g, x + 2 * sc, y + 7 * sc, sc); px(g, x + sc, y + 8 * sc, sc); px(g, x + 2 * sc, y + 8 * sc, sc); break;
            default: break;
        }
    }

    /** Texto com contorno de 1px (bem "fofo"). */
    public static void outlined(Graphics2D g, String s, int x, int y, Color col, Color outline, int sc) {
        if (sc == 1) { // texto pequeno: sombrinha em vez de contorno (fica mais legivel)
            draw(g, s, x + 1, y + 1, outline, 1);
            draw(g, s, x, y + 1, outline, 1);
            draw(g, s, x + 1, y, outline, 1);
            draw(g, s, x, y, col, 1);
            return;
        }
        for (int dy = -1; dy <= 1; dy++)
            for (int dx = -1; dx <= 1; dx++)
                if (dx != 0 || dy != 0) draw(g, s, x + dx * sc, y + dy * sc, outline, sc);
        draw(g, s, x, y, col, sc);
    }

    public static void centered(Graphics2D g, String s, int cx, int y, Color col, int sc) {
        draw(g, s, cx - width(s, sc) / 2, y, col, sc);
    }

    public static void centeredOutlined(Graphics2D g, String s, int cx, int y, Color col, Color outline, int sc) {
        outlined(g, s, cx - width(s, sc) / 2, y, col, outline, sc);
    }

    /** Quebra texto em linhas que cabem na largura. */
    public static java.util.List<String> wrap(String s, int maxW) {
        java.util.List<String> out = new java.util.ArrayList<>();
        for (String para : s.split("\n")) {
            String line = "";
            for (String w : para.split(" ")) {
                String t = line.isEmpty() ? w : line + " " + w;
                if (width(t) > maxW && !line.isEmpty()) {
                    out.add(line);
                    line = w;
                } else line = t;
            }
            out.add(line);
        }
        return out;
    }
}

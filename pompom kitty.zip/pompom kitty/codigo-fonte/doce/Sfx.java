package doce;

import javax.sound.sampled.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Sons e musicas chiptune gerados por codigo (nenhum arquivo externo). */
public final class Sfx {
    private Sfx() {}

    public static final int JUMP = 0, LAND = 1, GEM = 2, DIE = 3, CLICK = 4, LEVER = 5, DOOR = 6, WIN = 7,
        PORTAL = 8, BOING = 9, SELECT = 10, CONFIRM = 11, CRUMBLE = 12, POP = 13, FLIP = 14, CHIME = 15,
        BACK = 16, STAR = 17;
    private static final int N = 18;
    private static final float RATE = 22050f;
    private static Clip[] clips = new Clip[N];
    private static Clip[] music = new Clip[2];
    private static int musicId = -1;
    private static boolean ok = false;
    public static boolean muted = false;
    private static ExecutorService exec;

    public static void init() {
        exec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "audio");
            t.setDaemon(true);
            return t;
        });
        exec.submit(() -> {
            try {
                float[][] s = new float[N][];
                s[JUMP] = sweep(380, 760, 0.11, 0.25, 0.30);
                s[LAND] = noise(0.05, 0.18, 30);
                s[GEM] = cat(sq(988, 0.06, 0.25, 0.3), sq(1319, 0.14, 0.25, 0.3));
                s[DIE] = cat(sweep(660, 160, 0.35, 0.5, 0.35), noise(0.15, 0.2, 12));
                s[CLICK] = cat(sq(523, 0.03, 0.5, 0.25), sq(784, 0.05, 0.5, 0.25));
                s[LEVER] = cat(noise(0.03, 0.25, 40), sq(392, 0.05, 0.5, 0.2), sq(587, 0.06, 0.5, 0.2));
                s[DOOR] = arp(new double[]{523, 659, 784, 1047}, 0.07, 0.25);
                s[WIN] = cat(arp(new double[]{523, 659, 784, 1047, 784, 1047, 1319}, 0.09, 0.28), sq(1568, 0.35, 0.25, 0.25));
                s[PORTAL] = warble(0.35);
                s[BOING] = sweep(180, 620, 0.18, 0.5, 0.35);
                s[SELECT] = sq(880, 0.04, 0.25, 0.2);
                s[CONFIRM] = cat(sq(659, 0.05, 0.25, 0.25), sq(988, 0.09, 0.25, 0.25));
                s[CRUMBLE] = noise(0.25, 0.3, 8);
                s[POP] = sweep(600, 1200, 0.06, 0.5, 0.25);
                s[FLIP] = cat(sweep(300, 900, 0.12, 0.25, 0.25), sweep(900, 300, 0.12, 0.25, 0.2));
                s[CHIME] = cat(sq(1047, 0.08, 0.125, 0.22), sq(1568, 0.2, 0.125, 0.2));
                s[BACK] = cat(sq(659, 0.05, 0.25, 0.22), sq(440, 0.08, 0.25, 0.22));
                s[STAR] = arp(new double[]{784, 988, 1175, 1568, 1976}, 0.05, 0.25);
                for (int i = 0; i < N; i++) clips[i] = clip(s[i]);
                music[0] = clip(song(TITLE_MEL, TITLE_BASS, 112));
                music[1] = clip(song(LEVEL_MEL, LEVEL_BASS, 128));
                ok = true;
                muted = Save.muted;
                if (pendingMusic >= 0) applyMusic(pendingMusic);
            } catch (Throwable t) {
                ok = false;
                System.err.println("Audio indisponivel: " + t);
            }
        });
    }

    private static volatile int pendingMusic = -1;

    public static void play(int id) {
        if (!ok || muted || exec == null) return;
        exec.submit(() -> {
            try {
                Clip c = clips[id];
                if (c == null) return;
                c.stop();
                c.setFramePosition(0);
                c.start();
            } catch (Throwable ignored) {}
        });
    }

    public static void music(int id) {
        pendingMusic = id;
        if (!ok || exec == null) return;
        exec.submit(() -> applyMusic(id));
    }

    private static void applyMusic(int id) {
        try {
            if (id == musicId && (muted || (id >= 0 && music[id].isRunning()))) return;
            for (Clip c : music) if (c != null) c.stop();
            musicId = id;
            if (id >= 0 && !muted) {
                music[id].setFramePosition(0);
                music[id].loop(Clip.LOOP_CONTINUOUSLY);
            }
        } catch (Throwable ignored) {}
    }

    public static void toggleMute() {
        muted = !muted;
        Save.muted = muted;
        if (exec == null) return;
        final int id = musicId;
        exec.submit(() -> {
            try {
                if (muted) { for (Clip c : music) if (c != null) c.stop(); }
                else if (id >= 0) { music[id].setFramePosition(0); music[id].loop(Clip.LOOP_CONTINUOUSLY); }
            } catch (Throwable ignored) {}
        });
    }

    public static void shutdown() {
        try { for (Clip c : music) if (c != null) c.close(); } catch (Throwable ignored) {}
    }

    // ---------- Sintese ----------
    private static Clip clip(float[] s) throws Exception {
        byte[] b = new byte[s.length * 2];
        for (int i = 0; i < s.length; i++) {
            int v = (int) (Math.max(-1, Math.min(1, s[i])) * 32000);
            b[i * 2] = (byte) v;
            b[i * 2 + 1] = (byte) (v >> 8);
        }
        AudioFormat f = new AudioFormat(RATE, 16, 1, true, false);
        Clip c = AudioSystem.getClip();
        c.open(f, b, 0, b.length);
        return c;
    }

    private static float[] sq(double f, double dur, double duty, double vol) {
        return sweep(f, f, dur, duty, vol);
    }

    private static float[] sweep(double f0, double f1, double dur, double duty, double vol) {
        int n = (int) (dur * RATE);
        float[] s = new float[n];
        double ph = 0;
        for (int i = 0; i < n; i++) {
            double t = i / (double) n;
            double f = f0 + (f1 - f0) * t;
            ph += f / RATE;
            double v = (ph % 1.0) < duty ? 1 : -1;
            double env = Math.min(1, i / (RATE * 0.004)) * (1 - t * 0.85);
            s[i] = (float) (v * vol * env);
        }
        return s;
    }

    private static float[] noise(double dur, double vol, double decay) {
        int n = (int) (dur * RATE);
        float[] s = new float[n];
        java.util.Random r = new java.util.Random(7);
        float hold = 0;
        for (int i = 0; i < n; i++) {
            if (i % 3 == 0) hold = r.nextFloat() * 2 - 1;
            s[i] = (float) (hold * vol * Math.exp(-decay * i / RATE));
        }
        return s;
    }

    private static float[] warble(double dur) {
        int n = (int) (dur * RATE);
        float[] s = new float[n];
        double ph = 0;
        for (int i = 0; i < n; i++) {
            double t = i / RATE;
            double f = 500 + 300 * Math.sin(t * 60) + 400 * (i / (double) n);
            ph += f / RATE;
            s[i] = (float) (Math.sin(ph * Math.PI * 2) * 0.3 * (1 - i / (double) n));
        }
        return s;
    }

    private static float[] arp(double[] fs, double each, double vol) {
        float[][] parts = new float[fs.length][];
        for (int i = 0; i < fs.length; i++) parts[i] = sq(fs[i], each, 0.25, vol);
        return cat(parts);
    }

    private static float[] cat(float[]... parts) {
        int n = 0;
        for (float[] p : parts) n += p.length;
        float[] s = new float[n];
        int o = 0;
        for (float[] p : parts) { System.arraycopy(p, 0, s, o, p.length); o += p.length; }
        return s;
    }

    // ---------- Musica ----------
    // Cada token = colcheia. "-" segura, "." pausa.
    private static final String TITLE_MEL =
        "C5 E5 G5 E5 A5 G5 E5 - F5 E5 D5 C5 D5 - - . " +
        "C5 E5 G5 E5 A5 G5 C6 - B5 A5 G5 F5 G5 - - . " +
        "A5 - G5 - F5 E5 D5 - G5 - F5 - E5 D5 C5 - " +
        "D5 E5 F5 G5 A5 G5 F5 E5 D5 - G4 - C5 - - .";
    private static final String TITLE_BASS = "C3 G2 C3 G2 F2 C3 D3 G2";
    private static final String LEVEL_MEL =
        "G4 B4 D5 B4 E5 D5 B4 G4 A4 B4 C5 A4 B4 - G4 . " +
        "G4 B4 D5 G5 F#5 E5 D5 B4 C5 B4 A4 G4 A4 - - . " +
        "E5 - D5 C5 B4 - A4 G4 C5 - B4 A4 G4 - E4 . " +
        "D5 E5 D5 C5 B4 A4 B4 D5 G5 - D5 - G4 - - .";
    private static final String LEVEL_BASS = "G2 D3 G2 C3 A2 C3 D3 G2";

    private static double freq(String n) {
        String names = "C D EF G A B";
        int semi = names.indexOf(n.charAt(0));
        int i = 1;
        if (n.charAt(1) == '#') { semi++; i++; }
        int oct = Integer.parseInt(n.substring(i));
        int midi = 12 * (oct + 1) + semi;
        return 440.0 * Math.pow(2, (midi - 69) / 12.0);
    }

    private static float[] song(String mel, String bass, int bpm) {
        String[] m = mel.trim().split("\\s+");
        String[] b = bass.trim().split("\\s+");
        double eighth = 60.0 / bpm / 2;
        int stepN = (int) (eighth * RATE);
        int total = stepN * m.length;
        float[] s = new float[total];
        // melodia (onda quadrada 25%)
        int i = 0;
        while (i < m.length) {
            if (m[i].equals("-") || m[i].equals(".")) { i++; continue; }
            int len = 1;
            while (i + len < m.length && m[i + len].equals("-")) len++;
            double f = freq(m[i]);
            int start = i * stepN, n = len * stepN;
            double ph = 0;
            for (int k = 0; k < n && start + k < total; k++) {
                ph += f / RATE;
                double v = (ph % 1.0) < 0.25 ? 1 : -1;
                double env = Math.min(1, k / (RATE * 0.005)) * (0.75 + 0.25 * Math.exp(-k / (RATE * 0.08)));
                if (k > n - RATE * 0.03) env *= Math.max(0, (n - k) / (RATE * 0.03));
                double vib = 1 + 0.004 * Math.sin(k / RATE * 2 * Math.PI * 6);
                s[start + k] += (float) (v * env * 0.11 * vib);
            }
            i += len;
        }
        // baixo (triangulo): fundamental, oitava, quinta, oitava
        int bars = m.length / 8;
        for (int bar = 0; bar < bars; bar++) {
            double root = freq(b[bar % b.length]);
            double[] pat = {root, root * 2, root * 1.5, root * 2};
            for (int q = 0; q < 4; q++) {
                int start = (bar * 8 + q * 2) * stepN;
                int n = (int) (stepN * 1.6);
                double ph = 0;
                for (int k = 0; k < n && start + k < total; k++) {
                    ph += pat[q] / RATE;
                    double tri = 4 * Math.abs((ph % 1.0) - 0.5) - 1;
                    double env = Math.min(1, k / (RATE * 0.004)) * Math.exp(-k / (RATE * 0.25));
                    s[start + k] += (float) (tri * env * 0.16);
                }
            }
            // percussao suave
            java.util.Random r = new java.util.Random(bar);
            for (int e = 0; e < 8; e++) {
                int start = (bar * 8 + e) * stepN;
                boolean kick = e == 0 || e == 4;
                int n = (int) (RATE * (kick ? 0.09 : 0.03));
                for (int k = 0; k < n && start + k < total; k++) {
                    double v;
                    if (kick) v = Math.sin(2 * Math.PI * (90 - 50 * k / (double) n) * k / RATE) * Math.exp(-k / (RATE * 0.04)) * 0.22;
                    else v = (r.nextFloat() * 2 - 1) * Math.exp(-k / (RATE * 0.008)) * (e % 2 == 1 ? 0.035 : 0.02);
                    s[start + k] += (float) v;
                }
            }
        }
        return s;
    }
}

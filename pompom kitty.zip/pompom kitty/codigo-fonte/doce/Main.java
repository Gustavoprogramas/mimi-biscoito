package doce;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.util.concurrent.locks.LockSupport;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 * Janela e loop principal.
 * A fisica roda em passos fixos de 60 por segundo; o desenho roda o mais rapido possivel
 * (ou no limite escolhido) e interpola as posicoes entre dois passos, por isso fica liso
 * mesmo em monitores de 120/144/240 Hz.
 */
public class Main implements Runnable {
    public static final int W = 480, H = 272;
    public static final String TITLE = "Mimi & Biscoito - Aventura Doce";
    public static Main game;
    /** Fracao (0..1) entre o ultimo passo de fisica e o proximo; usada para interpolar o desenho. */
    public static volatile float alpha = 1f;

    public interface Screen {
        void update();
        void render(Graphics2D g);
        default void onEnter() {}
        default void onExit() {}
    }

    public static final int[] FPS_OPTIONS = {0, 240, 144, 120, 60}; // 0 = ilimitado
    private static final long STEP = 1_000_000_000L / 60;

    public final Input input = new Input();
    private JFrame frame;
    private Canvas canvas;
    private final BufferedImage buf = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
    private Screen screen, pending;
    private int fade = 0; // >0 = escurecendo, <0 = clareando
    private static final int FADE = 10;
    public long ticks;
    private volatile boolean running = true;
    private boolean maximized;
    private int fps, frameCount;
    private long fpsTime;
    private String osd = "";
    private long osdUntil;
    private final Color letterbox = new Color(0x2a1b2e);

    public static void main(String[] args) {
        System.setProperty("sun.java2d.opengl", "false");
        System.setProperty("sun.java2d.d3d", "true");
        System.setProperty("sun.java2d.ddforcevram", "true");
        // Truque classico do Windows: uma thread dormindo "para sempre" liga o relogio de 1 ms do sistema,
        // senao cada Thread.sleep() pode durar ~15 ms e o jogo da trancos.
        Thread hr = new Thread(() -> {
            try { Thread.sleep(Long.MAX_VALUE); } catch (InterruptedException ignored) {}
        }, "relogio-preciso");
        hr.setDaemon(true);
        hr.start();
        game = new Main();
        SwingUtilities.invokeLater(game::createWindow);
    }

    private void createWindow() {
        frame = new JFrame(TITLE);
        canvas = new Canvas();
        canvas.setPreferredSize(new Dimension(W * 2, H * 2));
        canvas.setBackground(letterbox);
        canvas.setFocusTraversalKeysEnabled(false);
        canvas.addKeyListener(input);
        canvas.setIgnoreRepaint(true);
        frame.setIgnoreRepaint(true);
        frame.add(canvas);
        frame.pack();
        Dimension scr = Toolkit.getDefaultToolkit().getScreenSize();
        if (scr.width >= W * 3 + 80 && scr.height >= H * 3 + 120) {
            canvas.setPreferredSize(new Dimension(W * 3, H * 3));
            frame.pack();
        }
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { quit(); }
            @Override public void windowDeactivated(WindowEvent e) { input.releaseAll(); }
        });
        try { frame.setIconImage(Art.icon()); } catch (Throwable ignored) {}
        frame.setVisible(true);
        canvas.createBufferStrategy(2);
        canvas.requestFocus();
        Sfx.init();
        Save.load();
        PixelFont.warmUp();
        setScreenNow(new Screens.Title());
        Thread t = new Thread(this, "loop");
        t.setPriority(Thread.MAX_PRIORITY);
        t.start();
    }

    public void quit() {
        running = false;
        Net.closeAll();
        Sfx.shutdown();
        Save.store();
        System.exit(0);
    }

    /** Troca de tela com fade. */
    public void setScreen(Screen s) {
        pending = s;
        fade = FADE;
    }

    public void setScreenNow(Screen s) {
        if (screen != null) screen.onExit();
        screen = s;
        pending = null;
        input.releaseAll();
        s.onEnter();
    }

    public Screen current() { return screen; }

    // =================================================================== loop
    @Override
    public void run() {
        long last = System.nanoTime();
        long acc = 0;
        fpsTime = last;
        while (running) {
            long frameStart = System.nanoTime();
            acc += frameStart - last;
            last = frameStart;
            if (acc > STEP * 6) acc = STEP; // travou (ex.: janela arrastada): nao tenta recuperar tudo
            while (acc >= STEP) {
                tick();
                acc -= STEP;
            }
            alpha = acc / (float) STEP;
            render();
            frameCount++;
            long now = System.nanoTime();
            if (now - fpsTime >= 1_000_000_000L) {
                fps = frameCount;
                frameCount = 0;
                fpsTime = now;
            }
            int cap = Save.fpsCap;
            if (cap > 0) sleepUntil(frameStart + 1_000_000_000L / cap);
            else if (Save.smooth) Thread.yield();
            else sleepUntil(frameStart + 1_000_000L); // modo classico ilimitado: ainda deixa a CPU respirar
        }
    }

    /** Espera precisa: dorme em pedacinhos e termina no "giro" pra nao passar do ponto. */
    private static void sleepUntil(long target) {
        while (true) {
            long left = target - System.nanoTime();
            if (left <= 0) return;
            if (left > 2_000_000L) LockSupport.parkNanos(left - 1_500_000L);
            else if (left > 200_000L) Thread.yield();
            else { /* gira o restinho */ }
        }
    }

    private void tick() {
        input.poll();
        ticks++;
        if (input.pressed(KeyEvent.VK_F11)) toggleMax();
        if (input.pressed(KeyEvent.VK_M)) { Sfx.toggleMute(); showOsd(Sfx.muted ? "SOM DESLIGADO" : "SOM LIGADO"); }
        if (input.pressed(KeyEvent.VK_F3)) cycleFps();
        if (input.pressed(KeyEvent.VK_F2)) { Save.showFps = !Save.showFps; Save.store(); }
        if (input.pressed(KeyEvent.VK_F4)) {
            Save.smooth = !Save.smooth;
            Save.store();
            showOsd(Save.smooth ? "DESENHO: SUAVE (ALTA RESOLUÇÃO)" : "DESENHO: CLÁSSICO (MAIS LEVE)");
        }
        try {
            if (fade > 0) {
                fade--;
                if (fade == 0 && pending != null) {
                    setScreenNow(pending);
                    fade = -FADE;
                }
            } else if (fade < 0) fade++;
            // durante o escurecimento a tela antiga fica congelada (nao consome mensagens da rede)
            if (screen != null && !(fade > 0 && pending != null)) screen.update();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void cycleFps() {
        int i = 0;
        for (int k = 0; k < FPS_OPTIONS.length; k++) if (FPS_OPTIONS[k] == Save.fpsCap) i = k;
        Save.fpsCap = FPS_OPTIONS[(i + 1) % FPS_OPTIONS.length];
        Save.store();
        showOsd("LIMITE DE FPS: " + (Save.fpsCap == 0 ? "ILIMITADO" : "" + Save.fpsCap));
    }

    private void showOsd(String s) {
        osd = s;
        osdUntil = System.currentTimeMillis() + 2000;
    }

    private void toggleMax() {
        SwingUtilities.invokeLater(() -> {
            maximized = !maximized;
            frame.setExtendedState(maximized ? JFrame.MAXIMIZED_BOTH : JFrame.NORMAL);
        });
    }

    // =================================================================== desenho
    private void drawScene(Graphics2D g) {
        if (screen != null) screen.render(g);
        float a = fade > 0 ? 1f - (fade - alpha) / (float) FADE : fade < 0 ? (-fade - alpha) / (float) FADE : 0f;
        a = Math.max(0, Math.min(1, a));
        if (a > 0) {
            g.setColor(new Color(42, 27, 46, Math.min(255, (int) (a * 255))));
            g.fillRect(0, 0, W, H);
        }
    }

    private void render() {
        BufferStrategy bs = canvas.getBufferStrategy();
        if (bs == null) return;
        int cw = canvas.getWidth(), ch = canvas.getHeight();
        if (cw <= 0 || ch <= 0) return;
        double raw = Math.min(cw / (double) W, ch / (double) H);
        double s = raw;
        if (raw >= 1) {
            double fl = Math.floor(raw);
            if (fl / raw >= 0.85) s = fl; // escala inteira quando quase nao perde espaco (pixels certinhos)
        }
        int dw = (int) Math.round(W * s), dh = (int) Math.round(H * s);
        int ox = (cw - dw) / 2, oy = (ch - dh) / 2;
        boolean smooth = Save.smooth;
        if (!smooth) { // modo classico: desenha pequeno e amplia de uma vez
            Graphics2D g = buf.createGraphics();
            try { drawScene(g); } catch (Exception e) { e.printStackTrace(); } finally { g.dispose(); }
        }
        do {
            do {
                Graphics2D cg = (Graphics2D) bs.getDrawGraphics();
                try {
                    cg.setColor(letterbox);
                    cg.fillRect(0, 0, cw, ch);
                    cg.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
                    cg.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
                    cg.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
                    if (smooth) {
                        AffineTransform base = cg.getTransform();
                        cg.translate(ox, oy);
                        cg.scale(dw / (double) W, dh / (double) H);
                        cg.clipRect(0, 0, W, H);
                        try { drawScene(cg); } catch (Exception e) { e.printStackTrace(); }
                        cg.setTransform(base);
                        cg.setClip(null);
                    } else {
                        cg.drawImage(buf, ox, oy, dw, dh, null);
                    }
                    drawOverlay(cg, cw);
                } finally {
                    cg.dispose();
                }
            } while (bs.contentsRestored());
            bs.show();
        } while (bs.contentsLost());
        Toolkit.getDefaultToolkit().sync();
    }

    /** FPS e avisos rapidos, desenhados na resolucao da tela. */
    private void drawOverlay(Graphics2D g, int cw) {
        if (Save.showFps) {
            String f = fps + " FPS";
            int y = canvas.getHeight() - 26;
            g.setColor(new Color(0, 0, 0, 140));
            g.fillRect(4, y, PixelFont.width(f, 2) + 8, 20);
            PixelFont.draw(g, f, 8, y + 3, new Color(0x8be06a), 2);
        }
        if (System.currentTimeMillis() < osdUntil) {
            int w = PixelFont.width(osd, 2) + 16;
            int x = (cw - w) / 2;
            g.setColor(new Color(42, 27, 46, 220));
            g.fillRect(x, 30, w, 24);
            PixelFont.draw(g, osd, x + 8, 35, Color.WHITE, 2);
        }
    }

    /** Usado pelos testes: um tick sem janela. */
    public void tickOnce() { tick(); }

    /** Usado pelos testes para desenhar sem janela. */
    public static BufferedImage renderOffscreen(Screen s) {
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        s.render(g);
        g.dispose();
        return img;
    }
}

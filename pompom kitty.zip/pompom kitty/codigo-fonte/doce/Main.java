package doce;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/** Janela, loop fixo de 60 ticks e troca de telas. */
public class Main implements Runnable {
    public static final int W = 480, H = 272;
    public static final String TITLE = "Mimi & Biscoito - Aventura Doce";
    public static Main game;

    public interface Screen {
        void update();
        void render(Graphics2D g);
        default void onEnter() {}
        default void onExit() {}
    }

    public final Input input = new Input();
    private JFrame frame;
    private Canvas canvas;
    private final BufferedImage buf = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
    private Screen screen, pending;
    private int fade = 0; // >0 = escurecendo, <0 = clareando
    private static final int FADE = 10;
    public long ticks;
    private volatile boolean running = true;
    private boolean maximized;

    public static void main(String[] args) {
        System.setProperty("sun.java2d.opengl", "false");
        game = new Main();
        SwingUtilities.invokeLater(game::createWindow);
    }

    private void createWindow() {
        frame = new JFrame(TITLE);
        canvas = new Canvas();
        canvas.setPreferredSize(new Dimension(W * 2, H * 2));
        canvas.setBackground(new Color(0x2a1b2e));
        canvas.setFocusTraversalKeysEnabled(false);
        canvas.addKeyListener(input);
        canvas.setIgnoreRepaint(true);
        frame.add(canvas);
        frame.pack();
        Dimension scr = Toolkit.getDefaultToolkit().getScreenSize();
        if (scr.width >= W * 3 + 80 && scr.height >= H * 3 + 120) {
            canvas.setPreferredSize(new Dimension(W * 3, H * 3));
            frame.pack();
        }
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { quit(); }
            @Override public void windowDeactivated(WindowEvent e) { input.releaseAll(); }
        });
        try { frame.setIconImage(Art.icon()); } catch (Throwable ignored) {}
        frame.setVisible(true);
        canvas.createBufferStrategy(2);
        canvas.requestFocus();
        Sfx.init();
        Save.load();
        setScreenNow(new Screens.Title());
        Thread t = new Thread(this, "loop");
        t.start();
    }

    public void quit() {
        running = false;
        Net.closeAll();
        Sfx.shutdown();
        Save.store();
        System.exit(0);
    }

    /** Troca de tela com fade. */
    public void setScreen(Screen s) {
        pending = s;
        fade = FADE;
    }

    public void setScreenNow(Screen s) {
        if (screen != null) screen.onExit();
        screen = s;
        pending = null;
        input.releaseAll();
        s.onEnter();
    }

    public Screen current() { return screen; }

    @Override
    public void run() {
        final long step = 1_000_000_000L / 60;
        long next = System.nanoTime();
        while (running) {
            long now = System.nanoTime();
            if (now - next > step * 10) next = now; // travou? nao tenta recuperar
            int loops = 0;
            while (now >= next && loops < 5) {
                tick();
                next += step;
                loops++;
            }
            render();
            long sleep = (next - System.nanoTime()) / 1_000_000L;
            if (sleep > 0) {
                try { Thread.sleep(sleep); } catch (InterruptedException ignored) {}
            } else Thread.yield();
        }
    }

    private void tick() {
        input.poll();
        ticks++;
        if (input.pressed(KeyEvent.VK_F11)) toggleMax();
        if (input.pressed(KeyEvent.VK_M)) Sfx.toggleMute();
        try {
            if (fade > 0) {
                fade--;
                if (fade == 0 && pending != null) {
                    setScreenNow(pending);
                    fade = -FADE;
                }
            } else if (fade < 0) fade++;
            // durante o escurecimento a tela antiga fica congelada (nao consome mensagens da rede)
            if (screen != null && !(fade > 0 && pending != null)) screen.update();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void toggleMax() {
        SwingUtilities.invokeLater(() -> {
            maximized = !maximized;
            frame.setExtendedState(maximized ? JFrame.MAXIMIZED_BOTH : JFrame.NORMAL);
        });
    }

    private void render() {
        Graphics2D g = buf.createGraphics();
        try {
            if (screen != null) screen.render(g);
            float a = fade > 0 ? 1f - fade / (float) FADE : fade < 0 ? -fade / (float) FADE : 0f;
            if (a > 0) {
                g.setColor(new Color(42, 27, 46, Math.min(255, (int) (a * 255))));
                g.fillRect(0, 0, W, H);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            g.dispose();
        }
        BufferStrategy bs = canvas.getBufferStrategy();
        if (bs == null) return;
        try {
            Graphics2D cg = (Graphics2D) bs.getDrawGraphics();
            int cw = canvas.getWidth(), ch = canvas.getHeight();
            double s = Math.min(cw / (double) W, ch / (double) H);
            if (s >= 1) s = Math.floor(s * 2) / 2.0; // passos de meio pixel ficam nitidos o bastante
            int dw = (int) (W * s), dh = (int) (H * s);
            int ox = (cw - dw) / 2, oy = (ch - dh) / 2;
            cg.setColor(new Color(0x2a1b2e));
            cg.fillRect(0, 0, cw, ch);
            cg.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
            cg.drawImage(buf, ox, oy, dw, dh, null);
            cg.dispose();
            bs.show();
            Toolkit.getDefaultToolkit().sync();
        } catch (IllegalStateException ignored) {
        }
    }

    /** Usado pelos testes: um tick sem janela. */
    public void tickOnce() { tick(); }

    /** Usado pelos testes para desenhar sem janela. */
    public static BufferedImage renderOffscreen(Screen s) {
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        s.render(g);
        g.dispose();
        return img;
    }
}

package doce;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.List;

/** Menus: titulo, online, lobby (escolha de personagem), mapa de fases, ajuda e final. */
public final class Screens {
    private Screens() {}

    // ================================================================ sessao
    public static final int LOCAL = 0, HOST = 1, CLIENT = 2;
    public static int mode = LOCAL;
    public static int myChar = Art.MIMI;
    public static int level = 0;
    public static String notice = "";
    public static int noticeT = 0;

    public static int otherChar() { return 1 - myChar; }

    static void toast(String s) { notice = s; noticeT = 260; }

    static Main game() { return Main.game; }
    static Input in() { return Main.game.input; }

    // ================================================================ desenho comum
    static final Color INK = new Color(0x3b2033), PINK = new Color(0xff6f9f), CREAM = new Color(0xfff6e8);
    private static final BufferedImage[] BG = new BufferedImage[Levels.THEMES.length];

    static void bg(Graphics2D g, int theme) {
        theme = Math.floorMod(theme, BG.length);
        if (BG[theme] == null) {
            BG[theme] = new BufferedImage(Main.W, Main.H, BufferedImage.TYPE_INT_RGB);
            Graphics2D b = BG[theme].createGraphics();
            Render.drawBackground(b, Levels.THEMES[theme], 0);
            b.dispose();
        }
        g.drawImage(BG[theme], 0, 0, null);
    }

    /** Chao de bolo decorativo dos menus. */
    private static BufferedImage floorImg;

    static void cakeFloor(Graphics2D g, long t) {
        if (floorImg == null) {
            floorImg = new BufferedImage(Main.W, Main.H, BufferedImage.TYPE_INT_ARGB);
            Graphics2D fg = floorImg.createGraphics();
            cakeFloorRaw(fg);
            fg.dispose();
        }
        g.drawImage(floorImg, 0, 0, null);
    }

    private static void cakeFloorRaw(Graphics2D g) {
        Levels.Theme th = Levels.THEMES[0];
        g.setColor(new Color(th.sponge));
        g.fillRect(0, Main.H - 22, Main.W, 22);
        g.setColor(new Color(th.spongeDark));
        for (int x = 3; x < Main.W; x += 11) g.fillRect(x, Main.H - 12 + (x % 5), 2, 1);
        g.setColor(new Color(th.frost));
        g.fillRect(0, Main.H - 24, Main.W, 5);
        for (int x = 0; x < Main.W; x += 7) g.fillRect(x, Main.H - 19, 2, 2 + (x * 13 % 4));
        for (int x = 4; x < Main.W; x += 9) {
            g.setColor(new Color(Levels.RAINBOW[(x / 9) % 6]));
            g.fillRect(x, Main.H - 23 + (x % 3), 2, 1);
        }
    }

    static void menu(Graphics2D g, String[] items, int sel, int cx, int y, long t) {
        for (int i = 0; i < items.length; i++) {
            int w = Math.max(160, PixelFont.width(items[i]) + 24);
            int x = cx - w / 2, yy = y + i * 19;
            boolean s = i == sel;
            Art.panel(g, x, yy, w, 15, s ? new Color(0xffd6e7) : new Color(255, 255, 255, 200), s ? PINK : INK);
            PixelFont.centered(g, items[i], cx, yy + 4, s ? new Color(0xc2185b) : INK, 1);
            if (s) {
                int bob = (int) (Math.sin(t * 0.2) * 2);
                PixelFont.draw(g, "♥", x - 10 + bob, yy + 4, PINK);
                PixelFont.draw(g, "♥", x + w + 4 - bob, yy + 4, PINK);
            }
        }
    }

    static void drawNotice(Graphics2D g) {
        if (noticeT <= 0 || notice.isEmpty()) return;
        noticeT--;
        int w = Math.min(Main.W - 20, PixelFont.width(notice) + 20);
        Art.panel(g, Main.W / 2 - w / 2, 6, w, 15, new Color(0xfff3c4), INK);
        PixelFont.centered(g, notice, Main.W / 2, 10, INK, 1);
    }

    static void footer(Graphics2D g, String s) {
        PixelFont.centeredOutlined(g, s, Main.W / 2, Main.H - 13, Color.WHITE, INK, 1);
    }

    static void title(Graphics2D g, String s, int y) {
        PixelFont.centeredOutlined(g, s, Main.W / 2, y, Color.WHITE, INK, 2);
    }

    /** Checa conexao; se caiu, volta ao titulo com aviso. Retorna false se caiu. */
    static boolean checkConn() {
        if (mode == LOCAL) return true;
        if (!Net.connected()) {
            Net.closeAll();
            toast("A conexão com o amigo caiu :(");
            game().setScreen(new Title());
            return false;
        }
        return true;
    }

    // ================================================================ titulo
    public static class Title implements Main.Screen {
        int sel = 0;
        long t = 0;
        final String[] items = {"Jogar online (Radmin / LAN)", "Jogar no mesmo PC", "Como jogar", "Sair"};

        @Override public void onEnter() { Sfx.music(0); Net.closeAll(); mode = LOCAL; }

        @Override public void update() {
            t++;
            Input i = in();
            if (i.up()) { sel = (sel + items.length - 1) % items.length; Sfx.play(Sfx.SELECT); }
            if (i.downK()) { sel = (sel + 1) % items.length; Sfx.play(Sfx.SELECT); }
            if (i.confirm()) {
                Sfx.play(Sfx.CONFIRM);
                switch (sel) {
                    case 0: game().setScreen(new Online()); break;
                    case 1: mode = LOCAL; game().setScreen(new LocalSelect()); break;
                    case 2: game().setScreen(new Help(this)); break;
                    default: game().quit();
                }
            }
        }

        @Override public void render(Graphics2D g) {
            bg(g, (int) (t / 600));
            cakeFloor(g, t);
            // personagens grandes
            int b1 = (int) Math.abs(Math.sin(t * 0.07) * 8), b2 = (int) Math.abs(Math.sin(t * 0.07 + 1.4) * 8);
            int f1 = (t / 20) % 6 == 0 ? 1 : (t / 12) % 2 == 0 ? 2 : 3;
            Art.draw(g, Art.frame(Art.MIMI, false, b1 > 4 ? 4 : f1), 26, Main.H - 24 - 64 - b1, 4, false);
            Art.draw(g, Art.frame(Art.BISCOITO, true, b2 > 4 ? 4 : f1), Main.W - 26 - 64, Main.H - 24 - 64 - b2, 4, false);
            // titulo
            int ty = 22 + (int) (Math.sin(t * 0.05) * 2);
            PixelFont.centeredOutlined(g, "MIMI & BISCOITO", Main.W / 2, ty, new Color(0xff6f9f), INK, 4);
            PixelFont.centeredOutlined(g, "UMA AVENTURA DOCE A DOIS", Main.W / 2, ty + 34, Color.WHITE, INK, 1);
            for (int k = 0; k < 7; k++) {
                int hx = (int) ((k * 71 + t * (0.3 + k * 0.05)) % (Main.W + 20)) - 10;
                int hy = 60 + (int) (Math.sin(t * 0.03 + k) * 6) + (k % 3) * 8;
                if (hx > 120 && hx < 360) continue;
                Art.heart(g, hx, hy, new Color(Levels.RAINBOW[k % 6]), 1);
            }
            menu(g, items, sel, Main.W / 2, 92, t);
            footer(g, "M: SOM    F11: TELA CHEIA    F2: FPS    F3: LIMITE DE FPS");
            drawNotice(g);
        }
    }

    // ================================================================ online
    public static class Online implements Main.Screen {
        int sel = 0;
        long t;
        final String[] items = {"Criar sala (eu sou o anfitrião)", "Entrar na sala de um amigo", "Voltar"};

        @Override public void update() {
            t++;
            Input i = in();
            if (i.up()) { sel = (sel + 2) % 3; Sfx.play(Sfx.SELECT); }
            if (i.downK()) { sel = (sel + 1) % 3; Sfx.play(Sfx.SELECT); }
            if (i.back()) { Sfx.play(Sfx.BACK); game().setScreen(new Title()); }
            if (i.confirm()) {
                Sfx.play(Sfx.CONFIRM);
                if (sel == 0) game().setScreen(new HostWait());
                else if (sel == 1) game().setScreen(new Join());
                else game().setScreen(new Title());
            }
        }

        @Override public void render(Graphics2D g) {
            bg(g, 6);
            cakeFloor(g, t);
            title(g, "JOGAR ONLINE", 24);
            Art.panel(g, 40, 50, Main.W - 80, 58, new Color(255, 255, 255, 220), INK);
            String txt = "1) Os dois instalam o Radmin VPN e entram na mesma rede.\n"
                + "2) Um cria a sala. O outro digita o IP do Radmin dele (começa com 26.)\n"
                + "3) Se o Windows perguntar, deixe o Java passar no firewall!";
            int y = 56;
            for (String l : PixelFont.wrap(txt, Main.W - 100)) { PixelFont.draw(g, l, 50, y, INK); y += PixelFont.LINE; }
            menu(g, items, sel, Main.W / 2, 124, t);
            footer(g, "ESC: VOLTAR");
            drawNotice(g);
        }
    }

    // ================================================================ anfitriao esperando
    public static class HostWait implements Main.Screen {
        long t;
        List<String> ips;
        boolean welcomed;

        @Override public void onEnter() {
            Net.host(Save.port);
            ips = Net.localIps();
            mode = HOST;
        }

        @Override public void update() {
            t++;
            if (in().back()) { Sfx.play(Sfx.BACK); Net.closeAll(); game().setScreen(new Online()); return; }
            if (t % 120 == 0) ips = Net.localIps();
            Net.Conn c = Net.conn;
            if (c == null) return;
            if (c.closed) { Net.conn = null; return; }
            byte[] m;
            while ((m = c.poll()) != null) {
                if (m[0] == Net.HELLO) {
                    try {
                        DataInputStream d = Net.reader(m);
                        d.readByte();
                        int v = d.readInt();
                        if (v != Net.VERSION) {
                            c.send(new Net.Msg(Net.REJECT).i(Net.VERSION).bytes());
                            toast("O amigo está com outra versão do jogo!");
                            continue;
                        }
                    } catch (IOException e) { continue; }
                    c.send(new Net.Msg(Net.WELCOME).i(Net.VERSION).bytes());
                    Sfx.play(Sfx.CONFIRM);
                    game().setScreen(new Lobby());
                    return;
                }
            }
        }

        @Override public void render(Graphics2D g) {
            bg(g, 6);
            cakeFloor(g, t);
            title(g, "SUA SALA ESTÁ ABERTA!", 18);
            Art.panel(g, 50, 44, Main.W - 100, 128, new Color(255, 255, 255, 225), INK);
            PixelFont.draw(g, "Passe este IP pro seu amigo:", 62, 52, INK);
            int y = 66;
            for (int i = 0; i < Math.min(4, ips.size()); i++) {
                String ip = ips.get(i);
                boolean rad = ip.contains("Radmin");
                PixelFont.draw(g, ip, 72, y, rad ? new Color(0xc2185b) : new Color(0x7a6a8a), rad ? 2 : 1);
                y += rad ? 20 : 12;
            }
            PixelFont.draw(g, "Porta: " + Save.port, 62, y + 4, INK);
            String dots = ".....".substring(0, (int) (t / 20 % 4));
            PixelFont.draw(g, Net.status + dots, 62, 150, new Color(0x5a8bff));
            int bob = (int) Math.abs(Math.sin(t * 0.1) * 6);
            Art.draw(g, Art.frame(Art.MIMI, false, (t / 10) % 2 == 0 ? 2 : 3), 70, 196 - bob, 3, false);
            Art.draw(g, Art.frame(Art.BISCOITO, true, 0), Main.W - 118, 196, 3, false);
            footer(g, "ESC: FECHAR A SALA");
            drawNotice(g);
        }
    }

    // ================================================================ entrar
    public static class Join implements Main.Screen {
        long t;
        String ip = Save.lastIp;
        boolean trying, helloSent;
        long tryT;

        @Override public void onEnter() { mode = CLIENT; Net.status = ""; }

        @Override public void update() {
            t++;
            Input i = in();
            if (i.pressed(KeyEvent.VK_ESCAPE)) {
                Sfx.play(Sfx.BACK); Net.closeAll(); game().setScreen(new Online()); return;
            }
            if (!trying) {
                for (char ch : i.typed().toCharArray())
                    if ((Character.isDigit(ch) || ch == '.' || ch == ':' || Character.isLetter(ch) || ch == '-') && ip.length() < 40) ip += ch;
                if (i.pressed(KeyEvent.VK_BACK_SPACE) && !ip.isEmpty()) ip = ip.substring(0, ip.length() - 1);
                if (i.pressed(KeyEvent.VK_ENTER) && !ip.trim().isEmpty()) {
                    String host = ip.trim();
                    int port = Save.port;
                    if (host.contains(":")) {
                        try { port = Integer.parseInt(host.substring(host.indexOf(':') + 1)); } catch (Exception ignored) {}
                        host = host.substring(0, host.indexOf(':'));
                    }
                    Save.lastIp = ip.trim();
                    Save.store();
                    Net.join(host, port);
                    trying = true; helloSent = false; tryT = t;
                    Sfx.play(Sfx.CONFIRM);
                }
                return;
            }
            Net.Conn c = Net.conn;
            if (c == null) {
                if (Net.status.startsWith("Não")) { trying = false; Sfx.play(Sfx.BACK); }
                return;
            }
            if (c.closed) { trying = false; Net.conn = null; Net.status = "A sala fechou a conexão."; return; }
            if (!helloSent) { c.send(new Net.Msg(Net.HELLO).i(Net.VERSION).bytes()); helloSent = true; }
            byte[] m;
            while ((m = c.poll()) != null) {
                if (m[0] == Net.WELCOME) { Sfx.play(Sfx.CONFIRM); game().setScreen(new Lobby()); return; }
                if (m[0] == Net.REJECT) { Net.closeAll(); trying = false; Net.status = "Versões diferentes do jogo!"; return; }
            }
            if (t - tryT > 600) { Net.closeAll(); trying = false; Net.status = "O anfitrião não respondeu."; }
        }

        @Override public void render(Graphics2D g) {
            bg(g, 6);
            cakeFloor(g, t);
            title(g, "ENTRAR NA SALA", 24);
            Art.panel(g, 60, 56, Main.W - 120, 96, new Color(255, 255, 255, 225), INK);
            PixelFont.draw(g, "IP do anfitrião (no Radmin começa com 26.):", 72, 66, INK);
            Art.panel(g, 72, 82, Main.W - 144, 22, new Color(0xfff0f6), PINK);
            String cur = ip + (!trying && (t / 20) % 2 == 0 ? "_" : "");
            PixelFont.draw(g, cur, 80, 86, INK, 2);
            String st = trying ? Net.status + ".....".substring(0, (int) (t / 15 % 4)) : Net.status;
            PixelFont.draw(g, st.isEmpty() ? "Digite o IP e aperte ENTER" : st, 72, 116, new Color(0x5a8bff));
            PixelFont.draw(g, "Dica: dá pra usar IP:PORTA se mudar a porta.", 72, 132, new Color(0x8e7aa8));
            footer(g, "ENTER: CONECTAR    ESC: VOLTAR");
            drawNotice(g);
        }
    }

    // ================================================================ lobby online: escolha de personagem
    public static class Lobby implements Main.Screen {
        long t;
        int[] pick = {Art.MIMI, Art.BISCOITO}; // [0]=anfitriao [1]=convidado
        boolean[] ready = new boolean[2];
        String msg = "";
        int msgT;

        @Override public void onEnter() { Sfx.music(0); if (mode == HOST) broadcast(); }

        int me() { return mode == HOST ? 0 : 1; }

        void broadcast() {
            new Net.Msg(Net.LOBBY).b(pick[0]).z(ready[0]).b(pick[1]).z(ready[1]).send();
        }

        @Override public void update() {
            t++;
            if (msgT > 0) msgT--;
            if (!checkConn()) return;
            Input i = in();
            int me = me(), other = 1 - me;
            boolean changed = false;
            if (!ready[me]) {
                if (i.left() || i.right()) { pick[me] = 1 - pick[me]; Sfx.play(Sfx.SELECT); changed = true; }
                if (i.confirm()) {
                    if (ready[other] && pick[other] == pick[me]) {
                        msg = "Seu amigo já escolheu " + Art.NAMES[pick[me]] + "! Troque :)"; msgT = 180; Sfx.play(Sfx.BACK);
                    } else { ready[me] = true; Sfx.play(Sfx.CONFIRM); changed = true; }
                }
                if (i.pressed(KeyEvent.VK_ESCAPE)) { Sfx.play(Sfx.BACK); Net.closeAll(); game().setScreen(new Title()); return; }
            } else if (i.back()) { ready[me] = false; Sfx.play(Sfx.BACK); changed = true; }

            if (changed) {
                if (mode == HOST) broadcast();
                else new Net.Msg(Net.LOBBY).b(pick[1]).z(ready[1]).send();
            }
            byte[] m;
            while ((m = Net.conn.poll()) != null) {
                try {
                    DataInputStream d = Net.reader(m);
                    byte type = d.readByte();
                    if (type == Net.BYE) { Net.closeAll(); toast("Seu amigo saiu da sala."); game().setScreen(new Title()); return; }
                    if (mode == HOST && type == Net.LOBBY) {
                        int p = d.readByte(); boolean r = d.readBoolean();
                        pick[1] = p; ready[1] = r;
                        if (ready[0] && ready[1] && pick[0] == pick[1]) ready[1] = false;
                        broadcast();
                    } else if (mode == CLIENT && type == Net.LOBBY) {
                        pick[0] = d.readByte(); ready[0] = d.readBoolean();
                        int p1 = d.readByte(); boolean r1 = d.readBoolean();
                        if (ready[1] && !r1) { msg = "Esse personagem já foi escolhido!"; msgT = 180; }
                        pick[1] = p1; ready[1] = r1;
                    } else if (mode == CLIENT && type == Net.MAP) {
                        myChar = pick[1];
                        LevelMap lm = new LevelMap();
                        lm.sel = d.readByte(); lm.clientUnlocked = d.readByte();
                        game().setScreen(lm);
                        return;
                    }
                } catch (IOException ignored) {}
            }
            if (mode == HOST && ready[0] && ready[1] && pick[0] != pick[1] && t > 10) {
                myChar = pick[0];
                LevelMap lm = new LevelMap();
                lm.sel = Math.min(Save.unlocked - 1, level);
                game().setScreen(lm);
                new Net.Msg(Net.MAP).b(lm.sel).b(Save.unlocked).send();
            }
        }

        @Override public void render(Graphics2D g) {
            bg(g, 1);
            cakeFloor(g, t);
            title(g, "QUEM VOCÊ VAI SER?", 14);
            int me = me();
            for (int ch = 0; ch < 2; ch++) {
                int cx = ch == 0 ? 130 : Main.W - 130;
                boolean mine = pick[me] == ch, theirs = pick[1 - me] == ch;
                Color border = mine ? PINK : theirs ? new Color(0x5a8bff) : INK;
                Art.panel(g, cx - 92, 40, 184, 186, new Color(255, 255, 255, 220), border);
                int bob = mine ? (int) Math.abs(Math.sin(t * 0.12) * 5) : 0;
                int fr = mine ? ((t / 9) % 2 == 0 ? 2 : 3) : ((t / 40) % 5 == 0 ? 1 : 0);
                Art.draw(g, Art.frame(ch, ch == 1, fr), cx - 40, 64 - bob, 5, false);
                PixelFont.centered(g, Art.NAMES[ch].toUpperCase(), cx, 152, Art.CHAR_COLOR[ch], 2);
                int y = 172;
                for (String l : PixelFont.wrap(Art.DESC[ch], 164)) { PixelFont.centered(g, l, cx, y, INK, 1); y += 10; }
                int ty = 46;
                if (mine) {
                    PixelFont.draw(g, ready[me] ? "VOCÊ ♥" : "VOCÊ", cx - 86, ty, PINK);
                }
                if (theirs) {
                    String s = ready[1 - me] ? "AMIGO PRONTO" : "AMIGO";
                    PixelFont.draw(g, s, cx + 86 - PixelFont.width(s), ty, new Color(0x5a8bff));
                }
                if (mine && ready[me]) PixelFont.centeredOutlined(g, "PRONTO!", cx, 132, new Color(0x8be06a), INK, 2);
            }
            PixelFont.centeredOutlined(g, "←  →", Main.W / 2, 120, Color.WHITE, INK, 2);
            String help = ready[me] ? "ESPERANDO O AMIGO...  (ESC: TROCAR)" : "← →: ESCOLHER    ENTER: CONFIRMAR    ESC: SAIR";
            footer(g, help);
            if (msgT > 0) {
                Art.panel(g, 90, 230, Main.W - 180, 15, new Color(0xfff3c4), INK);
                PixelFont.centered(g, msg, Main.W / 2, 234, INK, 1);
            }
            drawNotice(g);
        }
    }

    // ================================================================ escolha local (mesmo PC)
    public static class LocalSelect implements Main.Screen {
        long t;
        int p1 = Art.MIMI;

        @Override public void update() {
            t++;
            Input i = in();
            if (i.left() || i.right()) { p1 = 1 - p1; Sfx.play(Sfx.SELECT); }
            if (i.back()) { Sfx.play(Sfx.BACK); game().setScreen(new Title()); }
            if (i.confirm()) {
                Sfx.play(Sfx.CONFIRM);
                mode = LOCAL;
                myChar = p1;
                LevelMap lm = new LevelMap();
                lm.sel = Math.min(Save.unlocked - 1, level);
                game().setScreen(lm);
            }
        }

        @Override public void render(Graphics2D g) {
            bg(g, 0);
            cakeFloor(g, t);
            title(g, "DOIS NO MESMO TECLADO", 14);
            for (int ch = 0; ch < 2; ch++) {
                int cx = ch == 0 ? 130 : Main.W - 130;
                boolean j1 = p1 == ch;
                Art.panel(g, cx - 92, 40, 184, 180, new Color(255, 255, 255, 220), j1 ? PINK : new Color(0x5a8bff));
                int bob = (int) Math.abs(Math.sin(t * 0.12 + ch) * 4);
                Art.draw(g, Art.frame(ch, ch == 1, (t / 9) % 2 == 0 ? 2 : 3), cx - 40, 64 - bob, 5, false);
                PixelFont.centered(g, Art.NAMES[ch].toUpperCase(), cx, 152, Art.CHAR_COLOR[ch], 2);
                PixelFont.centered(g, j1 ? "JOGADOR 1: W A S D" : "JOGADOR 2: SETAS", cx, 174, INK, 1);
                PixelFont.centered(g, j1 ? "S = ALAVANCA  1-4 = EMOJI" : "↓ = ALAVANCA  7-0 = EMOJI", cx, 188, new Color(0x8e7aa8), 1);
            }
            PixelFont.centeredOutlined(g, "←  →", Main.W / 2, 120, Color.WHITE, INK, 2);
            footer(g, "← →: TROCAR    ENTER: CONTINUAR    ESC: VOLTAR");
            drawNotice(g);
        }
    }

    // ================================================================ mapa de fases
    public static class LevelMap implements Main.Screen {
        long t;
        int sel = 0;
        int clientUnlocked = 1;

        int unlocked() { return mode == CLIENT ? clientUnlocked : Save.unlocked; }

        @Override public void onEnter() { Sfx.music(0); }

        @Override public void update() {
            t++;
            if (!checkConn()) return;
            Input i = in();
            if (mode != CLIENT) {
                int old = sel;
                if (i.left()) sel = Math.max(0, sel - 1);
                if (i.right()) sel = Math.min(Levels.count() - 1, sel + 1);
                if (i.up()) sel = Math.max(0, sel - 5);
                if (i.downK()) sel = Math.min(Levels.count() - 1, sel + 5);
                if (i.pressed(KeyEvent.VK_F9)) { Save.unlocked = Levels.count(); Save.store(); toast("Todas as fases liberadas!"); }
                if (sel >= unlocked()) sel = old;
                if (sel != old) Sfx.play(Sfx.SELECT);
                if (sel != old || i.pressed(KeyEvent.VK_F9)) new Net.Msg(Net.MAP).b(sel).b(unlocked()).send();
                if (i.confirm()) {
                    Sfx.play(Sfx.CONFIRM);
                    level = sel;
                    if (mode == HOST) new Net.Msg(Net.START).b(sel).send();
                    game().setScreen(new GameScreen(sel));
                    return;
                }
                if (i.back()) {
                    Sfx.play(Sfx.BACK);
                    if (mode == HOST) { new Net.Msg(Net.TO_LOBBY).send(); game().setScreen(new Lobby()); }
                    else game().setScreen(new LocalSelect());
                    return;
                }
            } else if (i.pressed(KeyEvent.VK_ESCAPE)) {
                Sfx.play(Sfx.BACK); Net.closeAll(); game().setScreen(new Title()); return;
            }
            if (mode != LOCAL) {
                byte[] m;
                while (Net.conn != null && (m = Net.conn.poll()) != null) {
                    try {
                        DataInputStream d = Net.reader(m);
                        byte type = d.readByte();
                        if (type == Net.BYE) { Net.closeAll(); toast("Seu amigo saiu."); game().setScreen(new Title()); return; }
                        if (mode == CLIENT) {
                            if (type == Net.MAP) { int s = d.readByte(); if (s != sel) Sfx.play(Sfx.SELECT); sel = s; clientUnlocked = d.readByte(); }
                            else if (type == Net.START) { level = d.readByte(); game().setScreen(new GameScreen(level)); return; }
                            else if (type == Net.TO_LOBBY) { game().setScreen(new Lobby()); return; }
                        }
                    } catch (IOException ignored) {}
                }
            }
        }

        @Override public void render(Graphics2D g) {
            Levels.Def d = Levels.get(sel);
            bg(g, d.theme);
            cakeFloor(g, t);
            title(g, "MAPA DE FASES", 10);
            for (int k = 0; k < Levels.count(); k++) {
                int col = k % 5, row = k / 5;
                int x = 28 + col * 87, y = 36 + row * 66;
                boolean locked = k >= unlocked(), s = k == sel;
                Levels.Theme th = Levels.THEMES[Levels.get(k).theme];
                Art.panel(g, x, y + (s ? -2 : 0), 78, 58, locked ? new Color(0xb9b0c8) : new Color(th.sponge), s ? PINK : INK);
                if (!locked) {
                    g.setColor(new Color(th.frost));
                    g.fillRect(x + 2, y + 1 + (s ? -2 : 0), 74, 6);
                    for (int q = 0; q < 74; q += 6) g.fillRect(x + 2 + q, y + 7 + (s ? -2 : 0), 2, 2 + (q % 3));
                }
                int yy = y + (s ? -2 : 0);
                PixelFont.centeredOutlined(g, "" + (k + 1), x + 39, yy + 14, Color.WHITE, INK, 2);
                if (locked) PixelFont.centered(g, "TRANCADA", x + 39, yy + 34, INK, 1);
                else {
                    int hearts = Save.best[k];
                    for (int h = 0; h < 3; h++) Art.heart(g, x + 22 + h * 12, yy + 34, h < hearts ? PINK : new Color(255, 255, 255, 140), 1);
                }
                if (s) {
                    int bob = (int) (Math.sin(t * 0.2) * 2);
                    Art.draw(g, Art.frame(myChar, false, (t / 9) % 2 == 0 ? 2 : 3), x + 4, yy + 38 + bob - 16, 1, false);
                }
            }
            Art.panel(g, 40, 176, Main.W - 80, 50, new Color(255, 255, 255, 230), INK);
            PixelFont.centered(g, (sel + 1) + ". " + d.name.toUpperCase(), Main.W / 2, 183, new Color(0xc2185b), 2);
            PixelFont.centered(g, "NOVIDADE: " + d.mechanic.toUpperCase(), Main.W / 2, 202, INK, 1);
            int bt = Save.bestTime[sel];
            String rec = bt > 0 ? String.format("RECORDE %d:%02d", bt / 3600, (bt / 60) % 60) : "TEMPO IDEAL " + (d.par / 60) + ":" + String.format("%02d", d.par % 60);
            PixelFont.centered(g, rec, Main.W / 2, 214, new Color(0x8e7aa8), 1);
            footer(g, mode == CLIENT ? "O ANFITRIÃO ESCOLHE A FASE...   ESC: SAIR" : "SETAS: ESCOLHER   ENTER: JOGAR   ESC: VOLTAR");
            drawNotice(g);
        }
    }

    // ================================================================ como jogar
    public static class Help implements Main.Screen {
        final Main.Screen back;
        long t;
        int page = 0;
        static final String[][] PAGES = {
            {"CONTROLES",
                "ONLINE: SETAS ou WASD andam, ↑/W/ESPAÇO pula, ↓/S usa alavanca. Teclas 1 a 4 mandam emojis pro amigo (♥ ! ? ★).",
                "MESMO PC: Jogador 1 usa W A S D (emojis 1-4). Jogador 2 usa as SETAS (emojis 7-0).",
                "ESC pausa. M liga/desliga o som. F11 tela cheia. F2 mostra o FPS, F3 muda o limite de FPS e F4 troca o desenho (suave ou clássico, mais leve)."},
            {"REGRAS DOCES",
                "A Mimi nada na geleia ROSA. O Biscoito mergulha na calda de CHOCOLATE. A gosma VERDE não é amiga de ninguém!",
                "Pegue os morangos (Mimi), os cookies (Biscoito) e as estrelas (qualquer um).",
                "A fase termina quando os dois estão na frente das suas portas."},
            {"TRABALHO EM EQUIPE",
                "Botões só funcionam enquanto alguém (ou uma caixa) está em cima. Alavancas ficam ligadas.",
                "PEZINHO: suba na cabeça do amigo pra alcançar lugares altos!",
                "Cores iguais = ligados: o botão amarelo mexe no elevador amarelo."},
            {"MECÂNICAS NOVAS",
                "Ventiladores sopram pra cima. Gelo escorrega. Gelatina quica alto. Biscoito crocante quebra.",
                "Esteiras empurram. Portais levam você (e caixas!) longe. Cortinas rosa só a Mimi atravessa; as marrons só o Biscoito.",
                "Esferas roxas invertem a gravidade. No escuro, acenda as lanternas!"},
        };

        Help(Main.Screen back) { this.back = back; }

        @Override public void update() {
            t++;
            Input i = in();
            if (i.left()) { page = Math.max(0, page - 1); Sfx.play(Sfx.SELECT); }
            if (i.right() || i.confirm()) {
                if (page == PAGES.length - 1 && i.confirm()) { game().setScreen(back); return; }
                page = Math.min(PAGES.length - 1, page + 1); Sfx.play(Sfx.SELECT);
            }
            if (i.back()) { Sfx.play(Sfx.BACK); game().setScreen(back); }
        }

        @Override public void render(Graphics2D g) {
            bg(g, 3);
            cakeFloor(g, t);
            String[] p = PAGES[page];
            title(g, p[0], 16);
            Art.panel(g, 30, 42, Main.W - 60, 170, new Color(255, 255, 255, 230), INK);
            int y = 52;
            for (int k = 1; k < p.length; k++) {
                for (String l : PixelFont.wrap(p[k], Main.W - 84)) { PixelFont.draw(g, l, 42, y, INK); y += PixelFont.LINE; }
                y += 8;
            }
            if (page == 0) {
                Art.draw(g, Art.frame(Art.MIMI, false, (t / 9) % 2 == 0 ? 2 : 3), 150, 170, 2, false);
                Art.draw(g, Art.frame(Art.BISCOITO, true, (t / 9) % 2 == 0 ? 3 : 2), 300, 170, 2, false);
            }
            if (page == 1) {
                g.drawImage(Art.GEM_MIMI, 180, 180, 18, 18, null);
                g.drawImage(Art.GEM_BIS, 230, 180, 18, 18, null);
                g.drawImage(Art.STAR, 280, 180, 18, 18, null);
            }
            footer(g, "PÁGINA " + (page + 1) + "/" + PAGES.length + "    ← →: VIRAR    ESC: VOLTAR");
        }
    }

    // ================================================================ final
    public static class Ending implements Main.Screen {
        long t;

        @Override public void onEnter() { Sfx.music(0); Sfx.play(Sfx.WIN); }

        @Override public void update() {
            t++;
            if (t > 60 && in().confirm()) {
                if (mode == LOCAL) game().setScreen(new Title());
                else {
                    if (mode == HOST) {
                        LevelMap lm = new LevelMap();
                        lm.sel = Levels.count() - 1;
                        new Net.Msg(Net.MAP).b(lm.sel).b(Save.unlocked).send();
                        game().setScreen(lm);
                    }
                }
            }
            if (mode == CLIENT) {
                if (!checkConn()) return;
                byte[] m;
                while ((m = Net.conn.poll()) != null) {
                    if (m[0] == Net.MAP) {
                        LevelMap lm = new LevelMap();
                        try { DataInputStream d = Net.reader(m); d.readByte(); lm.sel = d.readByte(); lm.clientUnlocked = d.readByte(); } catch (IOException ignored) {}
                        game().setScreen(lm);
                        return;
                    }
                    if (m[0] == Net.BYE) { Net.closeAll(); game().setScreen(new Title()); return; }
                }
            }
        }

        @Override public void render(Graphics2D g) {
            bg(g, 9);
            cakeFloor(g, t);
            for (int k = 0; k < 18; k++) {
                int x = (int) ((k * 53 + t * (0.6 + (k % 4) * 0.2)) % Main.W);
                int y = (int) ((k * 37 + t * (0.8 + (k % 3) * 0.3)) % Main.H);
                g.setColor(new Color(Levels.RAINBOW[k % 6]));
                g.fillRect(x, y, 2, 3);
            }
            PixelFont.centeredOutlined(g, "VOCÊS CONSEGUIRAM!", Main.W / 2, 26, new Color(0xffe36e), INK, 3);
            PixelFont.centeredOutlined(g, "O castelo do bolo gigante é de vocês!", Main.W / 2, 60, Color.WHITE, INK, 1);
            int total = 0;
            for (int k = 0; k < Levels.count(); k++) total += Save.best[k];
            PixelFont.centeredOutlined(g, "♥ " + total + " / " + (Levels.count() * 3) + " CORAÇÕES", Main.W / 2, 76, PINK, INK, 1);
            int j1 = (int) Math.abs(Math.sin(t * 0.15) * 14), j2 = (int) Math.abs(Math.sin(t * 0.15 + 1.5) * 14);
            Art.draw(g, Art.frame(Art.MIMI, (t / 40) % 2 == 0, j1 > 6 ? 4 : 0), 150, 150 - j1, 4, false);
            Art.draw(g, Art.frame(Art.BISCOITO, (t / 40) % 2 == 1, j2 > 6 ? 4 : 0), 266, 150 - j2, 4, false);
            Art.heart(g, 232, 130 - (int) (t / 3 % 20), PINK, 2);
            footer(g, mode == CLIENT ? "ESPERANDO O ANFITRIÃO..." : "ENTER: CONTINUAR");
        }
    }
}

package doce;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.*;

/** Uma fase em andamento: mapa, objetos, fisica e regras. O host simula; o cliente so recebe o estado. */
public class World {
    public static final int TS = 16, COLS = 30, ROWS = 17;
    public static final int EMPTY = 0, SOLID = 1, ONEWAY = 2, ICE = 3, CONV_L = 4, CONV_R = 5, BOUNCE = 6,
        POOL_J = 7, POOL_C = 8, POOL_G = 9, CURT_P = 10, CURT_Q = 11;
    public static final int POOL_TOP = 6;
    public static final int PLAY = 0, DEAD = 1, DOORS = 2, DONE = 3;
    public static final int P_SPARK = 1, P_PUFF0 = 2, P_PUFF1 = 3, P_DUST = 4, P_HEARTS = 5, P_SWIRL = 6, P_CRUMBS = 7, P_FLIP = 8;

    public final int levelIndex;
    public final Levels.Def def;
    public final int[][] tiles = new int[ROWS][COLS];
    public final List<Ents.Ent> ents = new ArrayList<>();
    public final List<Ents.Solid> solids = new ArrayList<>();
    public final List<Ents.Button> buttons = new ArrayList<>();
    public final List<Ents.Lever> levers = new ArrayList<>();
    public final List<Ents.Fan> fans = new ArrayList<>();
    public final List<Ents.Portal> portals = new ArrayList<>();
    public final List<Ents.Orb> orbs = new ArrayList<>();
    public final List<Ents.Lantern> lanterns = new ArrayList<>();
    public final List<Ents.Gem> gems = new ArrayList<>();
    public final List<Ents.Door> doors = new ArrayList<>();
    public final List<Ents.Text> texts = new ArrayList<>();
    public final List<Box> boxes = new ArrayList<>();
    public final Player[] players = new Player[2];
    public final boolean[] chan = new boolean[26];
    public final int[] chanColor = new int[26];
    public int phase = PLAY, phaseT = 0, time = 0, gemsTotal = 0, gemsGot = 0;
    public int deathWho = -1, deathMsg = 0;
    public long cosmeticTick = 0;
    public final List<int[]> events = new ArrayList<>();
    public final List<Particle> particles = new ArrayList<>();
    private final Random rnd = new Random();

    public World(int levelIndex) {
        this.levelIndex = levelIndex;
        this.def = Levels.get(levelIndex);
        parse();
    }

    // =====================================================================
    // Leitura do mapa
    // =====================================================================
    private static int ch(String s) { return s.equals("-") ? -1 : Character.toUpperCase(s.charAt(0)) - 'A'; }

    private void parse() {
        Map<Character, String> leg = new HashMap<>();
        for (String l : def.legend) leg.put(l.charAt(0), l.substring(1).trim());
        char[][] m = new char[ROWS][COLS];
        for (int y = 0; y < ROWS; y++)
            for (int x = 0; x < COLS; x++) {
                String row = y < def.map.length ? def.map[y] : "";
                m[y][x] = x < row.length() ? row.charAt(x) : ' ';
            }
        boolean[][] used = new boolean[ROWS][COLS];
        for (int ty = 0; ty < ROWS; ty++) {
            for (int tx = 0; tx < COLS; tx++) {
                if (used[ty][tx]) continue;
                char c = m[ty][tx];
                int px = tx * TS, py = ty * TS;
                used[ty][tx] = true;
                if (leg.containsKey(c)) { legendObject(m, used, tx, ty, c, leg.get(c)); continue; }
                switch (c) {
                    case '#': tiles[ty][tx] = SOLID; break;
                    case '-': tiles[ty][tx] = ONEWAY; break;
                    case 'I': tiles[ty][tx] = ICE; break;
                    case '<': tiles[ty][tx] = CONV_L; break;
                    case '>': tiles[ty][tx] = CONV_R; break;
                    case 'T': tiles[ty][tx] = BOUNCE; break;
                    case 'J': tiles[ty][tx] = POOL_J; break;
                    case 'C': tiles[ty][tx] = POOL_C; break;
                    case 'G': tiles[ty][tx] = POOL_G; break;
                    case 'P': tiles[ty][tx] = CURT_P; break;
                    case 'Q': tiles[ty][tx] = CURT_Q; break;
                    case '~': add(new Ents.Crumble(px, py)); break;
                    case 'm': players[Art.MIMI] = new Player(this, Art.MIMI, px + 3, py + 2); break;
                    case 'b': players[Art.BISCOITO] = new Player(this, Art.BISCOITO, px + 3, py + 2); break;
                    case 'M': add(new Ents.Door(px, py, Art.MIMI)); break;
                    case 'B': add(new Ents.Door(px, py, Art.BISCOITO)); break;
                    case 'r': add(new Ents.Gem(px, py, 0)); break;
                    case 'c': add(new Ents.Gem(px, py, 1)); break;
                    case '*': add(new Ents.Gem(px, py, 2)); break;
                    case 'X': boxes.add(new Box(this, px, py)); break;
                    case '%': add(new Ents.Orb(px, py)); break;
                    case 'L': add(new Ents.Lantern(px, py)); break;
                    case 'F': tiles[ty][tx] = SOLID; add(new Ents.Fan(px, py, TS, -1)); break;
                    default: break;
                }
            }
        }
        for (Ents.Portal p : portals)
            for (Ents.Portal q : portals)
                if (p != q && p.id == q.id) p.other = q;
        for (Ents.Fan f : fans) computeFan(f, f.zoneTop == 0 ? 8 : f.zoneTop);
        for (Ents.Button b : buttons) {
            int bx = b.x / TS, by = b.y / TS;
            b.ceiling = isSolidTile(tile(bx, by - 1)) && !isSolidTile(tile(bx, by + 1));
        }
        gemsTotal = gems.size();
        if (players[0] == null) players[0] = new Player(this, 0, 32, 32);
        if (players[1] == null) players[1] = new Player(this, 1, 64, 32);
        // cada canal usado na fase ganha uma cor diferente (na ordem em que aparece)
        int[] pal = {0xffd23f, 0xb48cff, 0x5ad1e6, 0xff9a3c, 0x6f9bff, 0x8be06a, 0xe85d5d, 0xff6fb5};
        boolean[] seen = new boolean[26];
        int next = 0;
        for (int i = 0; i < 26; i++) chanColor[i] = pal[i % pal.length];
        savePrev();
        for (Ents.Ent e : ents) {
            int c = -1;
            if (e instanceof Ents.Button) c = ((Ents.Button) e).ch;
            else if (e instanceof Ents.Lever) c = ((Ents.Lever) e).ch;
            else if (e instanceof Ents.Elevator) c = ((Ents.Elevator) e).ch;
            else if (e instanceof Ents.Gate) c = ((Ents.Gate) e).ch;
            else if (e instanceof Ents.Fan) c = ((Ents.Fan) e).ch;
            if (c >= 0 && !seen[c]) { seen[c] = true; chanColor[c] = pal[next++ % pal.length]; }
        }
    }

    private void computeFan(Ents.Fan f, int maxH) {
        int tx = f.x / TS, ty = f.y / TS;
        int top = ty;
        for (int i = 1; i <= maxH; i++) {
            int yy = ty - i;
            if (yy < 0 || isSolidTile(tiles[yy][tx]) || isSolidTile(tiles[yy][(f.x + f.w - 1) / TS])) break;
            top = yy;
        }
        f.zoneTop = top * TS;
    }

    private static boolean isSolidTile(int t) {
        return t == SOLID || t == ICE || t == CONV_L || t == CONV_R || t == BOUNCE;
    }

    private void legendObject(char[][] m, boolean[][] used, int tx, int ty, char c, String spec) {
        String[] p = spec.split("\\s+");
        String kind = p[0];
        boolean rect = kind.equals("gate") || kind.equals("gateinv");
        boolean horiz = rect || kind.equals("elev") || kind.equals("mover") || kind.equals("fan");
        int w = 1, h = 1;
        if (horiz) {
            while (tx + w < COLS && m[ty][tx + w] == c && !used[ty][tx + w]) w++;
            if (rect) {
                outer:
                while (ty + h < ROWS) {
                    for (int i = 0; i < w; i++) if (m[ty + h][tx + i] != c || used[ty + h][tx + i]) break outer;
                    h++;
                }
            }
            for (int yy = 0; yy < h; yy++) for (int xx = 0; xx < w; xx++) used[ty + yy][tx + xx] = true;
        }
        int px = tx * TS, py = ty * TS;
        switch (kind) {
            case "button": add(new Ents.Button(px, py, ch(p[1]), -1, 0)); break;
            case "pbutton": add(new Ents.Button(px, py, ch(p[1]), Art.MIMI, 0)); break;
            case "cbutton": add(new Ents.Button(px, py, ch(p[1]), Art.BISCOITO, 0)); break;
            case "tbutton": add(new Ents.Button(px, py, ch(p[1]), -1, Integer.parseInt(p[2]))); break;
            case "lever": add(new Ents.Lever(px, py, ch(p[1]), p.length > 2 && p[2].equals("on"))); break;
            case "elev": add(new Ents.Elevator(px, py, w * TS, ch(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3]), false)); break;
            case "mover": add(new Ents.Elevator(px, py, w * TS, p.length > 3 ? ch(p[3]) : -1, Integer.parseInt(p[1]), Integer.parseInt(p[2]), true)); break;
            case "gate": add(new Ents.Gate(px, py, w * TS, h * TS, ch(p[1]), false)); break;
            case "gateinv": add(new Ents.Gate(px, py, w * TS, h * TS, ch(p[1]), true)); break;
            case "fan": {
                for (int i = 0; i < w; i++) tiles[ty][tx + i] = SOLID;
                Ents.Fan f = new Ents.Fan(px, py, w * TS, ch(p[1]));
                f.zoneTop = p.length > 2 ? Integer.parseInt(p[2]) : 8; // altura temporaria
                add(f);
                break;
            }
            case "portal": add(new Ents.Portal(px, py, Integer.parseInt(p[1]))); break;
            case "text": add(new Ents.Text(px, py, spec.substring(4).trim())); break;
            default: System.err.println("Legenda desconhecida: " + spec);
        }
    }

    private void add(Ents.Ent e) {
        ents.add(e);
        if (e instanceof Ents.Solid) solids.add((Ents.Solid) e);
        if (e instanceof Ents.Button) buttons.add((Ents.Button) e);
        if (e instanceof Ents.Lever) levers.add((Ents.Lever) e);
        if (e instanceof Ents.Fan) fans.add((Ents.Fan) e);
        if (e instanceof Ents.Portal) portals.add((Ents.Portal) e);
        if (e instanceof Ents.Orb) orbs.add((Ents.Orb) e);
        if (e instanceof Ents.Lantern) lanterns.add((Ents.Lantern) e);
        if (e instanceof Ents.Gem) gems.add((Ents.Gem) e);
        if (e instanceof Ents.Door) doors.add((Ents.Door) e);
        if (e instanceof Ents.Text) texts.add((Ents.Text) e);
    }

    public int tile(int tx, int ty) {
        if (tx < 0 || tx >= COLS) return SOLID;
        if (ty < 0) return SOLID;
        if (ty >= ROWS) return EMPTY;
        return tiles[ty][tx];
    }

    // =====================================================================
    // Regras
    // =====================================================================
    /** bits[personagem] = controles daquele personagem neste tick. */
    /** Guarda as posicoes atuais como "anteriores" (o desenho interpola entre as duas). */
    public void savePrev() {
        for (Player p : players) { p.px = p.x; p.py = p.y; }
        for (Box b : boxes) { b.px = b.x; b.py = b.y; }
        for (Ents.Solid s : solids) {
            if (s instanceof Ents.Elevator) { Ents.Elevator e = (Ents.Elevator) s; e.px = e.x; e.py = e.y; }
            else if (s instanceof Ents.Gate) { Ents.Gate gt = (Ents.Gate) s; gt.ph = gt.h; }
        }
    }

    public void update(int[] bits) {
        savePrev();
        if (phase == DONE) return;
        if (phase == PLAY) time++;
        for (Ents.Button b : buttons) b.update(this);
        for (Ents.Lever l : levers) l.update(this);
        Arrays.fill(chan, false);
        for (Ents.Button b : buttons) if (b.ch >= 0 && b.active()) chan[b.ch] = true;
        for (Ents.Lever l : levers) if (l.ch >= 0 && l.on) chan[l.ch] = true;
        for (Ents.Ent e : ents)
            if (!(e instanceof Ents.Button) && !(e instanceof Ents.Lever)) e.update(this);

        for (Player p : players) {
            if (phase == PLAY) p.update(bits[p.ch]);
            else p.update(0);
        }
        for (Box b : boxes) b.update();

        if (phase == PLAY) interactions();
        if (phase == DEAD) {
            phaseT--;
        } else if (phase == DOORS) {
            phaseT++;
            for (Ents.Door d : doors) if (d.open < 16 && phaseT % 2 == 0) d.open++;
            if (phaseT == 70) {
                phase = DONE;
                event(Sfx.WIN, COLS * TS / 2, ROWS * TS / 2, 0);
            }
        }
    }

    /** O host deve reiniciar a fase? */
    public boolean wantsRestart() { return phase == DEAD && phaseT <= 0; }

    private void interactions() {
        for (Player p : players) {
            if (!p.alive) continue;
            // poças
            int x0 = (p.x + 2) / TS, x1 = (p.x + p.w - 3) / TS;
            int y0 = Math.floorDiv(p.y, TS), y1 = Math.floorDiv(p.y + p.h - 1, TS);
            for (int ty = y0; ty <= y1; ty++)
                for (int tx = x0; tx <= x1; tx++) {
                    int t = tile(tx, ty);
                    if (t != POOL_J && t != POOL_C && t != POOL_G) continue;
                    int ly = ty * TS + 2;
                    if (p.y + p.h > ly && p.y < ty * TS + POOL_TOP + 1) {
                        boolean safe = (t == POOL_J && p.ch == Art.MIMI) || (t == POOL_C && p.ch == Art.BISCOITO);
                        if (!safe) { kill(p); }
                    }
                }
            if (!p.alive) continue;
            if (p.y > ROWS * TS + 24 || p.y < -48) { kill(p); continue; }
            // doces
            for (Ents.Gem g : gems) {
                if (g.got || !(g.kind == 2 || g.kind == p.ch)) continue;
                if (g.overlaps(p.x, p.y, p.w, p.h)) {
                    g.got = true;
                    gemsGot++;
                    event(g.kind == 2 ? Sfx.STAR : Sfx.GEM, g.x + 5, g.y + 5, P_SPARK);
                }
            }
            // alavancas
            if (p.actPressed)
                for (Ents.Lever l : levers)
                    if (l.overlaps(p.x, p.y, p.w, p.h)) {
                        l.on = !l.on;
                        l.anim = 10;
                        event(Sfx.LEVER, l.x + 8, l.y + 10, 0);
                        break;
                    }
            // lanternas
            for (Ents.Lantern l : lanterns)
                if (!l.lit && l.overlaps(p.x, p.y, p.w, p.h)) { l.lit = true; event(Sfx.CHIME, l.x + 5, l.y + 4, P_SPARK); }
            // orbes de gravidade
            boolean inOrb = false;
            for (Ents.Orb o : orbs)
                if (o.overlaps(p.x, p.y, p.w, p.h)) {
                    inOrb = true;
                    if (!p.inOrb) {
                        p.g = -p.g;
                        p.vy = 0.6f * p.g;
                        event(Sfx.FLIP, o.x + 6, o.y + 6, P_FLIP);
                    }
                }
            p.inOrb = inOrb;
        }
        // portais (jogadores e caixas)
        for (Actor a : actors()) {
            boolean inP = false;
            for (Ents.Portal pt : portals) {
                int cx = a.x + a.w / 2, cy = a.y + a.h / 2;
                if (cx >= pt.x && cx < pt.x + pt.w && cy >= pt.y && cy < pt.y + pt.h) {
                    inP = true;
                    if (!a.inPortal && pt.other != null) {
                        int nx = pt.other.x + TS / 2 - a.w / 2;
                        int ny = pt.other.y + TS - a.h - (a.g < 0 ? TS - a.h : 0);
                        if (!collides(a, nx, ny, 0)) {
                            event(Sfx.PORTAL, pt.x + 8, pt.y + 8, P_SWIRL);
                            a.x = nx; a.y = ny;
                            event(-1, pt.other.x + 8, pt.other.y + 8, P_SWIRL);
                        }
                    }
                }
            }
            a.inPortal = inP;
        }
        // portas
        boolean all = true;
        for (Ents.Door d : doors) {
            Player p = players[d.kind];
            int cx = p.x + p.w / 2;
            d.occupied = p.alive && cx >= d.x + 2 && cx <= d.x + d.w - 2 && p.y + p.h > d.y + 8 && p.y < d.y + d.h && p.onGround;
            if (!d.occupied) all = false;
        }
        if (all && doors.size() >= 2) {
            phase = DOORS;
            phaseT = 0;
            event(Sfx.DOOR, COLS * TS / 2, ROWS * TS / 2, 0);
            for (Ents.Door d : doors) event(-1, d.x + 8, d.y + 8, P_HEARTS);
        }
    }

    public void kill(Player p) {
        if (!p.alive || phase != PLAY) return;
        p.alive = false;
        phase = DEAD;
        phaseT = 110;
        deathWho = p.ch;
        deathMsg = (int) (time % 6);
        event(Sfx.DIE, p.x + p.w / 2, p.y + p.h / 2, p.ch == 0 ? P_PUFF0 : P_PUFF1);
    }

    public void event(int sfx, int x, int y, int particle) {
        events.add(new int[]{sfx, x, y, particle});
    }

    public int hearts() {
        int h = 1;
        if (gemsGot >= gemsTotal) h++;
        if (time <= def.par * 60) h++;
        return h;
    }

    // =====================================================================
    // Colisao
    // =====================================================================
    private final List<Actor> actorCache = new ArrayList<>();

    public List<Actor> actors() {
        actorCache.clear();
        for (Player p : players) if (p.alive) actorCache.add(p);
        actorCache.addAll(boxes);
        return actorCache;
    }

    static boolean over(int ax, int ay, int aw, int ah, int bx, int by, int bw, int bh) {
        return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
    }

    /** O retangulo do ator na posicao (nx,ny) bate em algo? dy = direcao do movimento vertical. */
    public boolean collides(Actor a, int nx, int ny, int dy) {
        if (nx < 0 || nx + a.w > COLS * TS || ny < 0) return true;
        int x0 = nx / TS, x1 = (nx + a.w - 1) / TS, y0 = ny / TS, y1 = (ny + a.h - 1) / TS;
        for (int ty = y0; ty <= y1; ty++)
            for (int tx = x0; tx <= x1; tx++) {
                int t = tile(tx, ty);
                switch (t) {
                    case EMPTY: break;
                    case SOLID: case ICE: case CONV_L: case CONV_R: case BOUNCE: return true;
                    case POOL_J: case POOL_C: case POOL_G:
                        if (over(nx, ny, a.w, a.h, tx * TS, ty * TS + POOL_TOP, TS, TS - POOL_TOP)) return true;
                        break;
                    case CURT_P:
                        if (!(a instanceof Player && ((Player) a).ch == Art.MIMI)) return true;
                        break;
                    case CURT_Q:
                        if (!(a instanceof Player && ((Player) a).ch == Art.BISCOITO)) return true;
                        break;
                    case ONEWAY:
                        if (dy != 0 && dy == a.g) {
                            int bx = tx * TS, by = ty * TS;
                            if (over(nx, ny, a.w, a.h, bx, by, TS, 5) && !over(a.x, a.y, a.w, a.h, bx, by, TS, 5)) return true;
                        }
                        break;
                    default: break;
                }
            }
        for (Ents.Solid s : solids)
            if (s.solid() && over(nx, ny, a.w, a.h, s.x, s.y, s.w, s.h)) return true;
        for (Box b : boxes)
            if (b != a && over(nx, ny, a.w, a.h, b.x, b.y, b.w, b.h)) return true;
        if (dy != 0 && dy == a.g) {
            for (Player p : players) {
                if (p == a || !p.alive || p.g != a.g) continue;
                int hy = p.g > 0 ? p.y : p.y + p.h - 2;
                if (over(nx, ny, a.w, a.h, p.x, hy, p.w, 2) && !over(a.x, a.y, a.w, a.h, p.x, hy, p.w, 2)) return true;
            }
        }
        return false;
    }

    static boolean ridesOn(Actor r, int bx, int by, int bw, int bh) {
        if (r.x + r.w <= bx || r.x >= bx + bw) return false;
        return r.g > 0 ? r.y + r.h == by : r.y == by + bh;
    }

    List<Actor> ridersOf(Actor base) {
        List<Actor> out = null;
        for (Player p : players)
            if (p != base && p.alive && (base instanceof Box ? p.g > 0 : p.g == base.g) && ridesOn(p, base.x, base.y, base.w, base.h)) {
                if (out == null) out = new ArrayList<>(2);
                out.add(p);
            }
        for (Box b : boxes)
            if (b != base && base.g > 0 && ridesOn(b, base.x, base.y, base.w, base.h)) {
                if (out == null) out = new ArrayList<>(2);
                out.add(b);
            }
        return out == null ? Collections.<Actor>emptyList() : out;
    }

    List<Actor> ridersOfSolid(Ents.Solid s) {
        List<Actor> out = new ArrayList<>(2);
        if (!s.solid()) return out;
        for (Actor a : new ArrayList<>(actors())) if (ridesOn(a, s.x, s.y, s.w, s.h)) out.add(a);
        return out;
    }

    public boolean anyActorRiding(Ents.Solid s) { return !ridersOfSolid(s).isEmpty(); }

    public boolean anyActorIn(int x, int y, int w, int h) {
        for (Actor a : actors()) if (over(a.x, a.y, a.w, a.h, x, y, w, h)) return true;
        return false;
    }

    public boolean buttonPressed(Ents.Button b) {
        for (Actor a : actors()) {
            if (b.only >= 0 && !(a instanceof Player && ((Player) a).ch == b.only)) continue;
            if (over(a.x, a.y, a.w, a.h, b.x + 2, b.ceiling ? b.y : b.y + 9, 12, 7)) return true;
        }
        return false;
    }

    /** Move um solido 1px empurrando/carregando quem estiver nele. */
    public boolean stepSolid(Ents.Solid s, int sx, int sy) {
        List<Actor> riders = ridersOfSolid(s);
        s.x += sx; s.y += sy;
        s.collidable = false;
        try {
            for (Actor a : new ArrayList<>(actors())) {
                if (riders.contains(a) || !over(a.x, a.y, a.w, a.h, s.x, s.y, s.w, s.h)) continue;
                int moved = sx != 0 ? a.moveX(sx) : a.moveY(sy);
                if (moved == 0) { s.x -= sx; s.y -= sy; return false; }
            }
            for (Actor r : riders) {
                int moved = sx != 0 ? r.moveX(sx) : r.moveY(sy);
                if (moved == 0 && sy != 0 && sy == -r.g) { s.x -= sx; s.y -= sy; return false; }
            }
        } finally {
            s.collidable = true;
        }
        return true;
    }

    /** Tipo do chao sob os pes (ou -1 se no ar). */
    public int groundType(Actor a) {
        if (!collides(a, a.x, a.y + a.g, a.g)) return -1;
        int fy = a.g > 0 ? a.y + a.h : a.y - 1;
        int ty = Math.floorDiv(fy, TS);
        int best = SOLID;
        int[] xs = {a.x, a.x + a.w - 1};
        for (int xx : xs) {
            int t = tile(xx / TS, ty);
            if (t == BOUNCE) return BOUNCE;
            if (t == CONV_L || t == CONV_R) best = t;
            else if (t == ICE && best == SOLID) best = ICE;
        }
        return best;
    }

    public Ents.Fan windAt(Actor a) {
        int cx = a.x + a.w / 2;
        for (Ents.Fan f : fans) {
            if (!f.on) continue;
            if (cx >= f.x && cx < f.x + f.w && a.y + a.h > f.zoneTop && a.y < f.y) return f;
        }
        return null;
    }

    boolean tryPushBox(Actor pusher, int s) {
        for (Box b : boxes) {
            if (b == pusher) continue;
            if (over(pusher.x + s, pusher.y, pusher.w, pusher.h, b.x, b.y, b.w, b.h)) {
                if (b.y + b.h <= pusher.y + 2 || b.y >= pusher.y + pusher.h - 2) return false;
                if (b.moveX(s) != 0 && !collides(pusher, pusher.x + s, pusher.y, 0)) return true;
                return false;
            }
        }
        return false;
    }

    // =====================================================================
    // Atores
    // =====================================================================
    public abstract static class Actor {
        public final World world;
        public int x, y, w, h;
        public int g = 1; // direcao da gravidade
        public float vx, vy, rx, ry;
        public int px, py; // posicao no passo anterior (para desenhar interpolado)
        public boolean inPortal;

        Actor(World wd, int x, int y, int ww, int hh) {
            this.world = wd; this.x = x; this.y = y; this.w = ww; this.h = hh;
        }

        public int moveX(int amt) {
            int s = Integer.signum(amt), moved = 0;
            int guard = 0;
            while (amt != 0 && guard++ < 64) {
                List<Actor> riders = world.ridersOf(this);
                if (!world.collides(this, x + s, y, 0)) {
                    x += s;
                    for (Actor r : riders) r.moveX(s);
                    amt -= s; moved += s;
                } else if (this instanceof Player && world.tryPushBox(this, s)) {
                    ((Player) this).pushing = 8;
                } else break;
            }
            return moved;
        }

        public int moveY(int amt) {
            int s = Integer.signum(amt), moved = 0;
            int guard = 0;
            while (amt != 0 && guard++ < 64) {
                List<Actor> riders = world.ridersOf(this);
                boolean towardRiders = s == -g;
                if (towardRiders) {
                    boolean ok = true;
                    for (Actor r : riders) if (r.moveY(s) == 0) ok = false;
                    if (!ok || world.collides(this, x, y + s, s)) break;
                    y += s;
                } else {
                    if (world.collides(this, x, y + s, s)) break;
                    y += s;
                    for (Actor r : riders) r.moveY(s);
                }
                amt -= s; moved += s;
            }
            return moved;
        }
    }

    public static class Box extends Actor {
        Box(World wd, int x, int y) { super(wd, x, y, 16, 16); }

        void update() {
            vy = Math.min(5f, vy + 0.3f);
            ry += vy;
            int my = (int) ry;
            ry -= my;
            if (my != 0 && moveY(my) != my) { vy = 0; ry = 0; }
            int gt = world.groundType(this);
            if (gt == CONV_L) moveX(-1);
            else if (gt == CONV_R) moveX(1);
        }
    }

    public static class Player extends Actor {
        public static final float GRAV = 0.30f, MAXFALL = 5.5f, JUMP = 5.9f, RUN = 1.9f, BOUNCE_V = 8.6f;
        public final int ch;
        public boolean alive = true, facingLeft, onGround, jumping, inOrb, actPressed, inWind;
        public int prevBits, coyote, buffer, pushing, anim, walkT, blinkT = 120, emote, emoteT;

        Player(World wd, int ch, int x, int y) {
            super(wd, x, y, 10, 14);
            this.ch = ch;
            this.facingLeft = ch == Art.BISCOITO;
        }

        void update(int bits) {
            if (emoteT > 0) emoteT--;
            if (!alive) return;
            int pb = prevBits;
            prevBits = bits;
            boolean L = (bits & Input.LEFT) != 0, R = (bits & Input.RIGHT) != 0, J = (bits & Input.JUMP) != 0;
            boolean jumpPressed = J && (pb & Input.JUMP) == 0;
            actPressed = (bits & Input.ACT) != 0 && (pb & Input.ACT) == 0;
            int er = (bits >> 4) & 7, per = (pb >> 4) & 7;
            if (er != 0 && er != per) {
                emote = er; emoteT = 150;
                world.event(Sfx.POP, x + w / 2, y, 0);
            }

            int gt = world.groundType(this);
            onGround = gt >= 0;
            float acc, dec;
            if (onGround && gt == ICE) { acc = 0.06f; dec = 0.012f; }
            else if (onGround) { acc = 0.4f; dec = 0.5f; }
            else { acc = 0.3f; dec = 0.1f; }
            float max = pushing > 0 ? 1.0f : RUN;
            if (pushing > 0) pushing--;
            int dir = (R ? 1 : 0) - (L ? 1 : 0);
            if (dir != 0) {
                float sp = vx * dir; // velocidade na direcao desejada
                if (sp < max) sp = Math.min(max, sp + acc);
                else sp = Math.max(max, sp - 0.2f);
                vx = sp * dir;
                facingLeft = dir < 0;
            } else {
                if (vx > 0) vx = Math.max(0, vx - dec);
                else if (vx < 0) vx = Math.min(0, vx + dec);
            }

            coyote = onGround ? 6 : coyote - 1;
            buffer = jumpPressed ? 7 : buffer - 1;
            if (buffer > 0 && coyote > 0) {
                vy = -JUMP * g;
                buffer = 0; coyote = 0; jumping = true;
                world.event(Sfx.JUMP, x + w / 2, g > 0 ? y + h : y, P_DUST);
            }
            if (jumping && !J && vy * g < 0) { vy *= 0.45f; jumping = false; }
            if (vy * g >= 0) jumping = false;

            vy += GRAV * g;
            Ents.Fan fan = world.windAt(this);
            inWind = fan != null;
            if (fan != null) {
                float d = (y + h) - fan.zoneTop;
                float force = 0.62f * Math.max(0.12f, Math.min(1f, d / 40f));
                vy -= force;
                vy *= 0.94f;
                if (vy < -3.2f) vy = -3.2f;
            }
            if (vy * g > MAXFALL) vy = MAXFALL * g;

            rx += vx;
            int mx = (int) rx;
            rx -= mx;
            if (mx != 0) {
                int moved = moveX(mx);
                if (moved != mx) { vx = 0; rx = 0; }
            }
            if (onGround && gt == CONV_L) moveX(-1);
            if (onGround && gt == CONV_R) moveX(1);

            ry += vy;
            int my = (int) ry;
            ry -= my;
            if (my != 0) {
                int moved = moveY(my);
                if (moved != my) {
                    if (Integer.signum(my) == g) {
                        int t2 = world.groundType(this);
                        if (t2 == BOUNCE) {
                            vy = -BOUNCE_V * g;
                            jumping = false;
                            world.event(Sfx.BOING, x + w / 2, g > 0 ? y + h : y, P_DUST);
                        } else {
                            if (Math.abs(vy) > 3.6f) world.event(Sfx.LAND, x + w / 2, g > 0 ? y + h : y, P_DUST);
                            vy = 0;
                        }
                    } else vy = 0;
                    ry = 0;
                }
            }
            onGround = world.groundType(this) >= 0;

            // animacao
            if (!onGround && !inWind) anim = 4;
            else if (onGround && Math.abs(vx) > 0.3f) {
                walkT++;
                anim = (walkT / 7) % 2 == 0 ? 2 : 3;
            } else {
                walkT = 0;
                blinkT--;
                if (blinkT < 0) blinkT = 150 + (int) (Math.random() * 120);
                anim = blinkT < 8 ? 1 : 0;
            }
            if (inWind && !onGround) anim = (int) ((world.time / 10) % 2) == 0 ? 4 : 0;
        }

        void write(DataOutputStream o) throws IOException {
            o.writeShort(x); o.writeShort(y);
            int f = (facingLeft ? 1 : 0) | (alive ? 2 : 0) | (onGround ? 4 : 0) | (g < 0 ? 8 : 0) | (inWind ? 16 : 0);
            o.writeByte(f);
            o.writeByte(anim);
            o.writeByte(emote);
            o.writeByte(Math.min(255, emoteT));
        }

        void read(DataInputStream i) throws IOException {
            x = i.readShort(); y = i.readShort();
            int f = i.readUnsignedByte();
            facingLeft = (f & 1) != 0; alive = (f & 2) != 0; onGround = (f & 4) != 0; g = (f & 8) != 0 ? -1 : 1; inWind = (f & 16) != 0;
            anim = i.readByte();
            emote = i.readByte();
            emoteT = i.readUnsignedByte();
        }
    }

    // =====================================================================
    // Rede
    // =====================================================================
    public void writeState(DataOutputStream o) throws IOException {
        o.writeByte(phase); o.writeShort(phaseT); o.writeInt(time);
        o.writeByte(gemsGot); o.writeByte(deathWho); o.writeByte(deathMsg);
        int cb = 0;
        for (int i = 0; i < 26; i++) if (chan[i]) cb |= 1 << i;
        o.writeInt(cb);
        for (Player p : players) p.write(o);
        for (Box b : boxes) { o.writeShort(b.x); o.writeShort(b.y); }
        for (Ents.Ent e : ents) e.write(o);
    }

    public void readState(DataInputStream i) throws IOException {
        savePrev();
        phase = i.readByte(); phaseT = i.readShort(); time = i.readInt();
        gemsGot = i.readByte(); deathWho = i.readByte(); deathMsg = i.readByte();
        int cb = i.readInt();
        for (int k = 0; k < 26; k++) chan[k] = (cb & (1 << k)) != 0;
        for (Player p : players) p.read(i);
        for (Box b : boxes) { b.x = i.readShort(); b.y = i.readShort(); }
        for (Ents.Ent e : ents) e.read(i);
    }

    // =====================================================================
    // Particulas (so visual, cada maquina simula a sua)
    // =====================================================================
    public static class Particle {
        public float x, y, vx, vy, grav;
        public int life, max, color, kind;
    }

    public void spawn(int kind, int x, int y) {
        int n;
        switch (kind) {
            case P_SPARK: n = 10; break;
            case P_PUFF0: case P_PUFF1: n = 18; break;
            case P_DUST: n = 4; break;
            case P_HEARTS: n = 6; break;
            case P_SWIRL: n = 12; break;
            case P_CRUMBS: n = 10; break;
            case P_FLIP: n = 10; break;
            default: return;
        }
        for (int i = 0; i < n; i++) {
            Particle p = new Particle();
            p.x = x; p.y = y; p.kind = kind;
            double a = rnd.nextDouble() * Math.PI * 2, sp = 0.5 + rnd.nextDouble() * 1.5;
            p.vx = (float) (Math.cos(a) * sp);
            p.vy = (float) (Math.sin(a) * sp);
            p.max = p.life = 20 + rnd.nextInt(20);
            switch (kind) {
                case P_SPARK: p.color = rnd.nextBoolean() ? 0xfff6a8 : 0xffffff; p.vy -= 0.6f; break;
                case P_PUFF0: p.color = rnd.nextBoolean() ? 0xff8fb4 : 0xffe3ee; p.vx *= 1.6f; p.vy *= 1.6f; p.max = p.life = 40 + rnd.nextInt(20); break;
                case P_PUFF1: p.color = rnd.nextBoolean() ? 0xc98a55 : 0xf6dfb8; p.vx *= 1.6f; p.vy *= 1.6f; p.max = p.life = 40 + rnd.nextInt(20); break;
                case P_DUST: p.color = 0xfff0f5; p.vy = -0.3f - rnd.nextFloat() * 0.4f; p.vx *= 0.8f; p.max = p.life = 14; break;
                case P_HEARTS: p.color = 0xff6f9f; p.vx *= 0.4f; p.vy = -0.6f - rnd.nextFloat(); p.max = p.life = 60; break;
                case P_SWIRL: p.color = Levels.RAINBOW[i % Levels.RAINBOW.length]; break;
                case P_CRUMBS: p.color = rnd.nextBoolean() ? 0xd9a066 : 0x9b6a3c; p.grav = 0.15f; p.vy -= 1; break;
                case P_FLIP: p.color = 0xc9a0ff; break;
                default: break;
            }
            particles.add(p);
        }
    }

    /** Chamado todo tick em qualquer maquina (host ou cliente). */
    public void updateCosmetic() {
        cosmeticTick++;
        for (Iterator<Particle> it = particles.iterator(); it.hasNext(); ) {
            Particle p = it.next();
            p.x += p.vx; p.y += p.vy; p.vy += p.grav;
            p.vx *= 0.95f;
            if (p.kind != P_HEARTS) p.vy *= 0.95f;
            if (--p.life <= 0) it.remove();
        }
    }
}

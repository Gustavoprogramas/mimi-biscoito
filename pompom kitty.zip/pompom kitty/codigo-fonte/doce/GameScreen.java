package doce;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.DataInputStream;
import java.io.IOException;

import static doce.Screens.*;

/** A fase em si: local, anfitriao (simula e transmite) ou convidado (so recebe). */
public class GameScreen implements Main.Screen {
    private final int idx;
    private World w;
    private Render r;
    private long t;
    private boolean paused, saved, lost;
    private int pauseSel;
    private int clientBits, lastSent = -1;
    private int introT = 170;
    private final String[] pauseItems = {"Continuar", "Reiniciar fase", "Mapa de fases", "Menu principal"};
    private static final String[] DEATH = {
        "caiu na meleca!", "virou docinho derretido!", "precisa de um banho agora!",
        "escorregou feio!", "tomou um banho de calda!", "foi pro lava-rápido!"
    };

    public GameScreen(int idx) {
        this.idx = idx;
        build();
    }

    private void build() {
        w = new World(idx);
        r = new Render(w);
        r.localChar = mode == LOCAL ? -1 : myChar;
        saved = false;
    }

    @Override public void onEnter() { Sfx.music(1); }

    // ------------------------------------------------------------------ entrada
    private int emote(Input in, int k1, int k2, int k3, int k4) {
        if (in.down(k1)) return 1 << 4;
        if (in.down(k2)) return 2 << 4;
        if (in.down(k3)) return 3 << 4;
        if (in.down(k4)) return 4 << 4;
        return 0;
    }

    private int myOnlineBits(Input in) {
        return in.bitsAny() | emote(in, KeyEvent.VK_1, KeyEvent.VK_2, KeyEvent.VK_3, KeyEvent.VK_4);
    }

    @Override public void update() {
        t++;
        if (introT > 0) introT--;
        Input in = Main.game.input;
        if (mode != LOCAL && !Net.connected()) {
            lost = true;
            if (in.confirm() || in.back()) { Net.closeAll(); Main.game.setScreen(new Title()); }
            w.updateCosmetic();
            return;
        }
        if (!handleNet()) return;

        // pausa
        if (in.pressed(KeyEvent.VK_ESCAPE) && w.phase != World.DONE) {
            if (mode == CLIENT) new Net.Msg(Net.PAUSE_REQ).send();
            else setPaused(!paused);
            Sfx.play(paused ? Sfx.SELECT : Sfx.BACK);
        } else if (paused && mode != CLIENT) {
            int old = pauseSel;
            if (in.up()) pauseSel = (pauseSel + 3) % 4;
            if (in.downK()) pauseSel = (pauseSel + 1) % 4;
            if (old != pauseSel) { Sfx.play(Sfx.SELECT); sendPause(); }
            if (in.confirm()) { Sfx.play(Sfx.CONFIRM); choosePause(); return; }
        }

        // simulacao
        if (mode != CLIENT && !paused) {
            int[] bits = new int[2];
            if (mode == LOCAL) {
                bits[myChar] = in.bitsWASD() | emote(in, KeyEvent.VK_1, KeyEvent.VK_2, KeyEvent.VK_3, KeyEvent.VK_4);
                bits[otherChar()] = in.bitsArrows() | emote(in, KeyEvent.VK_7, KeyEvent.VK_8, KeyEvent.VK_9, KeyEvent.VK_0);
            } else {
                bits[myChar] = myOnlineBits(in);
                bits[otherChar()] = clientBits;
            }
            w.update(bits);
            if (w.wantsRestart()) {
                restart();
                return;
            }
        }
        if (mode != CLIENT) {
            if (mode == HOST) sendState();
            for (int[] e : w.events) applyEvent(e);
            w.events.clear();
        } else {
            int b = paused ? 0 : myOnlineBits(in);
            if (b != lastSent || t % 15 == 0) { new Net.Msg(Net.INPUT).i(b).send(); lastSent = b; }
        }
        w.updateCosmetic();

        // fim de fase
        if (w.phase == World.DONE) {
            if (!saved) { Save.finished(idx, w.hearts(), w.time); saved = true; }
            if (mode != CLIENT) {
                if (in.confirm()) { Sfx.play(Sfx.CONFIRM); nextLevel(); }
                else if (in.pressed(KeyEvent.VK_R)) { Sfx.play(Sfx.CONFIRM); restart(); }
                else if (in.pressed(KeyEvent.VK_ESCAPE)) { Sfx.play(Sfx.BACK); toMap(); }
            }
        }
    }

    private void applyEvent(int[] e) {
        if (e[0] >= 0) Sfx.play(e[0]);
        if (e[3] > 0) w.spawn(e[3], e[1], e[2]);
    }

    private void setPaused(boolean p) {
        paused = p;
        pauseSel = 0;
        sendPause();
    }

    private void sendPause() {
        if (mode == HOST) new Net.Msg(Net.PAUSE).z(paused).b(pauseSel).send();
    }

    private void choosePause() {
        switch (pauseSel) {
            case 0: setPaused(false); break;
            case 1: paused = false; restart(); break;
            case 2: toMap(); break;
            default:
                Net.closeAll();
                Main.game.setScreen(new Title());
        }
    }

    private void restart() {
        if (mode == HOST) new Net.Msg(Net.START).b(idx).send();
        paused = false;
        sendPause();
        build();
        introT = 0;
    }

    private void nextLevel() {
        int n = idx + 1;
        if (n >= Levels.count()) {
            if (mode == HOST) new Net.Msg(Net.START).b(-1).send();
            Main.game.setScreen(new Ending());
            return;
        }
        level = n;
        if (mode == HOST) new Net.Msg(Net.START).b(n).send();
        Main.game.setScreen(new GameScreen(n));
    }

    private void toMap() {
        LevelMap lm = new LevelMap();
        lm.sel = Math.min(idx, Save.unlocked - 1);
        if (w.phase == World.DONE && idx + 1 < Levels.count()) lm.sel = Math.min(idx + 1, Save.unlocked - 1);
        if (mode == HOST) new Net.Msg(Net.MAP).b(lm.sel).b(Save.unlocked).send();
        Main.game.setScreen(lm);
    }

    // ------------------------------------------------------------------ rede
    private void sendState() {
        Net.Msg m = new Net.Msg(Net.STATE);
        try {
            w.writeState(m.o);
            m.o.writeShort(w.events.size());
            for (int[] e : w.events) {
                m.o.writeByte(e[0]);
                m.o.writeShort(e[1]);
                m.o.writeShort(e[2]);
                m.o.writeByte(e[3]);
            }
        } catch (IOException ignored) {}
        m.send();
    }

    /** Processa mensagens; retorna false se a tela mudou. */
    private boolean handleNet() {
        if (mode == LOCAL) return true;
        byte[] m;
        while (Net.conn != null && (m = Net.conn.poll()) != null) {
            try {
                DataInputStream d = Net.reader(m);
                byte type = d.readByte();
                if (type == Net.BYE) {
                    Net.closeAll();
                    toast(mode == HOST ? "Seu amigo saiu do jogo." : "O anfitrião saiu do jogo.");
                    Main.game.setScreen(new Title());
                    return false;
                }
                if (mode == HOST) {
                    if (type == Net.INPUT) clientBits = d.readInt();
                    else if (type == Net.PAUSE_REQ && w.phase != World.DONE) { setPaused(!paused); Sfx.play(Sfx.SELECT); }
                } else {
                    switch (type) {
                        case Net.STATE: {
                            w.readState(d);
                            int n = d.readShort();
                            for (int k = 0; k < n; k++) {
                                int sfx = d.readByte(), x = d.readShort(), y = d.readShort(), p = d.readByte();
                                applyEvent(new int[]{sfx, x, y, p});
                            }
                            break;
                        }
                        case Net.START: {
                            int n = d.readByte();
                            if (n < 0) { Main.game.setScreen(new Ending()); return false; }
                            level = n;
                            if (n == idx) { build(); paused = false; introT = 0; }
                            else { Main.game.setScreen(new GameScreen(n)); return false; }
                            break;
                        }
                        case Net.PAUSE:
                            paused = d.readBoolean();
                            pauseSel = d.readByte();
                            break;
                        case Net.MAP: {
                            LevelMap lm = new LevelMap();
                            lm.sel = d.readByte();
                            lm.clientUnlocked = d.readByte();
                            Main.game.setScreen(lm);
                            return false;
                        }
                        case Net.TO_LOBBY:
                            Main.game.setScreen(new Lobby());
                            return false;
                        default: break;
                    }
                }
            } catch (IOException | RuntimeException e) {
                // mensagem estranha: ignora
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ desenho
    @Override public void render(Graphics2D g) {
        r.render(g, t);
        r.drawHud(g);
        Color ink = Screens.INK;
        if (introT > 0 && w.phase == World.PLAY) {
            int a = Math.min(255, introT * 6);
            int y = 30 - (introT > 150 ? (introT - 150) : 0);
            Art.panel(g, Main.W / 2 - 120, y, 240, 34, new Color(255, 255, 255, Math.min(230, a)), new Color(0x3b, 0x20, 0x33, a));
            PixelFont.centered(g, "FASE " + (idx + 1), Main.W / 2, y + 5, new Color(0xc2, 0x18, 0x5b, a), 1);
            PixelFont.centered(g, w.def.name.toUpperCase(), Main.W / 2, y + 16, new Color(0x3b, 0x20, 0x33, a), 1);
            if (mode == LOCAL) {
                String c = "J1 (WASD) = " + Art.NAMES[myChar].toUpperCase() + "   J2 (SETAS) = " + Art.NAMES[otherChar()].toUpperCase();
                PixelFont.centeredOutlined(g, c, Main.W / 2, y + 40, Color.WHITE, new Color(0x3b, 0x20, 0x33, a), 1);
            }
        }
        if (w.phase == World.DEAD && w.deathWho >= 0) {
            Art.panel(g, Main.W / 2 - 110, 100, 220, 46, new Color(255, 255, 255, 235), ink);
            PixelFont.centered(g, "OPS!", Main.W / 2, 106, new Color(0xe0577f), 2);
            String s = Art.NAMES[w.deathWho] + " " + DEATH[Math.floorMod(w.deathMsg, DEATH.length)];
            PixelFont.centered(g, s, Main.W / 2, 128, ink, 1);
        }
        if (w.phase == World.DONE) drawResults(g);
        if (paused) drawPause(g);
        if (lost) {
            g.setColor(new Color(42, 27, 46, 180));
            g.fillRect(0, 0, Main.W, Main.H);
            Art.panel(g, Main.W / 2 - 120, 100, 240, 50, Screens.CREAM, ink);
            PixelFont.centered(g, "A CONEXÃO CAIU :(", Main.W / 2, 108, new Color(0xe0577f), 2);
            PixelFont.centered(g, "ENTER: VOLTAR AO MENU", Main.W / 2, 132, ink, 1);
        }
        Screens.drawNotice(g);
    }

    private void drawPause(Graphics2D g) {
        g.setColor(new Color(42, 27, 46, 150));
        g.fillRect(0, 0, Main.W, Main.H);
        PixelFont.centeredOutlined(g, "PAUSA", Main.W / 2, 50, Color.WHITE, Screens.INK, 3);
        Screens.menu(g, pauseItems, pauseSel, Main.W / 2, 90, t);
        String f = mode == CLIENT ? "O ANFITRIÃO ESCOLHE.  ESC: PEDIR PRA CONTINUAR" : "ENTER: ESCOLHER    ESC: CONTINUAR";
        Screens.footer(g, f);
    }

    private void drawResults(Graphics2D g) {
        int a = (int) Math.min(170, w.phaseT * 4L);
        g.setColor(new Color(42, 27, 46, Math.min(150, a)));
        g.fillRect(0, 0, Main.W, Main.H);
        Color ink = Screens.INK;
        Art.panel(g, Main.W / 2 - 130, 46, 260, 168, Screens.CREAM, ink);
        PixelFont.centered(g, "FASE COMPLETA!", Main.W / 2, 56, new Color(0xc2185b), 2);
        int hearts = w.hearts();
        long since = t;
        for (int h = 0; h < 3; h++) {
            boolean on = h < hearts;
            int pop = (int) Math.max(0, 4 - ((since % 100000) / 8 - h * 2));
            Art.heart(g, Main.W / 2 - 46 + h * 32, 82 - pop, on ? Screens.PINK : new Color(0xd8cfe0), 4);
        }
        int secs = w.time / 60;
        String tm = String.format("TEMPO %d:%02d   (IDEAL %d:%02d)", secs / 60, secs % 60, w.def.par / 60, w.def.par % 60);
        PixelFont.centered(g, tm, Main.W / 2, 124, ink, 1);
        PixelFont.centered(g, "DOCES " + w.gemsGot + " / " + w.gemsTotal, Main.W / 2, 138, ink, 1);
        String tip = hearts == 3 ? "PERFEITO! VOCÊS SÃO UMA DUPLA DOCE!"
            : w.gemsGot < w.gemsTotal ? "Faltaram doces! Juntos vocês pegam todos."
            : "Tentem mais rápido pro terceiro coração!";
        PixelFont.centered(g, tip, Main.W / 2, 156, new Color(0x8e7aa8), 1);
        int j1 = (int) Math.abs(Math.sin(t * 0.15) * 6), j2 = (int) Math.abs(Math.sin(t * 0.15 + 1.5) * 6);
        Art.draw(g, Art.frame(Art.MIMI, false, j1 > 3 ? 4 : 0), Main.W / 2 - 118, 76 - j1, 2, false);
        Art.draw(g, Art.frame(Art.BISCOITO, true, j2 > 3 ? 4 : 0), Main.W / 2 + 86, 76 - j2, 2, false);
        String f = mode == CLIENT ? "ESPERANDO O ANFITRIÃO..." : (idx + 1 < Levels.count() ? "ENTER: PRÓXIMA   R: REPETIR   ESC: MAPA" : "ENTER: FINAL!   R: REPETIR   ESC: MAPA");
        PixelFont.centered(g, f, Main.W / 2, 196, ink, 1);
    }
}

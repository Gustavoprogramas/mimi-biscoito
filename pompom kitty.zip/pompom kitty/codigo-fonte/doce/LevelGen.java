package doce;

import java.util.*;

/**
 * Gera as fases dos mundos 2 a 10.
 *
 * Cada fase e montada com "pedacos" que eu desenhei e testei (pocas, pontes, portoes com botao,
 * tuneis de agua, cadeados...). Os pedacos respeitam os limites da fisica (altura do pulo, tamanho
 * dos buracos), e os conectores entre andares (escada, nuvens, ventilador, elevador, trampolim,
 * agua, portal...) sempre levam ao proximo andar. A semente e fixa: a fase N e igual em qualquer PC,
 * o que e essencial pro jogo online.
 */
public final class LevelGen {
    private LevelGen() {}

    static final int W = 30, H = 17;

    // ===================================================================== nomes
    static final String[][] NAMES = {
        {"Primeiro Mergulho", "Bolhas de Guaraná", "Túnel de Gelo-Refri", "Canudinho Gigante", "Cachoeira de Uva",
            "Aquário de Balas", "Corredeira Cítrica", "Fundo do Copo", "Gás Total", "Tsunami de Refri"},
        {"Chave de Caramelo", "Cadeado de Menta", "Trilha do Pirulito", "Clareira das Jujubas", "Toca do Coelho de Açúcar",
            "Ponte de Alcaçuz", "Raízes de Chiclete", "Labirinto de Folhas", "Árvore das Chaves", "Coração da Floresta"},
        {"Primeira Brisa", "Rajada Rosa", "Nuvens Fofas", "Relâmpago de Algodão", "Pipa Perdida",
            "Ventania Doce", "Chuva de Granulado", "Furacão de Marshmallow", "Olho da Tempestade", "Depois da Chuva"},
        {"Tic-Tac", "Ponteiro Apressado", "Engrenagens de Bolacha", "Cuco Sonolento", "Pêndulo de Pirulito",
            "Corda Dada", "Badalada da Meia-Noite", "Ampulheta Doce", "Mecanismo Secreto", "Hora Exata"},
        {"Pé do Vulcão", "Gêiser de Brigadeiro", "Rio de Ganache", "Pedras Quentinhas", "Túnel de Lava Doce",
            "Fornalha de Biscoito", "Erupção Cremosa", "Cratera de Trufa", "Magma de Caramelo", "Topo Fumegante"},
        {"Raio Rosa", "Botão Vermelho", "Pisca-Pisca", "Corredor Neon", "Experimento 42",
            "Sala Espelhada", "Caixa de Proteção", "Feixe Cruzado", "Cientista Maluquinho", "Reator de Açúcar"},
        {"Decolagem", "Passeio na Lua", "Cinturão de Confeitos", "Estação Biscoito", "Planeta Gelatina",
            "Cometa de Chantilly", "Gravidade Zero", "Nebulosa de Açúcar", "Buraco de Minhoca", "Pouso Suave"},
        {"Troca-Troca", "Cogumelos Brilhantes", "Vaga-lumes", "Trilha Encantada", "Espelho da Fada",
            "Bruma Lilás", "Feitiço do Sapo", "Lago da Lua", "Círculo de Fadas", "Árvore Ancestral"},
        {"Faixa Vermelha", "Faixa Laranja", "Faixa Amarela", "Faixa Verde", "Faixa Azul",
            "Faixa Anil", "Faixa Violeta", "Ponte Prismática", "Nuvem Final", "Pote de Ouro Doce"},
    };

    static final String[] HINTS = {
        "NA ÁGUA: SEGURE ↑ PRA NADAR PRA CIMA",
        "PEGUE A CHAVE E ENCOSTE NO CADEADO",
        "O VENTO EMPURRA! CUIDADO NOS PULOS",
        "BLOCOS DO RELÓGIO SOMEM NO RITMO",
        "ESPERE A BOLHA DE LAVA DESCER",
        "LASER LIGADO = PERIGO! BOTÃO DESLIGA",
        "GRAVIDADE BAIXINHA: PULOS LONGOS",
        "A ESFERA DOURADA TROCA VOCÊS DE LUGAR",
        "TUDO JUNTO! BOA SORTE, DUPLA!",
    };

    // ===================================================================== montador
    static final String LEGEND_POOL = "0123456789adefghijklnopqstuvwxyzADEHKNORSUVYZ!$&+=?;:,'\"^()[]/\\|`@";

    static final class B {
        final char[][] m = new char[H][W];
        final Map<String, Character> legend = new LinkedHashMap<>();
        final Random r;
        final int wi, n; // wi = mundo (1..9 = mundos 2..10), n = fase dentro do mundo (0..9)
        int chan = 0, portal = 1, group = 1, coop = 0;
        final LinkedHashSet<String> mech = new LinkedHashSet<>();
        final List<int[]> flat = new ArrayList<>(); // chao livre (x, linha de pe) para doces/lanternas
        int segs = 0, conns = 0;

        B(long seed, int wi, int n) {
            r = new Random(seed);
            this.wi = wi; this.n = n;
            for (char[] row : m) Arrays.fill(row, '#');
        }

        char L(String spec) {
            Character c = legend.get(spec);
            if (c == null) {
                c = LEGEND_POOL.charAt(legend.size());
                legend.put(spec, c);
            }
            return c;
        }

        String ch() { return String.valueOf((char) ('A' + chan++)); }

        void set(int x, int y, char c) {
            if (x < 1 || x > W - 2 || y < 1 || y > H - 1) throw new IllegalStateException("fora do mapa " + x + "," + y);
            m[y][x] = c;
        }

        char get(int x, int y) { return m[y][x]; }

        void air(int x0, int y0, int x1, int y1) {
            for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) m[y][x] = ' ';
        }

        boolean chance(double p) { return r.nextDouble() < p; }
        int range(int a, int b) { return a + r.nextInt(b - a + 1); }
    }

    /** Um corredor: chao na linha floor, ar de top ate floor-1; anda na direcao dir. */
    static final class Cor {
        final int floor, top, dir;
        int xa, xb;
        Cor(int floor, int top, int xa, int xb, int dir) { this.floor = floor; this.top = top; this.xa = xa; this.xb = xb; this.dir = dir; }
        int g() { return floor - 1; }
        int air() { return floor - top; }
        int len() { return xb - xa + 1; }
    }

    /** Ajudante de coordenadas locais: lx = 0 e o lado por onde se chega no pedaco. */
    static final class P {
        final B b; final Cor c; final int d0;
        P(B b, Cor c, int d0) { this.b = b; this.c = c; this.d0 = d0; }
        int x(int lx) { return c.dir > 0 ? c.xa + d0 + lx : c.xb - d0 - lx; }
        void at(int lx, int y, char ch) { b.set(x(lx), y, ch); }
        void at(int lx, int y, String spec) { b.set(x(lx), y, b.L(spec)); }
        int g() { return c.floor - 1; }
        int F() { return c.floor; }
        int T() { return c.top; }
        char conv() { return c.dir > 0 ? '>' : '<'; }
        char wind(boolean forward) { return (c.dir > 0) == forward ? '}' : '{'; }
    }

    // ===================================================================== fisica por mundo
    static final class Phys {
        int maxPool, maxBlock, orbPool;
        Phys(int maxPool, int maxBlock, int orbPool) { this.maxPool = maxPool; this.maxBlock = maxBlock; this.orbPool = orbPool; }
    }

    static Phys phys(B b, Cor c) {
        if (b.wi == 7 && c.air() >= 6) return new Phys(5, Math.min(4, c.air() - 3), 7); // espaco: gravidade baixa e teto alto
        if (c.air() <= 3) return new Phys(2, 1, 5);
        return new Phys(3, 2, 5);
    }

    // ===================================================================== geracao
    public static Levels.Def generate(int index) {
        int wi = Levels.worldOf(index); // 1..9
        int n = index % Levels.PER_WORLD;
        for (int attempt = 0; attempt < 40; attempt++) {
            B b = new B(91_337L * index + 7_919L * attempt + 12345, wi, n);
            try {
                return build(b, index);
            } catch (RuntimeException e) {
                // tenta de novo com outra semente (determinístico)
            }
        }
        throw new IllegalStateException("nao consegui gerar a fase " + index);
    }

    static final int ZIG = 0, TOWER = 1, LANES = 2, SPACE = 3;

    static Levels.Def build(B b, int index) {
        int wi = b.wi, n = b.n;
        int skel;
        if (wi == 7) skel = n % 2 == 0 ? SPACE : ZIG;
        else if (n < 3) skel = ZIG;
        else if (n < 6) skel = b.chance(0.6) ? ZIG : TOWER;
        else {
            double x = b.r.nextDouble();
            skel = x < 0.35 ? ZIG : x < 0.7 ? TOWER : LANES;
        }
        if (wi == 8 && n >= 4 && skel == LANES) skel = ZIG; // bosque usa trilhas com troca
        switch (skel) {
            case ZIG: zigzag(b); break;
            case TOWER: tower(b); break;
            case LANES: lanes(b); break;
            default: space(b); break;
        }
        finish(b);
        int cm = 0, cb = 0, cM = 0, cB = 0;
        for (char[] row : b.m) for (char ch : row) { if (ch == 'm') cm++; if (ch == 'b') cb++; if (ch == 'M') cM++; if (ch == 'B') cB++; }
        if (cm != 1 || cb != 1 || cM != 1 || cB != 1) throw new IllegalStateException("inicio/portas");
        String[] map = new String[H];
        for (int y = 0; y < H; y++) map[y] = new String(b.m[y]);
        List<String> leg = new ArrayList<>();
        for (Map.Entry<String, Character> e : b.legend.entrySet()) leg.add(e.getValue() + " " + e.getKey());
        String name = NAMES[wi - 1][n];
        List<String> mech = new ArrayList<>(b.mech);
        String mechanic = mech.isEmpty() ? "Desafio" : String.join(", ", mech.subList(0, Math.min(3, mech.size())));
        boolean dark = (wi == 8 && n % 2 == 1) || (wi == 9 && n == 6) || (wi == 4 && n == 8);
        int par = 30 + b.segs * 9 + b.conns * 7 + b.coop * 6;
        Levels.Def d = new Levels.Def(name, mechanic, 9 + wi, par, dark, map, leg.toArray(new String[0]));
        if (wi == 7) d.grav = 0.55f;
        return d;
    }

    // ===================================================================== esqueletos
    /** Tres corredores em zigue-zague, ligados por pocos nas laterais. */
    static void zigzag(B b) {
        b.air(1, 12, 28, 15);
        b.air(1, 7, 28, 10);
        b.air(1, 1, 28, 5);
        b.air(25, 11, 28, 11); // poco direito (andar 1 -> 2)
        b.air(1, 6, 4, 6);     // poco esquerdo (andar 2 -> 3)
        Cor c1 = new Cor(16, 12, 5, 23, 1);
        Cor c2 = new Cor(11, 7, 6, 23, -1);
        Cor c3 = new Cor(6, 1, 7, 21, 1);
        start(b, 15);
        connector(b, c1, c2, true);
        connector(b, c2, c3, false);
        fill(b, c1);
        fill(b, c2);
        fill(b, c3);
        b.set(24, 5, 'M');
        b.set(26, 5, 'B');
        if (b.chance(0.5)) { b.set(24, 5, 'B'); b.set(26, 5, 'M'); }
        hint(b, 5, 12);
    }

    /** Quatro corredores baixinhos (3 de altura). */
    static void tower(B b) {
        b.air(1, 13, 28, 15);
        b.air(1, 9, 28, 11);
        b.air(1, 5, 28, 7);
        b.air(1, 1, 28, 3);
        b.air(25, 12, 28, 12);
        b.air(1, 8, 4, 8);
        b.air(25, 4, 28, 4);
        Cor c1 = new Cor(16, 13, 5, 23, 1);
        Cor c2 = new Cor(12, 9, 6, 23, -1);
        Cor c3 = new Cor(8, 5, 6, 23, 1);
        Cor c4 = new Cor(4, 1, 7, 23, -1);
        start(b, 15);
        connector(b, c1, c2, true);
        connector(b, c2, c3, false);
        connector(b, c3, c4, true);
        fill(b, c1);
        fill(b, c2);
        fill(b, c3);
        fill(b, c4);
        boolean swap = b.chance(0.5);
        b.set(2, 3, swap ? 'B' : 'M');
        b.set(4, 3, swap ? 'M' : 'B');
        hint(b, 5, 13);
    }

    /** Dois corredores altos (mundo do espaco, gravidade baixa). */
    static void space(B b) {
        b.air(1, 9, 28, 15);
        b.air(1, 1, 28, 7);
        b.air(25, 8, 28, 8);
        Cor c1 = new Cor(16, 9, 5, 23, 1);
        Cor c2 = new Cor(8, 1, 7, 23, -1);
        start(b, 15);
        connector(b, c1, c2, true);
        fill(b, c1);
        fill(b, c2);
        b.set(2, 7, 'M');
        b.set(4, 7, 'B');
        if (b.chance(0.5)) { b.set(2, 7, 'B'); b.set(4, 7, 'M'); }
        hint(b, 5, 9);
    }

    static void start(B b, int row) {
        b.set(1, row, 'm');
        b.set(3, row, 'b');
        if (b.chance(0.5)) { b.set(1, row, 'b'); b.set(3, row, 'm'); }
    }

    static void hint(B b, int x, int row) {
        if (b.n != 0) return;
        for (int xx = x; xx < 20; xx++)
            if (b.m[row][xx] == ' ') { b.set(xx, row, b.L("text " + HINTS[b.wi - 1])); return; }
    }

    /**
     * Duas pistas separadas por cortinas: cada um corre na sua e abre o portao do outro.
     * Ordem sem trava: botao da pista 1 -> portao da pista 0 -> botao da pista 0 -> portao da pista 1 ...
     */
    static void lanes(B b) {
        b.air(1, 4, 4, 15);     // area de saida
        b.air(5, 4, 28, 7);     // pista de cima (chao na linha 8)
        b.air(5, 12, 28, 15);   // pista de baixo (chao na linha 16)
        // escadinha de nuvens ate a pista de cima
        b.set(3, 14, '-'); b.set(4, 14, '-');
        b.set(1, 12, '-'); b.set(2, 12, '-');
        b.set(3, 10, '-'); b.set(4, 10, '-');
        b.set(1, 15, 'm'); b.set(2, 15, ' '); b.set(3, 15, 'b');
        boolean mimiTop = b.chance(0.5);
        if (!mimiTop) { b.set(1, 15, 'b'); b.set(3, 15, 'm'); }
        int[] owner = {mimiTop ? Art.MIMI : Art.BISCOITO, mimiTop ? Art.BISCOITO : Art.MIMI}; // [0]=cima [1]=baixo
        Cor[] lane = {new Cor(8, 4, 6, 26, 1), new Cor(16, 12, 6, 26, 1)};
        for (int i = 0; i < 2; i++) {
            char curtain = owner[i] == Art.MIMI ? 'P' : 'Q';
            for (int y = lane[i].top; y <= lane[i].g(); y++) b.set(5, y, curtain);
            b.set(27, lane[i].g(), owner[i] == Art.MIMI ? 'M' : 'B');
        }
        b.mech.add("Pistas separadas");
        // travas cruzadas
        int pairs = b.n >= 8 ? 3 : 2;
        int[][] plan = {{1, 2, 0, 5}, {0, 9, 1, 12}, {1, 15, 0, 18}}; // {pista do botao, d, pista do portao, d}
        boolean[][] reserved = new boolean[2][21];
        for (int k = 0; k < pairs; k++) {
            int bl = plan[k][0], bd = plan[k][1], gl = plan[k][2], gd = plan[k][3];
            String c = b.ch();
            String btn;
            if (b.chance(0.3)) btn = "lever " + c;
            else btn = (owner[bl] == Art.MIMI ? "pbutton " : "cbutton ") + c;
            b.set(lane[bl].xa + bd, lane[bl].g(), b.L(btn));
            for (int y = lane[gl].top; y <= lane[gl].g(); y++) b.set(lane[gl].xa + gd, y, b.L("gate " + c));
            for (int dd = -1; dd <= 1; dd++) {
                if (bd + dd >= 0 && bd + dd < 21) reserved[bl][bd + dd] = true;
                if (gd + dd >= 0 && gd + dd < 21) reserved[gl][gd + dd] = true;
            }
            b.coop++;
        }
        // obstaculos pequenos nos trechos livres de cada pista
        for (int i = 0; i < 2; i++) {
            int d = 0;
            while (d < 21) {
                if (reserved[i][d]) { d++; continue; }
                int run = 0;
                while (d + run < 21 && !reserved[i][d + run]) run++;
                laneHazard(b, lane[i], owner[i], d, run);
                d += run;
            }
        }
    }

    static void laneHazard(B b, Cor c, int owner, int d, int run) {
        if (run < 3) { for (int k = 0; k < run; k++) b.flat.add(new int[]{c.xa + d + k, c.g(), owner}); return; }
        P p = new P(b, c, d);
        int w = Math.min(run - 2, 3);
        int kind = b.r.nextInt(4);
        if (kind == 0 || w < 2) { // poca do outro (que mata o dono) ou verde
            char t = b.chance(0.5) ? 'G' : (owner == Art.MIMI ? 'C' : 'J');
            for (int k = 1; k <= w; k++) p.at(k, c.floor, t);
            p.at(1 + w / 2, c.g() - 1, owner == Art.MIMI ? 'r' : 'c');
            b.mech.add("Poças");
        } else if (kind == 1) {
            for (int k = 1; k <= w; k++) { p.at(k, c.floor, 'G'); p.at(k, c.g(), '~'); }
            b.mech.add("Biscoito crocante");
        } else if (kind == 2) {
            p.at(1, c.g(), '#');
            if (w >= 2) p.at(2, c.g(), '#');
            p.at(1, c.g() - 1, owner == Art.MIMI ? 'r' : 'c');
        } else {
            for (int k = 1; k <= w; k++) p.at(k, c.floor, owner == Art.MIMI ? 'J' : 'C');
            p.at(1 + w / 2, c.g() - 1, '*');
        }
        b.segs++;
    }

    // ===================================================================== conectores entre andares
    static final int STAIRS = 0, LADDER = 1, FAN = 2, ELEV = 3, TRAMP = 4, WATER = 5, PORTAL = 6, STAIRS_BEAT = 7, STAIRS_CRUMBLE = 8;

    static int pickConnector(B b) {
        int[] pool;
        switch (b.wi) {
            case 1: pool = new int[]{WATER, WATER, WATER, STAIRS, LADDER, ELEV, FAN}; break;
            case 2: pool = new int[]{STAIRS, LADDER, ELEV, TRAMP, PORTAL}; break;
            case 3: pool = new int[]{FAN, FAN, TRAMP, LADDER, ELEV, STAIRS_CRUMBLE}; break;
            case 4: pool = new int[]{STAIRS_BEAT, STAIRS_BEAT, ELEV, LADDER, STAIRS}; break;
            case 5: pool = new int[]{STAIRS_CRUMBLE, STAIRS_CRUMBLE, TRAMP, FAN, ELEV}; break;
            case 6: pool = new int[]{ELEV, ELEV, PORTAL, LADDER, STAIRS}; break;
            case 7: pool = new int[]{STAIRS, LADDER, FAN, TRAMP, PORTAL, ELEV}; break;
            case 8: pool = new int[]{PORTAL, PORTAL, LADDER, STAIRS, ELEV}; break;
            default: pool = new int[]{STAIRS, LADDER, FAN, ELEV, TRAMP, WATER, PORTAL, STAIRS_BEAT, STAIRS_CRUMBLE}; break;
        }
        return pool[b.r.nextInt(pool.length)];
    }

    /**
     * Liga o corredor a (de baixo) ao b (de cima). right = poco no lado direito (colunas 25-28),
     * senao no esquerdo (1-4). Quem sobe sai pro lado de dentro (coluna 24 ou 5).
     */
    static void connector(B b, Cor a, Cor up, boolean right) {
        int type = pickConnector(b);
        int FA = a.floor, FB = up.floor, D = FA - FB;
        // colunas do poco, "far" = encostado na parede, "near" = perto da saida
        int far0 = right ? 27 : 1, far1 = right ? 28 : 2;
        int near0 = right ? 25 : 3, near1 = right ? 26 : 4;
        int exitCol = right ? 24 : 5;
        boolean space = b.wi == 7 && D >= 7;
        b.conns++;
        switch (type) {
            case STAIRS: case STAIRS_BEAT: case STAIRS_CRUMBLE: {
                int r1, r2;
                if (space) { r1 = FA - 3; r2 = FA - 6; }
                else if (D == 5) { r1 = FA - 1; r2 = FA - 3; }
                else { r1 = FA - 1; r2 = FA - 2; }
                char c1 = '#', c2 = '#';
                if (type == STAIRS_BEAT) { c1 = b.L("beat 0"); c2 = b.L("beat 1"); b.mech.add("Blocos do relógio"); }
                if (type == STAIRS_CRUMBLE) { c1 = '~'; c2 = '~'; b.mech.add("Biscoito crocante"); }
                for (int y = r1; y <= FA - 1; y++) { b.set(far0, y, c1); b.set(far1, y, c1); if (type != STAIRS) break; }
                if (type == STAIRS) for (int y = r1; y <= FA - 1; y++) { b.set(far0, y, '#'); b.set(far1, y, '#'); }
                b.set(near0, r2, c2); b.set(near1, r2, c2);
                break;
            }
            case LADDER: {
                if (space) { b.set(far0, FA - 3, '-'); b.set(far1, FA - 3, '-'); b.set(near0, FA - 6, '-'); b.set(near1, FA - 6, '-'); }
                else if (D == 5) { b.set(far0, FA - 2, '-'); b.set(far1, FA - 2, '-'); b.set(near0, FA - 4, '-'); b.set(near1, FA - 4, '-'); }
                else { for (int x = Math.min(near0, far1); x <= Math.max(near0, far1); x++) if (x != (right ? 28 : 1)) b.set(x, FA - 2, '-'); }
                break;
            }
            case FAN: {
                int fx = right ? 25 : 4;
                b.set(fx, FA, b.L("fan - " + (D + 2)));
                b.mech.add("Ventiladores");
                break;
            }
            case ELEV: {
                String c = b.ch();
                char e = b.L("elev " + c + " 0 -" + (D - 1));
                int ex0 = right ? 25 : 2;
                for (int x = ex0; x < ex0 + 3; x++) b.set(x, FA - 1, e);
                int bA = right ? 22 : 7, bB = right ? 22 : 7;
                b.set(bA, FA - 1, b.L("button " + c));
                b.set(bB, FB - 1, b.L("button " + c));
                // reserva o espaco dos botoes nos corredores
                if (right) { a.xb = Math.min(a.xb, 20); up.xb = Math.min(up.xb, 20); }
                else { a.xa = Math.max(a.xa, 9); up.xa = Math.max(up.xa, 9); }
                b.mech.add("Elevador em dupla");
                b.coop++;
                break;
            }
            case TRAMP: {
                for (int x = Math.min(far0, near1); x <= Math.max(far1, near1); x++)
                    if (x != (right ? 25 : 4)) b.set(x, FA, 'T');
                b.mech.add("Gelatina");
                break;
            }
            case WATER: {
                int x0 = right ? 25 : 1;
                for (int y = FB; y <= FA - 1; y++) for (int x = x0; x < x0 + 4; x++) b.set(x, y, 'W');
                b.mech.add("Água");
                break;
            }
            default: { // PORTAL
                char pc = b.L("portal " + b.portal++);
                b.set(right ? 27 : 2, FA - 1, pc);
                b.set(exitCol, FB - 1, pc);
                b.mech.add("Portais");
                break;
            }
        }
    }

    // ===================================================================== pedacos
    static final int S_POOL = 0, S_TWOPOOLS = 1, S_BLOCK = 2, S_CLOUD = 3, S_CRUMBLE = 4, S_GATEBTN = 5, S_BOXPIT = 6,
        S_CONVEYOR = 7, S_MOVER = 8, S_ICE = 9, S_TIMED = 10, S_WATER = 11, S_KEYPOOL = 12, S_KEYCLOUD = 13,
        S_WIND = 14, S_BEATBRIDGE = 15, S_BEATWALLS = 16, S_GEYSER = 17, S_LASERBTN = 18, S_LASERBLINK = 19,
        S_ORBCEIL = 20, S_PILLARS = 21, S_SWAP = 22;

    static int[] segPool(B b) {
        switch (b.wi) {
            case 1: return new int[]{S_WATER, S_WATER, S_WATER, S_POOL, S_TWOPOOLS, S_BLOCK, S_CLOUD, S_GATEBTN, S_MOVER, S_ICE};
            case 2: return new int[]{S_KEYPOOL, S_KEYPOOL, S_KEYCLOUD, S_POOL, S_TWOPOOLS, S_BLOCK, S_CRUMBLE, S_GATEBTN, S_BOXPIT, S_CLOUD};
            case 3: return new int[]{S_WIND, S_WIND, S_WIND, S_CRUMBLE, S_CRUMBLE, S_CLOUD, S_POOL, S_MOVER, S_GATEBTN, S_TIMED};
            case 4: return new int[]{S_BEATBRIDGE, S_BEATBRIDGE, S_BEATWALLS, S_BEATWALLS, S_TIMED, S_CONVEYOR, S_GATEBTN, S_POOL, S_BOXPIT};
            case 5: return new int[]{S_GEYSER, S_GEYSER, S_GEYSER, S_CONVEYOR, S_CRUMBLE, S_MOVER, S_POOL, S_GATEBTN, S_BOXPIT};
            case 6: return new int[]{S_LASERBTN, S_LASERBTN, S_LASERBLINK, S_LASERBLINK, S_BOXPIT, S_GATEBTN, S_TIMED, S_POOL, S_CONVEYOR};
            case 7: return new int[]{S_ORBCEIL, S_ORBCEIL, S_PILLARS, S_PILLARS, S_POOL, S_CLOUD, S_MOVER, S_GATEBTN, S_CRUMBLE};
            case 8: return new int[]{S_SWAP, S_SWAP, S_SWAP, S_POOL, S_TWOPOOLS, S_CRUMBLE, S_GATEBTN, S_KEYPOOL, S_BLOCK};
            default: return new int[]{S_WATER, S_KEYPOOL, S_WIND, S_BEATBRIDGE, S_GEYSER, S_LASERBTN, S_LASERBLINK, S_ORBCEIL, S_SWAP,
                S_CRUMBLE, S_MOVER, S_CONVEYOR, S_GATEBTN, S_BOXPIT, S_TIMED, S_TWOPOOLS};
        }
    }

    /** Preenche um corredor com pedacos, deixando chao livre entre eles. */
    static void fill(B b, Cor c) {
        int[] pool = segPool(b);
        int len = c.len();
        int d = 0;
        int gapMin = b.n >= 6 ? 1 : 2, gapMax = b.n >= 6 ? 2 : 3;
        int lead = 1;
        for (int k = 0; k < lead; k++) b.flat.add(new int[]{gx(c, d + k), c.g()});
        d += lead;
        int tries = 0;
        boolean signature = false;
        int last = -1;
        while (d < len - 2 && tries < 30) {
            tries++;
            int rem = len - d;
            int s;
            if (!signature && b.chance(0.55)) { s = pool[0]; } else s = pool[b.r.nextInt(pool.length)];
            if (s == last && tries < 25) continue; // evita repetir o mesmo pedaco colado
            int used = place(b, c, d, rem, s);
            if (used < 0) continue;
            last = s;
            if (s == pool[0]) signature = true;
            b.segs++;
            d += used;
            int gap = b.range(gapMin, gapMax);
            for (int k = 0; k < gap && d < len; k++) { b.flat.add(new int[]{gx(c, d), c.g()}); d++; }
        }
        while (d < len) { b.flat.add(new int[]{gx(c, d), c.g()}); d++; }
    }

    static int gx(Cor c, int d) { return c.dir > 0 ? c.xa + d : c.xb - d; }

    static int place(B b, Cor c, int d, int rem, int s) {
        P p = new P(b, c, d);
        Phys ph = phys(b, c);
        int air = c.air(), g = c.g(), F = c.floor, T = c.top;
        switch (s) {
            case S_POOL: {
                int w = b.range(1, ph.maxPool);
                if (w + 2 > rem) return -1;
                char t = "JCG".charAt(b.r.nextInt(3));
                for (int k = 1; k <= w; k++) p.at(k, F, t);
                char gem = t == 'J' ? 'c' : t == 'C' ? 'r' : (b.chance(0.3) ? '*' : (b.chance(0.5) ? 'r' : 'c'));
                p.at(1 + (w - 1) / 2, g - 1, gem);
                b.mech.add("Poças");
                return w + 2;
            }
            case S_TWOPOOLS: {
                if (8 > rem) return -1;
                boolean jFirst = b.chance(0.5);
                char a = jFirst ? 'J' : 'C', z = jFirst ? 'C' : 'J';
                p.at(1, F, a); p.at(2, F, a); p.at(5, F, z); p.at(6, F, z);
                p.at(1, g - 1, a == 'J' ? 'c' : 'r');
                p.at(6, g - 1, z == 'J' ? 'c' : 'r');
                b.mech.add("Poças");
                return 8;
            }
            case S_BLOCK: {
                int h = b.range(1, Math.max(1, Math.min(ph.maxBlock, air - 2)));
                int w = b.range(1, 3);
                if (w + 2 > rem) return -1;
                for (int k = 1; k <= w; k++) for (int y = g - h + 1; y <= g; y++) p.at(k, y, '#');
                p.at(1 + (w - 1) / 2, g - h, h >= 2 || b.wi == 7 ? '*' : (b.chance(0.5) ? 'r' : 'c'));
                return w + 2;
            }
            case S_CLOUD: {
                if (air < 4 || 5 > rem) return -1;
                int lift = b.wi == 7 ? Math.min(air - 2, 4) : 2;
                for (int k = 1; k <= 3; k++) { p.at(k, F, 'G'); p.at(k, g - lift, '-'); }
                p.at(1, g - lift - 1, 'r');
                p.at(3, g - lift - 1, 'c');
                b.mech.add("Nuvens");
                return 5;
            }
            case S_CRUMBLE: {
                int w = b.range(3, b.wi == 7 ? 6 : 5);
                if (w + 2 > rem || air < 3) return -1;
                for (int k = 1; k <= w; k++) { p.at(k, F, 'G'); p.at(k, g, '~'); }
                if (air >= 4) p.at(1 + w / 2, g - 2, '*');
                b.mech.add("Biscoito crocante");
                return w + 2;
            }
            case S_GATEBTN: {
                if (5 > rem) return -1;
                String ch = b.ch();
                int v = b.r.nextInt(3);
                String left = v == 0 ? "button " + ch : v == 1 ? "pbutton " + ch : "cbutton " + ch;
                String right = v == 0 ? "button " + ch : v == 1 ? "cbutton " + ch : "pbutton " + ch;
                p.at(0, g, left);
                for (int y = T; y <= g; y++) p.at(2, y, "gate " + ch);
                p.at(4, g, right);
                b.mech.add("Botão em dupla");
                b.coop++;
                return 5;
            }
            case S_BOXPIT: {
                if (8 > rem || air < 3) return -1;
                String ch = b.ch();
                // muretinha de 2 no comeco: a caixa nao escapa pra tras
                p.at(0, g, '#'); p.at(0, g - 1, '#');
                for (int k = 1; k <= 6; k++) if (k != 5) p.at(k, g, '#');
                p.at(5, g, "button " + ch);
                p.at(2, g - 1, 'X');
                for (int y = T; y <= g; y++) p.at(7, y, "gate " + ch);
                if (air >= 4) p.at(4, g - 2, '*');
                b.mech.add("Caixa no buraco");
                return 8;
            }
            case S_CONVEYOR: {
                int w = b.range(4, 6);
                if (w + 4 > rem) return -1;
                for (int k = 1; k <= w; k++) p.at(k, F, p.conv());
                p.at(w + 1, F, 'G'); p.at(w + 2, F, 'G');
                p.at(2, g - 1, 'r');
                p.at(Math.min(w, 4), g - 1, 'c');
                b.mech.add("Esteiras");
                return w + 4;
            }
            case S_MOVER: {
                int w = b.range(5, b.wi == 7 ? 8 : 7);
                if (w + 2 > rem || air < 3) return -1;
                for (int k = 1; k <= w; k++) p.at(k, F, 'G');
                String spec = "mover " + ((w - 2) * c.dir) + " 0";
                p.at(1, g, spec); p.at(2, g, spec);
                if (air >= 4) p.at(1 + w / 2, g - 2, '*');
                b.mech.add("Plataforma móvel");
                return w + 2;
            }
            case S_ICE: {
                if (8 > rem) return -1;
                for (int k = 1; k <= 4; k++) p.at(k, F, 'I');
                char t = b.chance(0.5) ? 'J' : 'C';
                p.at(5, F, t); p.at(6, F, t);
                p.at(2, g - 1, 'r'); p.at(3, g - 1, 'c');
                b.mech.add("Gelo");
                return 8;
            }
            case S_TIMED: {
                if (7 > rem) return -1;
                String ch = b.ch();
                p.at(0, g, "tbutton " + ch + " 4");
                for (int y = T; y <= g; y++) p.at(4, y, "gate " + ch);
                p.at(6, g, "lever " + ch);
                b.mech.add("Botão com tempo");
                b.coop++;
                return 7;
            }
            case S_WATER: {
                int w = b.range(6, 9);
                if (w + 2 > rem || air < 3) return -1;
                for (int k = 1; k <= w; k++) for (int y = T; y <= g; y++) p.at(k, y, 'W');
                // bloco pendurado: passar por baixo
                for (int y = T; y <= g - 1; y++) p.at(2, y, '#');
                // bloco no chao: passar por cima
                int fh = air >= 4 ? 2 : 1;
                for (int y = g - fh + 1; y <= g; y++) p.at(w - 1, y, '#');
                if (w >= 7) { p.at(4, F, 'G'); p.at(5, F, 'G'); }
                p.at(3, T, 'r');
                p.at(w, T, 'c');
                if (w >= 8) p.at(6, T, '*');
                b.mech.add("Água");
                return w + 2;
            }
            case S_KEYPOOL: {
                if (6 > rem) return -1;
                int grp = b.group++;
                char t = b.chance(0.5) ? 'J' : 'C';
                p.at(1, F, t); p.at(2, F, t);
                // a chave fica no meio da poca (na celula da esquerda, deslocada meio tile)
                b.set(Math.min(p.x(1), p.x(2)), g, b.L("key " + grp + " deep"));
                for (int y = T; y <= g; y++) p.at(4, y, "lock " + grp);
                p.at(2, g - 1, t == 'J' ? 'c' : 'r');
                b.mech.add("Chaves e cadeados");
                b.coop++;
                return 6;
            }
            case S_KEYCLOUD: {
                if (air < 4 || 6 > rem) return -1;
                int grp = b.group++;
                p.at(1, g - 2, '-'); p.at(2, g - 2, '-');
                p.at(1, g - 3, "key " + grp);
                p.at(2, F, 'G');
                for (int y = T; y <= g; y++) p.at(4, y, "lock " + grp);
                b.mech.add("Chaves e cadeados");
                return 6;
            }
            case S_WIND: {
                boolean forward = b.chance(0.5);
                int w = forward ? b.range(2, 3) : 2;
                if (w + 3 > rem) return -1;
                char wc = p.wind(forward);
                for (int k = 0; k <= w + 1; k++) for (int y = T; y <= g; y++) p.at(k, y, wc);
                for (int k = 1; k <= w; k++) p.at(k, F, 'G');
                p.at(1 + w / 2, g - 1, b.chance(0.5) ? 'r' : 'c');
                b.mech.add("Vento");
                return w + 3;
            }
            case S_BEATBRIDGE: {
                int w = b.chance(0.5) ? 4 : 6;
                if (w + 2 > rem || air < 3) return -1;
                for (int k = 1; k <= w; k++) {
                    p.at(k, F, 'G');
                    p.at(k, g, "beat " + (((k - 1) / 2) % 2));
                }
                if (air >= 4) p.at(1 + w / 2, g - 2, '*');
                b.mech.add("Blocos do relógio");
                return w + 2;
            }
            case S_BEATWALLS: {
                if (6 > rem) return -1;
                for (int y = T; y <= g; y++) { p.at(1, y, "beat 0"); p.at(4, y, "beat 1"); }
                p.at(2, g, b.chance(0.5) ? 'r' : 'c');
                b.mech.add("Blocos do relógio");
                return 6;
            }
            case S_GEYSER: {
                int w = b.range(2, Math.min(3, ph.maxPool));
                if (w + 2 > rem) return -1;
                for (int k = 1; k <= w; k++) p.at(k, F, 'G');
                int off = b.r.nextInt(150);
                p.at(1, g, "blob 150 " + off + " 3");
                if (w == 3) p.at(3, g, "blob 150 " + ((off + 75) % 150) + " 3");
                b.mech.add("Bolhas de lava");
                return w + 2;
            }
            case S_LASERBTN: {
                if (5 > rem || air < 3) return -1;
                String ch = b.ch();
                p.at(0, g, "button " + ch);
                p.at(2, T, "laser D " + ch);
                p.at(4, g, "button " + ch);
                b.mech.add("Lasers");
                b.coop++;
                return 5;
            }
            case S_LASERBLINK: {
                int k = b.chance(0.5) ? 1 : 2;
                int w = k == 1 ? 3 : 5;
                if (w > rem || air < 3) return -1;
                int off = b.r.nextInt(140);
                p.at(1, T, "laserblink D 70 " + off);
                if (k == 2) p.at(3, T, "laserblink D 70 " + ((off + 70) % 140));
                b.mech.add("Lasers");
                return w;
            }
            case S_ORBCEIL: {
                int w = ph.orbPool + b.r.nextInt(2);
                if (w + 2 > rem || air < 4) return -1;
                for (int k = 1; k <= w; k++) p.at(k, F, 'G');
                p.at(0, g - 1, '%');
                p.at(w + 1, T + 1, '%');
                p.at(1 + w / 2, T, b.chance(0.5) ? 'r' : 'c');
                b.mech.add("Gravidade invertida");
                return w + 2;
            }
            case S_PILLARS: {
                int ph2 = Math.max(2, Math.min(ph.maxBlock, air - 3));
                int gap = b.range(2, 3);
                int w = 2 + gap + 2;
                if (w + 2 > rem) return -1;
                int h1 = b.range(2, ph2), h2 = b.range(2, ph2);
                for (int k = 1; k <= 2; k++) for (int y = g - h1 + 1; y <= g; y++) p.at(k, y, '#');
                for (int k = 3; k < 3 + gap; k++) p.at(k, F, 'G');
                for (int k = 3 + gap; k < 5 + gap; k++) for (int y = g - h2 + 1; y <= g; y++) p.at(k, y, '#');
                p.at(3 + gap, g - h2, '*');
                p.at(1, g - h1, b.chance(0.5) ? 'r' : 'c');
                b.mech.add("Pilares");
                return w + 2;
            }
            case S_SWAP: {
                if (9 > rem || air < 3) return -1;
                int owner = b.chance(0.5) ? Art.MIMI : Art.BISCOITO;
                char cur = owner == Art.MIMI ? 'P' : 'Q';
                char safe = owner == Art.MIMI ? 'J' : 'C';
                for (int y = T; y <= g; y++) { p.at(0, y, cur); p.at(7, y, cur); }
                p.at(1, F, safe); p.at(2, F, safe);
                p.at(4, F, 'G');
                p.at(6, g, '#');
                p.at(2, g - 1, owner == Art.MIMI ? 'r' : 'c');
                p.at(8, g, "swap");
                b.mech.add("Orbe de troca");
                b.coop++;
                return 9;
            }
            default: return -1;
        }
    }

    // ===================================================================== acabamento
    static void finish(B b) {
        int r = 0, c = 0, s = 0;
        for (char[] row : b.m) for (char ch : row) { if (ch == 'r') r++; if (ch == 'c') c++; if (ch == '*') s++; }
        Collections.shuffle(b.flat, b.r);
        Iterator<int[]> it = b.flat.iterator();
        while ((r < 3 || c < 3 || s < 1) && it.hasNext()) {
            int[] f = it.next();
            int x = f[0], y = f[1];
            if (b.m[y][x] != ' ' || b.m[y - 1][x] != ' ' || y + 1 >= H) continue;
            char below = b.m[y + 1][x];
            if (below != '#') continue;
            int own = f.length > 2 ? f[2] : -1; // nas pistas separadas, so o dono alcanca
            if (r < 3 && own != Art.BISCOITO) { b.m[y][x] = 'r'; r++; }
            else if (c < 3 && own != Art.MIMI) { b.m[y][x] = 'c'; c++; }
            else if (s < 1) { b.m[y - 1][x] = '*'; s++; }
        }
        // lanternas no escuro
        boolean dark = (b.wi == 8 && b.n % 2 == 1) || (b.wi == 9 && b.n == 6) || (b.wi == 4 && b.n == 8);
        if (dark) {
            int placed = 0;
            for (int[] f : b.flat) {
                if (placed >= 6) break;
                int x = f[0], y = f[1];
                if (b.m[y][x] == ' ' && b.m[y + 1][x] == '#') { b.m[y][x] = 'L'; placed++; }
            }
        }
    }
}

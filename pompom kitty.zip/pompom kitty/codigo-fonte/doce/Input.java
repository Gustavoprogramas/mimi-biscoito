package doce;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/** Estado do teclado: teclas seguradas, recem-apertadas e caracteres digitados. */
public class Input extends KeyAdapter {
    private final boolean[] down = new boolean[1024];
    private final boolean[] pressedQ = new boolean[1024];
    private final boolean[] pressed = new boolean[1024];
    private final StringBuilder typedQ = new StringBuilder();
    private String typed = "";

    @Override
    public synchronized void keyPressed(KeyEvent e) {
        int k = e.getKeyCode();
        if (k >= 0 && k < down.length) {
            if (!down[k]) pressedQ[k] = true;
            down[k] = true;
        }
    }

    @Override
    public synchronized void keyReleased(KeyEvent e) {
        int k = e.getKeyCode();
        if (k >= 0 && k < down.length) down[k] = false;
    }

    @Override
    public synchronized void keyTyped(KeyEvent e) {
        char c = e.getKeyChar();
        if (c >= 32 && c < 127) typedQ.append(c);
    }

    /** Chamado uma vez por tick, antes da logica. */
    public synchronized void poll() {
        for (int i = 0; i < pressed.length; i++) {
            pressed[i] = pressedQ[i];
            pressedQ[i] = false;
        }
        typed = typedQ.toString();
        typedQ.setLength(0);
    }

    public synchronized void releaseAll() {
        for (int i = 0; i < down.length; i++) down[i] = false;
    }

    public boolean down(int k) { return down[k]; }
    public boolean pressed(int k) { return pressed[k]; }
    public String typed() { return typed; }

    public boolean anyPressed(int... ks) {
        for (int k : ks) if (pressed[k]) return true;
        return false;
    }

    public boolean anyDown(int... ks) {
        for (int k : ks) if (down[k]) return true;
        return false;
    }

    // Atalhos de menu (aceita WASD e setas)
    public boolean up() { return anyPressed(KeyEvent.VK_UP, KeyEvent.VK_W); }
    public boolean downK() { return anyPressed(KeyEvent.VK_DOWN, KeyEvent.VK_S); }
    public boolean left() { return anyPressed(KeyEvent.VK_LEFT, KeyEvent.VK_A); }
    public boolean right() { return anyPressed(KeyEvent.VK_RIGHT, KeyEvent.VK_D); }
    public boolean confirm() { return anyPressed(KeyEvent.VK_ENTER, KeyEvent.VK_SPACE); }
    public boolean back() { return anyPressed(KeyEvent.VK_ESCAPE, KeyEvent.VK_BACK_SPACE); }

    /** Bits de controle de um jogador. */
    public static final int LEFT = 1, RIGHT = 2, JUMP = 4, ACT = 8;

    /** Controles para jogo online: WASD ou setas. */
    public int bitsAny() {
        int b = 0;
        if (anyDown(KeyEvent.VK_LEFT, KeyEvent.VK_A)) b |= LEFT;
        if (anyDown(KeyEvent.VK_RIGHT, KeyEvent.VK_D)) b |= RIGHT;
        if (anyDown(KeyEvent.VK_UP, KeyEvent.VK_W, KeyEvent.VK_SPACE)) b |= JUMP;
        if (anyDown(KeyEvent.VK_DOWN, KeyEvent.VK_S)) b |= ACT;
        return b;
    }

    /** Jogador 1 no modo local: WASD. */
    public int bitsWASD() {
        int b = 0;
        if (down(KeyEvent.VK_A)) b |= LEFT;
        if (down(KeyEvent.VK_D)) b |= RIGHT;
        if (down(KeyEvent.VK_W)) b |= JUMP;
        if (down(KeyEvent.VK_S)) b |= ACT;
        return b;
    }

    /** Jogador 2 no modo local: setas. */
    public int bitsArrows() {
        int b = 0;
        if (down(KeyEvent.VK_LEFT)) b |= LEFT;
        if (down(KeyEvent.VK_RIGHT)) b |= RIGHT;
        if (down(KeyEvent.VK_UP)) b |= JUMP;
        if (down(KeyEvent.VK_DOWN)) b |= ACT;
        return b;
    }
}

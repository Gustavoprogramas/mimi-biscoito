package doce;

/**
 * As fases. Cada mapa tem 30x17 tiles.
 *
 * Legenda fixa:
 *  #  parede          -  plataforma de nuvem (passa por baixo)
 *  I  gelo            <  > esteiras        T  gelatina (trampolim)
 *  J  geleia de morango (so Mimi)  C  calda de chocolate (so Biscoito)  G  gosma verde (ninguem)
 *  P  cortina rosa (so Mimi passa) Q  cortina marrom (so Biscoito passa)
 *  ~  biscoito que quebra    X  caixa de presente    %  orbe de gravidade   L  lanterna
 *  F  ventilador sempre ligado
 *  m  b  inicio da Mimi / do Biscoito      M  B  portas
 *  r  morango (Mimi)   c  cookie (Biscoito)   *  estrela (qualquer um)
 * Outros caracteres sao definidos na legenda de cada fase (botoes, elevadores, portoes...).
 */
public final class Levels {
    private Levels() {}

    public static final int[] RAINBOW = {0xff6f9f, 0xffa95e, 0xffe36e, 0x8be06a, 0x5ad1e6, 0xb48cff};

    public static final class Def {
        public final String name, mechanic;
        public final String[] map, legend;
        public final int theme, par;
        public final boolean dark;

        Def(String name, String mechanic, int theme, int par, boolean dark, String[] map, String... legend) {
            this.name = name; this.mechanic = mechanic; this.theme = theme; this.par = par; this.dark = dark;
            this.map = map; this.legend = legend;
        }
    }

    private static final Def[] LEVELS = {
        new Def("Jardim de Morangos", "Poças e docinhos", 0, 60, false, new String[]{
            "##############################",
            "#        5                   #",
            "#                            #",
            "#  M  B                      #",
            "#########################    #",
            "#   4            *           #",
            "#                          ###",
            "#       r c     ##       #####",
            "#   ########GGG###############",
            "#    2                       #",
            "###          3               #",
            "####     r     c             #",
            "#########JJ####CC##GG####    #",
            "# 1                          #",
            "#       r    c             ###",
            "# m b                    #####",
            "########JJ###CC###GGG#########",
        },
            "1 text SETAS OU WASD: ANDAR E PULAR",
            "2 text GELEIA ROSA: SÓ A MIMI PASSA",
            "3 text CHOCOLATE: SÓ O BISCOITO",
            "4 text VERDE: NINGUÉM ENCOSTA!",
            "5 text OS DOIS NAS PORTAS PRA VENCER!"),

        new Def("Elevador de Bala", "Botões e elevadores", 1, 90, false, new String[]{
            "##############################",
            "#                            #",
            "#                            #",
            "#                            #",
            "#  M  B    3                 #",
            "###############              #",
            "#                            #",
            "#                            #",
            "#                           *#",
            "#                          ###",
            "#     r 4      55   c 2      #",
            "#  #####################     #",
            "#                            #",
            "#        8                   #",
            "#       r                    #",
            "#66  m b    1     c     777  #",
            "##############################",
        },
            "1 button A", "2 button B", "3 button C", "4 button C",
            "5 elev C 0 -5", "6 elev B 0 -4", "7 elev A 0 -4",
            "8 text UM SEGURA O BOTÃO, O OUTRO SOBE!"),

        new Def("Alavancas e Caixas", "Alavanca, caixa e pezinho", 2, 120, false, new String[]{
            "##############################",
            "#                            #",
            "#                            #",
            "#  M  B                      #",
            "###########               *  #",
            "#             c              #",
            "#           -----            #",
            "#                  r         #",
            "#                -----       #",
            "#        7                 4 #",
            "#        g        h    #######",
            "#  8     g        h    #######",
            "#        g 9      h    #######",
            "#        g  r c   h    #######",
            "# m b 1  g X      h  ee#######",
            "#################2############",
            "##############################",
        },
            "1 lever A", "2 button B", "4 lever C", "e elev C 0 -4", "g gate A", "h gate B",
            "7 text PEZINHO: SUBA NA CABEÇA DO AMIGO!",
            "8 text S/↓: ALAVANCA",
            "9 text CAIXA NO BURACO!"),

        new Def("Nuvens de Algodão-Doce", "Ventiladores", 3, 100, false, new String[]{
            "##############################",
            "#                          * #",
            "#  1                         #",
            "#                            #",
            "# M  B    5                  #",
            "##############               #",
            "#                            #",
            "#                     r c    #",
            "#                   -----    #",
            "#                  6         #",
            "#         ####k#JJ##         #",
            "#                            #",
            "#  9                         #",
            "#             r              #",
            "#                            #",
            "# m b                8     c #",
            "#########F###GGG###########7##",
        },
            "1 text BOTÃO LIGA O VENTILADOR DO AMIGO",
            "5 button C", "6 button C", "8 button D",
            "k fan C 7", "7 fan D 15",
            "9 text VENTO DE ALGODÃO-DOCE TE LEVA PRA CIMA!"),

        new Def("Rinque de Sorvete", "Gelo, gelatina e biscoito crocante", 4, 100, false, new String[]{
            "##############################",
            "#                            #",
            "#                            #",
            "#       6              M  B  #",
            "#    #########################",
            "#                            #",
            "#1111                     *  #",
            "#                            #",
            "#    4                       #",
            "#     2   r           c      #",
            "#TTT########~~~~~#######     #",
            "#          5                 #",
            "#                            #",
            "#     3                      #",
            "#       r   c                #",
            "#m b                         #",
            "#####IIIIIIIIIIIIIIJJ#CC#TTT##",
        },
            "1 gate A", "2 button A", "6 button A",
            "3 text GELO ESCORREGA! CUIDADO NO FIM",
            "4 text UM NO BOTÃO, O OUTRO PULA NA GELATINA!",
            "5 text BISCOITO CROCANTE QUEBRA!"),

        new Def("Fábrica de Doces", "Esteiras e botão com tempo", 5, 110, false, new String[]{
            "##############################",
            "#                            #",
            "#                            #",
            "#          *                 #",
            "#            r  c        M B #",
            "#      ###GG<<<<<<<<<<<#######",
            "#        a                   #",
            "#  ----  a                   #",
            "#        a                   #",
            "#  4     a     r c           #",
            "############<<<<<<<<<###     #",
            "#                 h 6        #",
            "#         r c     h     -----#",
            "# 5               h          #",
            "#m b X            h        3 #",
            "#######>>>>>>>>2##############",
            "##############################",
        },
            "2 button B", "3 tbutton A 4", "4 lever A", "a gate A", "h gate B",
            "5 text ESTEIRA LEVA A CAIXA!",
            "6 text BOTÃO COM TEMPO: CORRE!"),

        new Def("Portais Arco-Íris", "Portais e cortinas", 6, 100, false, new String[]{
            "##############################",
            "#     P              Q       #",
            "#     P              Q       #",
            "#  M  P       7      Q  B    #",
            "##############################",
            "#                   a        #",
            "#######             a        #",
            "#  o  #             a        #",
            "# *   #             a        #",
            "#  1  # r 7       c a  2 9   #",
            "#############    #############",
            "#        P          Q        #",
            "#3       P 4        Q5       #",
            "#   r    P          Q  c     #",
            "#        P          Q        #",
            "# 9      P m eeee b Q   X  o #",
            "##############################",
        },
            "1 button A", "2 button B", "a gate A", "e elev B 0 -5",
            "7 portal 3", "9 portal 1", "o portal 2",
            "3 text SÓ MIMI", "4 text CAIXA NO PORTAL!", "5 text SÓ BISCOITO"),

        new Def("Mundo de Cabeça pra Baixo", "Gravidade invertida", 7, 90, false, new String[]{
            "##############################",
            "##############################",
            "##############################",
            "##############################",
            "#  r c   1        g   *      #",
            "#                 g      %   #",
            "#%                g          #",
            "#                 g          #",
            "#                 g          #",
            "#    2                       #",
            "#  3                         #",
            "#           a                #",
            "#           a                #",
            "#   %       a   r c          #",
            "#           a                #",
            "# m b    r ca  4          M B#",
            "#######JJ##########CC#########",
        },
            "1 button A", "4 button B", "a gate A", "g gate B",
            "2 text TOQUE NA ESFERA: GRAVIDADE AO CONTRÁRIO!",
            "3 text UM NO TETO, OUTRO NO CHÃO!"),

        new Def("Noite do Pijama", "Escuro, lanternas e plataformas", 8, 100, true, new String[]{
            "##############################",
            "#                            #",
            "#                            #",
            "#                            #",
            "#                            #",
            "#                            #",
            "# M B  L   r     c   L       #",
            "#########~~~~~~#######       #",
            "#                            #",
            "#                     --     #",
            "#         *                  #",
            "#              55        L 3 #",
            "#        r  c           ######",
            "#     44                ######",
            "# 6                     ######",
            "#m b 2                  ######",
            "######GGGGGGGGGGGGGGGGGG######",
        },
            "2 button B", "3 lever B", "4 mover 7 0", "5 mover 7 0 B",
            "6 text ESCURINHO... ACENDA AS LANTERNAS!"),

        new Def("Castelo do Bolo Gigante", "Tudo junto!", 9, 150, false, new String[]{
            "##############################",
            "#     d     *       # o #    #",
            "#     d   %         #   #    #",
            "#     d        %    # 4 #    #",
            "#     d             #####    #",
            "# M B d   r    c         7   #",
            "###########################  #",
            "# y                          #",
            "#                          tt#",
            "#                            #",
            "#5     X    6 3 8     r c    #",
            "#<<<<<<### ######## IIIIIIITT#",
            "#             ##             #",
            "# 9           ##  0          #",
            "#    r        ##        c    #",
            "#m    1       ##    2      b #",
            "####JJ####f########g####CC####",
        },
            "1 pbutton R", "2 cbutton L", "3 button R", "8 button L",
            "f fan L 7", "g fan R 7", "6 tbutton T 4", "t gate T", "7 lever T",
            "4 button D", "d gate D", "5 portal 1", "o portal 1",
            "9 text BOTÃO ROSA: SÓ MIMI", "0 text BOTÃO MARROM: SÓ BISCOITO",
            "y text CAIXA NO PORTAL ABRE AS PORTAS!"),
    };

    public static int count() { return LEVELS.length; }

    public static Def get(int i) { return LEVELS[Math.max(0, Math.min(LEVELS.length - 1, i))]; }

    // ---------------------------------------------------------------- temas
    public static final class Theme {
        public final int skyTop, skyBot, sponge, spongeDark, frost, frostDark, deco;
        public final int[] sprinkles;
        Theme(int skyTop, int skyBot, int sponge, int spongeDark, int frost, int frostDark, int deco, int... sprinkles) {
            this.skyTop = skyTop; this.skyBot = skyBot; this.sponge = sponge; this.spongeDark = spongeDark;
            this.frost = frost; this.frostDark = frostDark; this.deco = deco; this.sprinkles = sprinkles;
        }
    }

    // deco: 0 nuvens+morangos, 1 balas, 2 cookies, 3 nuvens, 4 flocos, 5 rosquinhas, 6 arco-iris+estrelas, 7 planetas, 8 lua, 9 castelo
    public static final Theme[] THEMES = {
        new Theme(0xbff0e0, 0xfff3f8, 0xf6d7a7, 0xd9ad74, 0xff8fb4, 0xe0577f, 0, 0xffffff, 0xffe36e, 0x7ad67a),
        new Theme(0xd9c8ff, 0xfff0fb, 0xf3d6ff, 0xc9a3e6, 0xb48cff, 0x7e5bd6, 1, 0xff6f9f, 0xffe36e, 0x5ad1e6),
        new Theme(0xffd9b8, 0xfff6e8, 0xe0a865, 0xb47a3e, 0x7a4a2a, 0x4f2c17, 2, 0xffffff, 0xff8fb4, 0xffe36e),
        new Theme(0xa8d8ff, 0xfde2ff, 0xfff0f7, 0xf0c4dc, 0xff9ed2, 0xe06aa8, 3, 0x9fd3ff, 0xffe36e, 0xffffff),
        new Theme(0xc8f4ff, 0xfffbe6, 0xbdf2dc, 0x86cfb2, 0xffffff, 0xb6dcef, 4, 0xff8fb4, 0x5ad1e6, 0xffe36e),
        new Theme(0xc9c3e6, 0xf3e9ff, 0xc7bbe3, 0x9384bd, 0x6f5fa8, 0x4a3d80, 5, 0xffe36e, 0xff8fb4, 0x8be06a),
        new Theme(0x3b2a6b, 0x8e5bb5, 0xffd3e8, 0xe39fc4, 0xff6fb5, 0xc94488, 6, 0xffe36e, 0x5ad1e6, 0x8be06a),
        new Theme(0x1f2a5c, 0x5a4b9a, 0x9fd3ff, 0x6a9fd6, 0xffe36e, 0xd9a92b, 7, 0xff8fb4, 0xffffff, 0xb48cff),
        new Theme(0x101633, 0x2a2350, 0x6c5a8e, 0x4b3d68, 0xc9b8ff, 0x8f7ad6, 8, 0xffe36e, 0xffffff, 0xff8fb4),
        new Theme(0xffd6a0, 0xffc2e0, 0xfff0c8, 0xe6c98a, 0xff6f9f, 0xd94478, 9, 0xffd23f, 0xffffff, 0x5ad1e6),
    };
}

package doce;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Desenha um World em pixel art (fundo e tiles ficam em cache). */
public class Render {
    private static final int TS = World.TS;
    private final World w;
    private final Levels.Theme th;
    private final BufferedImage bg, tilesImg;
    private final List<int[]> dyn = new ArrayList<>();
    private BufferedImage darkImg;
    private final java.util.IdentityHashMap<Ents.Gate, BufferedImage> gateImgs = new java.util.IdentityHashMap<>();
    private final java.util.IdentityHashMap<Ents.Fan, BufferedImage> windImgs = new java.util.IdentityHashMap<>();
    private static final BufferedImage[][] PORTAL = new BufferedImage[6][42];
    private static final BufferedImage SHADOW = new BufferedImage(10, 1, BufferedImage.TYPE_INT_ARGB);
    static { for (int i = 0; i < 10; i++) SHADOW.setRGB(i, 0, 0x28000000); }
    private static final Color INK = new Color(0x3b2033), GHOST = new Color(255, 255, 255, 50), WIND = new Color(0xf4f8ff);
    public int localChar = -1; // personagem desta maquina (para a setinha "VOCE")

    public Render(World w) {
        this.w = w;
        this.th = Levels.THEMES[w.def.theme % Levels.THEMES.length];
        bg = new BufferedImage(Main.W, Main.H, BufferedImage.TYPE_INT_RGB);
        tilesImg = new BufferedImage(Main.W, Main.H, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = bg.createGraphics();
        drawBackground(g, th, 0);
        g.dispose();
        g = tilesImg.createGraphics();
        drawTiles(g);
        g.dispose();
    }

    static Color c(int rgb) { return new Color(rgb); }

    // =================================================================== fundo
    public static void drawBackground(Graphics2D g, Levels.Theme th, long t) {
        Color top = c(th.skyTop), bot = c(th.skyBot);
        int bands = 12;
        for (int i = 0; i < bands; i++) {
            Color a = Art.mix(top, bot, i / (double) (bands - 1));
            int y0 = i * Main.H / bands, y1 = (i + 1) * Main.H / bands;
            g.setColor(a);
            g.fillRect(0, y0, Main.W, y1 - y0);
            if (i < bands - 1) { // dithering entre faixas
                g.setColor(Art.mix(top, bot, (i + 1) / (double) (bands - 1)));
                for (int x = (y1 - 2) % 2; x < Main.W; x += 2) g.fillRect(x, y1 - 2, 1, 1);
                for (int x = (y1 - 1) % 2 == 0 ? 1 : 0; x < Main.W; x += 2) g.fillRect(x, y1 - 1, 1, 1);
            }
        }
        Random r = new Random(th.deco * 31L + 7);
        boolean night = (th.skyTop & 0xff) < 0x70 && ((th.skyTop >> 16) & 0xff) < 0x70;
        Color soft = night ? new Color(255, 255, 255, 40) : new Color(255, 255, 255, 120);
        // estrelinhas no ceu noturno
        if (night || th.deco == 6 || th.deco == 7 || th.deco == 8) {
            for (int i = 0; i < 70; i++) {
                int x = r.nextInt(Main.W), y = r.nextInt(Main.H);
                g.setColor(new Color(255, 255, 255, 80 + r.nextInt(150)));
                g.fillRect(x, y, 1, 1);
                if (r.nextInt(6) == 0) { g.fillRect(x - 1, y, 3, 1); g.fillRect(x, y - 1, 1, 3); }
            }
        }
        switch (th.deco) {
            case 0: case 3: // nuvens fofas
                for (int i = 0; i < (th.deco == 3 ? 9 : 6); i++) cloud(g, r.nextInt(Main.W), 10 + r.nextInt(Main.H - 60), 20 + r.nextInt(30), soft);
                if (th.deco == 0) for (int i = 0; i < 8; i++) strawberry(g, r.nextInt(Main.W), r.nextInt(Main.H), new Color(255, 120, 150, 70));
                break;
            case 1:
                for (int i = 0; i < 14; i++) candy(g, r.nextInt(Main.W), r.nextInt(Main.H), new Color(Levels.RAINBOW[i % 6] & 0xffffff | 0x50000000, true));
                break;
            case 2:
                for (int i = 0; i < 10; i++) {
                    int x = r.nextInt(Main.W), y = r.nextInt(Main.H), s = 10 + r.nextInt(14);
                    g.setColor(new Color(224, 168, 101, 70)); g.fillOval(x, y, s, s);
                    g.setColor(new Color(90, 50, 30, 70));
                    for (int k = 0; k < 4; k++) g.fillRect(x + 2 + r.nextInt(s - 4), y + 2 + r.nextInt(s - 4), 2, 2);
                }
                break;
            case 4:
                for (int i = 0; i < 26; i++) {
                    int x = r.nextInt(Main.W), y = r.nextInt(Main.H);
                    g.setColor(new Color(255, 255, 255, 140));
                    g.fillRect(x - 2, y, 5, 1); g.fillRect(x, y - 2, 1, 5);
                    g.fillRect(x - 1, y - 1, 1, 1); g.fillRect(x + 1, y + 1, 1, 1); g.fillRect(x + 1, y - 1, 1, 1); g.fillRect(x - 1, y + 1, 1, 1);
                }
                for (int i = 0; i < 5; i++) cloud(g, r.nextInt(Main.W), 10 + r.nextInt(120), 24, soft);
                break;
            case 5:
                for (int i = 0; i < 9; i++) {
                    int x = r.nextInt(Main.W), y = r.nextInt(Main.H), s = 16 + r.nextInt(16);
                    g.setColor(new Color(255, 160, 200, 60)); g.fillOval(x, y, s, s);
                    g.setColor(Art.mix(c(th.skyTop), c(th.skyBot), 0.5)); g.fillOval(x + s / 3, y + s / 3, s / 3, s / 3);
                }
                break;
            case 6: // arco-iris
                for (int k = 0; k < 6; k++) {
                    g.setColor(new Color(Levels.RAINBOW[k] & 0xffffff | 0x46000000, true));
                    int rad = 200 - k * 8;
                    g.setStroke(new BasicStroke(8));
                    g.drawArc(Main.W / 2 - rad, 230 - rad, rad * 2, rad * 2, 0, 180);
                }
                g.setStroke(new BasicStroke(1));
                break;
            case 7:
                g.setColor(new Color(255, 200, 120, 90)); g.fillOval(360, 30, 40, 40);
                g.setColor(new Color(255, 230, 180, 90)); g.fillRect(350, 49, 60, 3);
                g.setColor(new Color(180, 140, 255, 80)); g.fillOval(60, 150, 26, 26);
                break;
            case 8:
                g.setColor(new Color(255, 250, 220, 200)); g.fillOval(390, 22, 34, 34);
                g.setColor(c(th.skyTop)); g.fillOval(400, 18, 30, 30);
                break;
            case 9:
                g.setColor(new Color(255, 255, 255, 90));
                int bx = 300;
                g.fillRect(bx, 150, 140, 122);
                for (int i = 0; i < 5; i++) g.fillRect(bx + i * 30, 140, 16, 10);
                g.fillRect(bx + 20, 90, 30, 60); g.fillRect(bx + 90, 90, 30, 60);
                for (int i = 0; i < 12; i++) {
                    Color hc = new Color(255, 111, 159, 70);
                    Art.heart(g, r.nextInt(Main.W), r.nextInt(Main.H), hc, 1);
                }
                break;
            default: break;
        }
    }

    static void cloud(Graphics2D g, int x, int y, int s, Color col) {
        g.setColor(col);
        g.fillOval(x, y + s / 4, s, s / 2);
        g.fillOval(x + s / 4, y, s / 2, s / 2);
        g.fillOval(x + s / 2, y + s / 6, s / 2 + 4, s / 2);
    }

    static void strawberry(Graphics2D g, int x, int y, Color col) {
        g.setColor(col);
        g.fillRect(x + 1, y, 6, 2); g.fillRect(x, y + 2, 8, 3); g.fillRect(x + 1, y + 5, 6, 2); g.fillRect(x + 3, y + 7, 2, 1);
    }

    static void candy(Graphics2D g, int x, int y, Color col) {
        g.setColor(col);
        g.fillRect(x + 3, y, 6, 6);
        g.fillRect(x, y + 1, 3, 4);
        g.fillRect(x + 9, y + 1, 3, 4);
    }

    // =================================================================== tiles estaticos
    private boolean solidish(int t) {
        return t == World.SOLID || t == World.ICE || t == World.CONV_L || t == World.CONV_R || t == World.BOUNCE
            || t == World.POOL_J || t == World.POOL_C || t == World.POOL_G;
    }

    private void drawTiles(Graphics2D g) {
        Random r = new Random(w.levelIndex * 977L + 3);
        Color sponge = c(th.sponge), dark = c(th.spongeDark), frost = c(th.frost), frostD = c(th.frostDark);
        Color line = Art.mix(dark, Color.BLACK, 0.35);
        for (int ty = 0; ty < World.ROWS; ty++)
            for (int tx = 0; tx < World.COLS; tx++) {
                int t = w.tiles[ty][tx];
                int x = tx * TS, y = ty * TS;
                switch (t) {
                    case World.SOLID: case World.BOUNCE: case World.POOL_J: case World.POOL_C: case World.POOL_G: {
                        int top = (t == World.POOL_J || t == World.POOL_C || t == World.POOL_G) ? World.POOL_TOP : 0;
                        g.setColor(sponge);
                        g.fillRect(x, y + top, TS, TS - top);
                        // farelos
                        g.setColor(dark);
                        for (int k = 0; k < 4; k++) g.fillRect(x + 1 + r.nextInt(TS - 3), y + top + 2 + r.nextInt(TS - top - 3), 1 + r.nextInt(2), 1);
                        // camada de recheio a cada 2 linhas
                        if (ty % 3 == 1 && top == 0) {
                            g.setColor(Art.mix(frost, sponge, 0.45));
                            g.fillRect(x, y + 8, TS, 2);
                        }
                        boolean openUp = !solidish(w.tile(tx, ty - 1)) && ty > 0;
                        if (top > 0) {
                            g.setColor(line);
                            g.fillRect(x, y + top, TS, 1);
                        } else if (openUp && t == World.SOLID) {
                            g.setColor(frost);
                            g.fillRect(x, y, TS, 4);
                            for (int k = 0; k < TS; k++) {
                                int drip = ((tx * 7 + k * 13) % 9 == 0) ? 3 : ((tx + k) % 5 == 0 ? 1 : 0);
                                if (drip > 0) g.fillRect(x + k, y + 4, 1, drip);
                            }
                            g.setColor(Art.mix(frost, Color.WHITE, 0.45));
                            g.fillRect(x, y, TS, 1);
                            for (int k = 0; k < 3; k++) {
                                g.setColor(c(th.sprinkles[r.nextInt(th.sprinkles.length)]));
                                g.fillRect(x + 1 + r.nextInt(TS - 3), y + 1 + r.nextInt(2), 2, 1);
                            }
                            g.setColor(frostD);
                            for (int k = 0; k < TS; k++) {
                                int drip = ((tx * 7 + k * 13) % 9 == 0) ? 3 : ((tx + k) % 5 == 0 ? 1 : 0);
                                g.fillRect(x + k, y + 4 + drip, 1, 1);
                            }
                        }
                        g.setColor(line);
                        if (!solidish(w.tile(tx - 1, ty)) && tx > 0) g.fillRect(x, y + top, 1, TS - top);
                        if (!solidish(w.tile(tx + 1, ty)) && tx < World.COLS - 1) g.fillRect(x + TS - 1, y + top, 1, TS - top);
                        if (!solidish(w.tile(tx, ty + 1)) && ty < World.ROWS - 1) g.fillRect(x, y + TS - 1, TS, 1);
                        if (t != World.SOLID) dyn.add(new int[]{t, x, y});
                        break;
                    }
                    case World.ICE: {
                        g.setColor(c(0xbfeeff)); g.fillRect(x, y, TS, TS);
                        g.setColor(c(0xe9fbff)); g.fillRect(x, y, TS, 2);
                        g.setColor(Color.WHITE);
                        for (int k = 0; k < 5; k++) g.fillRect(x + 3 + k, y + 10 - k, 1, 1);
                        g.fillRect(x + 10, y + 5, 2, 1);
                        g.setColor(c(0x7fc6e6));
                        g.drawRect(x, y, TS - 1, TS - 1);
                        break;
                    }
                    case World.CONV_L: case World.CONV_R: {
                        g.setColor(c(0x5b4a7a)); g.fillRect(x, y, TS, TS);
                        g.setColor(c(0x3b2f52)); g.fillRect(x, y + 6, TS, 10);
                        g.setColor(c(0xb9a6e0));
                        g.fillOval(x + 2, y + 9, 5, 5); g.fillOval(x + 9, y + 9, 5, 5);
                        dyn.add(new int[]{t, x, y});
                        break;
                    }
                    case World.ONEWAY: {
                        g.setColor(c(0xf3c98b)); g.fillRect(x, y, TS, 5);
                        g.setColor(c(0xc98d4e));
                        for (int k = 0; k < TS; k += 4) g.fillRect(x + k, y + 1, 1, 3);
                        g.fillRect(x, y + 4, TS, 1);
                        g.setColor(c(0xfff0d0)); g.fillRect(x, y, TS, 1);
                        break;
                    }
                    case World.CURT_P: case World.CURT_Q:
                        dyn.add(new int[]{t, x, y});
                        break;
                    default: break;
                }
            }
    }

    // =================================================================== quadro
    // ---- interpolacao: desenha cada coisa entre a posicao do passo anterior e a atual
    private float a = 1f;

    private float lerp(int prev, int cur) {
        return Math.abs(cur - prev) > 20 ? cur : prev + (cur - prev) * a;
    }

    public void render(Graphics2D g, long t) {
        a = Math.max(0f, Math.min(1f, Main.alpha));
        g.drawImage(bg, 0, 0, null);
        for (Ents.Fan f : w.fans) drawWind(g, f, t);
        g.drawImage(tilesImg, 0, 0, null);
        for (int[] d : dyn) drawDyn(g, d[0], d[1], d[2], t);
        if (!w.def.dark) for (Ents.Text tx : w.texts) drawText(g, tx);
        for (Ents.Ent e : w.ents) {
            if (e instanceof Ents.Elevator) {
                Ents.Elevator el = (Ents.Elevator) e;
                int ox = el.x, oy = el.y;
                float fx = lerp(el.px, el.x), fy = lerp(el.py, el.y);
                el.x = (int) Math.floor(fx); el.y = (int) Math.floor(fy);
                double dx = fx - el.x, dy = fy - el.y;
                g.translate(dx, dy);
                drawEnt(g, e, t);
                g.translate(-dx, -dy);
                el.x = ox; el.y = oy;
            } else if (e instanceof Ents.Gate) {
                Ents.Gate gt = (Ents.Gate) e;
                int oh = gt.h;
                gt.h = Math.round(lerp(gt.ph, gt.h));
                drawEnt(g, e, t);
                gt.h = oh;
            } else drawEnt(g, e, t);
        }
        for (World.Box b : w.boxes) {
            float fx = lerp(b.px, b.x), fy = lerp(b.py, b.y);
            int ix = (int) Math.floor(fx), iy = (int) Math.floor(fy);
            double dx = fx - ix, dy = fy - iy;
            g.translate(dx, dy);
            drawBox(g, ix, iy);
            g.translate(-dx, -dy);
        }
        for (World.Player p : w.players) withPlayerAt(g, p, t, false);
        drawParticles(g);
        if (w.def.dark) {
            drawDark(g, t);
            for (Ents.Text tx : w.texts) drawText(g, tx);
        }
        for (World.Player p : w.players) withPlayerAt(g, p, t, true);
    }

    // Os tiles animados (pocas, esteiras, gelatina, cortinas) sao desenhados uma vez por quadro
    // de animacao e guardados como imagem: muito mais leve do que pintar pixel a pixel.
    private final BufferedImage[] frames = new BufferedImage[12 * 256];

    private BufferedImage frame(int type, int idx) {
        int key = type * 256 + idx;
        BufferedImage im = frames[key];
        if (im != null) return im;
        switch (type) {
            case World.POOL_J: im = poolFrame(idx, 0xff5c8a, 0xffa3c2, 0xd63d6b); break;
            case World.POOL_C: im = poolFrame(idx, 0x7a3f1d, 0xb06a3c, 0x55280f); break;
            case World.POOL_G: im = poolFrame(idx, 0x6fd14a, 0xb8f28f, 0x3f9a2a); break;
            case World.CONV_L: case World.CONV_R: {
                im = new BufferedImage(TS, 6, BufferedImage.TYPE_INT_ARGB);
                Graphics2D g = im.createGraphics();
                int dir = type == World.CONV_R ? 1 : -1;
                g.setColor(c(0xffe36e));
                for (int k = -8; k < TS + 8; k += 8) {
                    int ax = k + dir * idx;
                    if (ax < 0 || ax > TS - 4) continue;
                    if (dir > 0) { g.fillRect(ax, 1, 1, 4); g.fillRect(ax + 1, 2, 1, 2); }
                    else { g.fillRect(ax + 2, 1, 1, 4); g.fillRect(ax + 1, 2, 1, 2); }
                }
                g.dispose();
                break;
            }
            case World.BOUNCE: {
                int squish = idx - 1;
                im = new BufferedImage(TS, 9, BufferedImage.TYPE_INT_ARGB);
                Graphics2D g = im.createGraphics();
                g.setColor(c(0x3f9a50)); g.fillRect(1, 1 + squish, TS - 2, 7 - squish);
                g.setColor(c(0x8be06a)); g.fillRect(1, 2 + squish, TS - 2, 5 - squish);
                g.setColor(c(0xd6ffc8)); g.fillRect(3, 3 + squish, 3, 1); g.fillRect(9, 4 + squish, 2, 1);
                g.dispose();
                break;
            }
            case World.CURT_P: case World.CURT_Q: {
                boolean p = type == World.CURT_P;
                Color a = p ? new Color(255, 111, 159, 150) : new Color(150, 95, 55, 160);
                Color b = p ? new Color(255, 200, 220, 120) : new Color(240, 210, 160, 120);
                im = new BufferedImage(TS + 2, TS, BufferedImage.TYPE_INT_ARGB);
                Graphics2D g = im.createGraphics();
                for (int k = 0; k < TS; k += 2) {
                    int wav = (int) Math.round(Math.sin((idx + k * 3) * 0.08));
                    g.setColor(k % 4 == 0 ? a : b);
                    g.fillRect(1 + k + wav, 0, 2, TS);
                }
                g.dispose();
                break;
            }
            default: return null;
        }
        frames[key] = im;
        return im;
    }

    private static BufferedImage poolFrame(int idx, int main, int light, int dark) {
        BufferedImage im = new BufferedImage(TS, 5, BufferedImage.TYPE_INT_ARGB);
        double ph = idx / 32.0 * Math.PI * 2;
        for (int k = 0; k < TS; k++) {
            for (int r = 0; r < 4; r++) im.setRGB(k, r, 0xff000000 | main);
            im.setRGB(k, 4, 0xff000000 | dark);
            int h = (int) Math.round(Math.sin(k * 0.5 + ph));
            im.setRGB(k, h > 0 ? 0 : 1, 0xff000000 | light);
        }
        return im;
    }

    private void drawDyn(Graphics2D g, int type, int x, int y, long t) {
        switch (type) {
            case World.POOL_J: case World.POOL_C: case World.POOL_G: {
                double ph = (x * 0.5 + t * 0.12) % (Math.PI * 2);
                int idx = (int) (ph / (Math.PI * 2) * 32) & 31;
                g.drawImage(frame(type, idx), x, y + 2, null);
                if (type == World.POOL_G && ((t / 20) + x / 16) % 5 == 0) {
                    g.setColor(c(0xd6ffb8));
                    g.fillRect(x + 4 + (x % 7), y + 3 - (int) (t % 20) / 10, 2, 2);
                }
                break;
            }
            case World.CONV_L: case World.CONV_R:
                g.drawImage(frame(type, (int) ((t / 3) % 8)), x, y, null);
                break;
            case World.BOUNCE: {
                int squish = (int) (Math.sin(t * 0.2 + x) * 1.2);
                squish = Math.max(-1, Math.min(1, squish));
                g.drawImage(frame(type, squish + 1), x, y - 2, null);
                break;
            }
            case World.CURT_P: case World.CURT_Q: {
                g.drawImage(frame(type, (int) ((t + y) % 79)), x - 1, y, null);
                if (w.tile(x / TS, y / TS - 1) != type) {
                    boolean p = type == World.CURT_P;
                    g.setColor(p ? c(0xe0577f) : c(0x6b3f1f));
                    g.fillRect(x, y, TS, 2);
                    g.setColor(Color.WHITE);
                    g.fillRect(x + 6, y + 2, 4, 2);
                }
                break;
            }
            default: break;
        }
    }

    private void drawWind(Graphics2D g, Ents.Fan f, long t) {
        if (!f.on) return;
        int h = f.y - f.zoneTop;
        if (h <= 0) return;
        BufferedImage col = windImgs.get(f);
        if (col == null) {
            col = new BufferedImage(Math.max(1, f.w - 4), h, BufferedImage.TYPE_INT_ARGB);
            Graphics2D ig = col.createGraphics();
            ig.setColor(new Color(255, 255, 255, 40));
            ig.fillRect(0, 0, f.w - 4, h);
            ig.dispose();
            windImgs.put(f, col);
        }
        g.drawImage(col, f.x + 2, f.zoneTop, null);
        g.setColor(WIND);
        for (int k = 0; k < f.w / 4 + 2; k++) {
            int lx = f.x + 2 + (k * 5) % (f.w - 4);
            int ly = f.y - (int) ((t * 2 + k * 23) % Math.max(1, h));
            g.fillRect(lx, ly, 1, 4);
        }
    }

    private void drawText(Graphics2D g, Ents.Text tx) {
        boolean night = Levels.THEMES[w.def.theme].deco >= 6;
        Color txt = night ? Color.WHITE : c(0x5a2a4a);
        Color out = night ? new Color(40, 20, 60, 200) : new Color(255, 255, 255, 190);
        PixelFont.outlined(g, tx.text, tx.x, tx.y + 4, txt, out, 1);
    }

    // =================================================================== objetos
    private void drawEnt(Graphics2D g, Ents.Ent e, long t) {
        if (e instanceof Ents.Elevator) {
            Ents.Elevator el = (Ents.Elevator) e;
            Color base = el.ch >= 0 ? c(w.chanColor[el.ch]) : c(0x7fe0c4);
            g.setColor(c(0x3b2033)); g.fillRect(el.x, el.y, el.w, el.h);
            g.setColor(base); g.fillRect(el.x + 1, el.y + 1, el.w - 2, el.h - 2);
            g.setColor(Art.mix(base, Color.WHITE, 0.6));
            g.fillRect(el.x + 1, el.y + 1, el.w - 2, 2);
            g.setColor(Art.mix(base, Color.BLACK, 0.2));
            for (int k = 4; k < el.w - 2; k += 6) g.fillRect(el.x + k, el.y + 4, 3, 2);
        } else if (e instanceof Ents.Gate) {
            Ents.Gate gt = (Ents.Gate) e;
            if (gt.h <= 0) {
                g.setColor(GHOST);
                g.drawRect(gt.x + 2, gt.y, gt.w - 5, gt.fullH - 1);
                return;
            }
            BufferedImage im = gateImgs.get(gt);
            if (im == null) {
                im = new BufferedImage(gt.w, gt.fullH, BufferedImage.TYPE_INT_ARGB);
                Graphics2D ig = im.createGraphics();
                ig.setColor(Color.WHITE); ig.fillRect(1, 0, gt.w - 2, gt.fullH);
                ig.setColor(c(w.chanColor[gt.ch < 0 ? 0 : gt.ch]));
                for (int k = -gt.w - gt.fullH; k < gt.fullH + gt.w; k += 8)
                    ig.fillPolygon(new int[]{0, gt.w, gt.w, 0}, new int[]{k + gt.w, k, k + 4, k + gt.w + 4}, 4);
                ig.dispose();
                gateImgs.put(gt, im);
            }
            // o portao "sobe" mostrando so a parte de baixo das listras
            g.drawImage(im, gt.x, gt.y, gt.x + gt.w, gt.y + gt.h, 0, gt.fullH - gt.h, gt.w, gt.fullH, null);
            g.setColor(INK);
            g.drawRect(gt.x + 1, gt.y, gt.w - 3, gt.h - 1);
        } else if (e instanceof Ents.Crumble) {
            Ents.Crumble cr = (Ents.Crumble) e;
            if (cr.state == 2) {
                g.setColor(new Color(150, 100, 60, 70));
                for (int k = 0; k < TS; k += 3) { g.fillRect(cr.x + k, cr.y, 1, 1); g.fillRect(cr.x + k, cr.y + TS - 1, 1, 1); }
                return;
            }
            int sx = cr.state == 1 ? (int) ((t / 2) % 3) - 1 : 0;
            int x = cr.x + sx, y = cr.y;
            g.setColor(c(0x8a5a2e)); g.fillRect(x, y, TS, TS);
            g.setColor(c(0xe8b46a)); g.fillRect(x + 1, y + 1, TS - 2, TS - 2);
            g.setColor(c(0xf6d08f)); g.fillRect(x + 1, y + 1, TS - 2, 2);
            g.setColor(c(0x5a321a));
            g.fillRect(x + 3, y + 5, 2, 2); g.fillRect(x + 10, y + 4, 2, 2); g.fillRect(x + 6, y + 10, 2, 2); g.fillRect(x + 12, y + 11, 2, 1);
            if (cr.state == 1) { g.setColor(c(0x5a321a)); g.fillRect(x + 7, y + 1, 1, 6); g.fillRect(x + 8, y + 6, 1, 4); }
        } else if (e instanceof Ents.Button) {
            Ents.Button b = (Ents.Button) e;
            Color col = c(w.chanColor[Math.max(0, b.ch)]);
            int ph = b.pressed ? 1 : 3;
            if (!b.ceiling) {
                g.setColor(c(0x3b2033)); g.fillRect(b.x + 1, b.y + 14, 14, 2);
                g.setColor(col); g.fillRect(b.x + 3, b.y + 14 - ph, 10, ph);
                g.setColor(Art.mix(col, Color.WHITE, 0.5)); g.fillRect(b.x + 4, b.y + 14 - ph, 8, 1);
                if (b.only >= 0) {
                    g.drawImage(Art.gem(b.only), b.x + 3, b.y + 1, null);
                }
                if (b.timed > 0 && b.t > 0) {
                    int bw = (int) (14 * b.t / (b.timed * 60.0));
                    g.setColor(c(0x3b2033)); g.fillRect(b.x + 1, b.y + 6, 14, 3);
                    g.setColor(c(0xffe36e)); g.fillRect(b.x + 1, b.y + 7, bw, 1);
                } else if (b.timed > 0) {
                    PixelFont.draw(g, "" + b.timed, b.x + 6, b.y + 4, c(0x3b2033));
                }
            } else {
                g.setColor(c(0x3b2033)); g.fillRect(b.x + 1, b.y, 14, 2);
                g.setColor(col); g.fillRect(b.x + 3, b.y + 2, 10, ph);
            }
        } else if (e instanceof Ents.Lever) {
            Ents.Lever l = (Ents.Lever) e;
            int bx = l.x + 8, by = l.y + 15;
            g.setColor(c(0x3b2033)); g.fillRect(l.x + 3, l.y + 12, 10, 4);
            g.setColor(c(0x8e7aa8)); g.fillRect(l.x + 4, l.y + 13, 8, 2);
            int dx = l.on ? 1 : -1;
            g.setColor(c(0x3b2033));
            for (int k = 0; k < 8; k++) g.fillRect(bx + dx * k / 2 - 1, by - 3 - k, 2, 1);
            g.setColor(c(w.chanColor[Math.max(0, l.ch)]));
            g.fillOval(bx + dx * 4 - 3, by - 14, 6, 6);
            g.setColor(Color.WHITE); g.fillRect(bx + dx * 4 - 1, by - 13, 1, 1);
        } else if (e instanceof Ents.Fan) {
            Ents.Fan f = (Ents.Fan) e;
            for (int k = 0; k < f.w; k += TS) {
                int x = f.x + k, y = f.y;
                g.setColor(c(0x3b2033)); g.fillRect(x, y, TS, TS);
                g.setColor(f.ch >= 0 ? c(w.chanColor[f.ch]) : c(0xb9a6e0));
                g.fillRect(x + 1, y + 1, TS - 2, TS - 2);
                g.setColor(c(0x5b4a7a)); g.fillRect(x + 2, y + 2, TS - 4, 5);
                int a = f.on ? (int) (t % 4) : 0;
                g.setColor(Color.WHITE);
                for (int b = 0; b < 3; b++) g.fillRect(x + 3 + ((b * 4 + a) % 10), y + 3, 2, 3);
            }
        } else if (e instanceof Ents.Portal) {
            Ents.Portal p = (Ents.Portal) e;
            int fi = (int) (t % 42), ci = Math.floorMod(p.id, 6);
            BufferedImage im = PORTAL[ci][fi];
            if (im == null) {
                im = new BufferedImage(18, 18, BufferedImage.TYPE_INT_ARGB);
                Graphics2D ig = im.createGraphics();
                int cx = 9, cy = 9;
                for (int k = 0; k < 6; k++) {
                    double ang = fi * 0.15 + k * Math.PI / 3;
                    ig.setColor(c(Levels.RAINBOW[k]));
                    ig.fillRect(cx + (int) (Math.cos(ang) * 6) - 1, cy + (int) (Math.sin(ang) * 7) - 1, 3, 3);
                }
                ig.setColor(new Color(40, 20, 70, 200));
                ig.fillOval(cx - 4, cy - 5, 8, 10);
                ig.setColor(c(Levels.RAINBOW[ci]));
                ig.fillRect(cx - 1, cy - 1, 2, 2);
                ig.dispose();
                PORTAL[ci][fi] = im;
            }
            g.drawImage(im, p.x - 1, p.y - 1, null);
        } else if (e instanceof Ents.Orb) {
            Ents.Orb o = (Ents.Orb) e;
            int bob = (int) Math.round(Math.sin(t * 0.1 + o.x) * 1.5);
            g.setColor(new Color(201, 160, 255, 90)); g.fillOval(o.x - 2, o.y - 2 + bob, 16, 16);
            g.setColor(c(0x7e5bd6)); g.fillOval(o.x, o.y + bob, 12, 12);
            g.setColor(c(0xc9a0ff)); g.fillOval(o.x + 2, o.y + 2 + bob, 8, 8);
            PixelFont.draw(g, (t / 30) % 2 == 0 ? "↑" : "↓", o.x + 3, o.y + 2 + bob, Color.WHITE);
        } else if (e instanceof Ents.Lantern) {
            Ents.Lantern l = (Ents.Lantern) e;
            g.setColor(c(0x3b2033)); g.fillRect(l.x + 4, l.y + 6, 2, 10);
            g.fillRect(l.x + 1, l.y + 15, 8, 1);
            g.setColor(c(0x3b2033)); g.fillRect(l.x + 1, l.y, 8, 8);
            g.setColor(l.lit ? c(0xffe36e) : c(0x8e8aa8)); g.fillRect(l.x + 2, l.y + 1, 6, 6);
            if (l.lit) { g.setColor(Color.WHITE); g.fillRect(l.x + 3, l.y + 2, 2, 2); }
        } else if (e instanceof Ents.Gem) {
            Ents.Gem gm = (Ents.Gem) e;
            if (gm.got) return;
            int bob = (int) Math.round(Math.sin(t * 0.08 + gm.x * 0.3) * 1.5);
            g.drawImage(Art.gem(gm.kind), gm.x, gm.y + bob, null);
            if ((t + gm.x) % 50 < 6) { g.setColor(Color.WHITE); g.fillRect(gm.x + 7, gm.y + bob, 1, 3); g.fillRect(gm.x + 6, gm.y + 1 + bob, 3, 1); }
        } else if (e instanceof Ents.Door) {
            drawDoor(g, (Ents.Door) e, t);
        }
    }

    private void drawDoor(Graphics2D g, Ents.Door d, long t) {
        Color main = d.kind == Art.MIMI ? c(0xff8fb4) : c(0xc98a55);
        Color trim = d.kind == Art.MIMI ? c(0xe0577f) : c(0x7fe0c4);
        int x = d.x, y = d.y;
        if (d.occupied || w.phase >= World.DOORS) {
            g.setColor(new Color(255, 255, 200, 70 + (int) (Math.sin(t * 0.2) * 30)));
            g.fillRect(x - 3, y - 3, 22, 38);
        }
        g.setColor(c(0x3b2033));
        g.fillRect(x, y + 3, 16, 29); g.fillRect(x + 2, y + 1, 12, 2); g.fillRect(x + 4, y, 8, 1);
        g.setColor(trim);
        g.fillRect(x + 1, y + 4, 14, 28); g.fillRect(x + 3, y + 2, 10, 2);
        // interior (escuro) visivel quando abre
        g.setColor(c(0x2a1b2e));
        g.fillRect(x + 3, y + 5, 10, 27);
        int open = Math.min(16, d.open) * 27 / 16;
        if (open < 27) {
            g.setColor(main);
            g.fillRect(x + 3, y + 5, 10, 27 - open);
            g.setColor(Art.mix(main, Color.WHITE, 0.4));
            g.fillRect(x + 3, y + 5, 10, 1);
            if (27 - open > 14) {
                g.drawImage(Art.gem(d.kind), x + 4, y + 8, null);
                g.setColor(c(0xffe36e)); g.fillRect(x + 11, y + 20, 1, 2);
            }
        }
        if (d.occupied && w.phase == World.PLAY) {
            int by = (int) (Math.sin(t * 0.25) * 2);
            PixelFont.draw(g, "↓", x + 6, y - 10 + by, Color.WHITE);
        }
    }

    private void drawBox(Graphics2D g, int x, int y) {
        g.setColor(c(0x3b2033)); g.fillRect(x, y + 2, 16, 14);
        g.setColor(c(0x7fd8e6)); g.fillRect(x + 1, y + 3, 14, 12);
        g.setColor(c(0xb8f0f5)); g.fillRect(x + 1, y + 3, 14, 2);
        g.setColor(c(0xff6f9f)); g.fillRect(x + 7, y + 3, 2, 12); g.fillRect(x + 1, y + 8, 14, 2);
        g.setColor(c(0x3b2033)); g.fillRect(x + 4, y, 3, 3); g.fillRect(x + 9, y, 3, 3);
        g.setColor(c(0xff6f9f)); g.fillRect(x + 5, y + 1, 2, 2); g.fillRect(x + 9, y + 1, 2, 2);
    }

    /** Desenha o jogador (ou o balaozinho de emoji) na posicao interpolada. */
    private void withPlayerAt(Graphics2D g, World.Player p, long t, boolean emote) {
        int ox = p.x, oy = p.y;
        float fx = lerp(p.px, p.x), fy = lerp(p.py, p.y);
        p.x = (int) Math.floor(fx); p.y = (int) Math.floor(fy);
        double dx = fx - p.x, dy = fy - p.y;
        g.translate(dx, dy);
        try {
            if (emote) drawEmote(g, p, t); else drawPlayer(g, p, t);
        } finally {
            g.translate(-dx, -dy);
            p.x = ox; p.y = oy;
        }
    }

    private void drawPlayer(Graphics2D g, World.Player p, long t) {
        if (!p.alive) return;
        if (w.phase == World.DOORS && w.phaseT > 20) return;
        boolean flip = p.g < 0;
        int sx = p.x - 3, sy = flip ? p.y : p.y - 2;
        BufferedImage img = Art.frame(p.ch, p.facingLeft, Math.max(0, Math.min(4, p.anim)));
        // sombrinha
        if (p.onGround && !flip) {
            g.drawImage(SHADOW, p.x, p.y + p.h - 1, null);
        }
        Art.draw(g, img, sx, sy, 1, flip);
        if (p.ch == localChar && w.time < 240 && w.phase == World.PLAY) {
            int ay = flip ? p.y + p.h + 4 : p.y - 12 + (int) (Math.sin(t * 0.2) * 2);
            PixelFont.centeredOutlined(g, "VOCÊ", p.x + 5, ay - 8, Color.WHITE, c(0x3b2033), 1);
        }
    }

    private void drawEmote(Graphics2D g, World.Player p, long t) {
        if (!p.alive || p.emoteT <= 0 || p.emote <= 0) return;
        String[] ic = {"", "♥", "!", "?", "★"};
        int[] colr = {0, 0xff4f8a, 0xff9a3c, 0x5a8bff, 0xffc83d};
        int e = Math.min(4, p.emote);
        int x = p.x + p.w / 2 - 6, y = (p.g > 0 ? p.y - 15 : p.y + p.h + 3);
        if (p.emoteT > 140) y += (p.emoteT - 140) / 3;
        Art.panel(g, x, y, 13, 11, Color.WHITE, c(0x3b2033));
        g.setColor(Color.WHITE);
        g.fillRect(x + 5, y + 11, 3, 1);
        g.setColor(c(0x3b2033));
        g.fillRect(x + 5, y + 11, 1, 1); g.fillRect(x + 7, y + 11, 1, 1); g.fillRect(x + 6, y + 12, 1, 1);
        PixelFont.draw(g, ic[e], x + 4, y + 2, c(colr[e]));
    }

    private void drawParticles(Graphics2D g) {
        for (World.Particle p : w.particles) {
            int a = Math.max(0, Math.min(255, 255 * p.life / Math.max(1, p.max) + 40));
            g.setColor(new Color(p.color >> 16 & 255, p.color >> 8 & 255, p.color & 255, Math.min(255, a)));
            int x = Math.round(p.x + p.vx * a), y = Math.round(p.y + p.vy * a);
            if (p.kind == World.P_HEARTS) {
                g.fillRect(x, y, 1, 1); g.fillRect(x + 2, y, 1, 1); g.fillRect(x, y + 1, 3, 1); g.fillRect(x + 1, y + 2, 1, 1);
            } else if (p.kind == World.P_PUFF0 || p.kind == World.P_PUFF1) {
                int s = p.life > p.max / 2 ? 3 : 2;
                g.fillRect(x, y, s, s);
            } else g.fillRect(x, y, p.life > 10 ? 2 : 1, p.life > 10 ? 2 : 1);
        }
    }

    // =================================================================== escuridao
    private int[] darkPix;
    private static final int DARK_RGB = 0x08061a;
    private static final int[] DARK_BANDS = {18, 34, 64, 121};

    /** Escuridao calculada direto nos pixels (sem formas nem composicao: leve em qualquer PC). */
    private void drawDark(Graphics2D g, long t) {
        if (darkImg == null) {
            darkImg = new BufferedImage(Main.W, Main.H, BufferedImage.TYPE_INT_ARGB);
            darkPix = ((java.awt.image.DataBufferInt) darkImg.getRaster().getDataBuffer()).getData();
        }
        java.util.Arrays.fill(darkPix, (228 << 24) | DARK_RGB);
        for (World.Player p : w.players)
            if (p.alive) light(Math.round(lerp(p.px, p.x)) + p.w / 2, Math.round(lerp(p.py, p.y)) + p.h / 2, 46 + (int) (Math.sin(t * 0.05) * 2));
        for (Ents.Lantern l : w.lanterns) light(l.x + 5, l.y + 4, l.lit ? 74 + (int) (Math.sin(t * 0.07 + l.x) * 3) : 10);
        for (Ents.Gem gm : w.gems) if (!gm.got) light(gm.x + 5, gm.y + 5, 9);
        for (Ents.Door dr : w.doors) light(dr.x + 8, dr.y + 16, 16);
        for (Ents.Ent e : w.ents) if (e instanceof Ents.Button || e instanceof Ents.Lever) light(e.x + 8, e.y + 12, 8);
        g.drawImage(darkImg, 0, 0, null);
    }

    private void light(int cx, int cy, int r) {
        int r2 = r * r;
        int y0 = Math.max(0, cy - r), y1 = Math.min(Main.H - 1, cy + r);
        int x0 = Math.max(0, cx - r), x1 = Math.min(Main.W - 1, cx + r);
        int b0 = (int) (r2 * 0.16f), b1 = (int) (r2 * 0.36f), b2 = (int) (r2 * 0.64f);
        for (int y = y0; y <= y1; y++) {
            int dy = y - cy, row = y * Main.W;
            for (int x = x0; x <= x1; x++) {
                int dx = x - cx, d2 = dx * dx + dy * dy;
                if (d2 >= r2) continue;
                int a = d2 < b0 ? DARK_BANDS[0] : d2 < b1 ? DARK_BANDS[1] : d2 < b2 ? DARK_BANDS[2] : DARK_BANDS[3];
                int i = row + x;
                if (a < (darkPix[i] >>> 24)) darkPix[i] = (a << 24) | DARK_RGB;
            }
        }
    }

    // =================================================================== HUD
    public void drawHud(Graphics2D g) {
        int got0 = 0, tot0 = 0, got1 = 0, tot1 = 0, got2 = 0, tot2 = 0;
        for (Ents.Gem gm : w.gems) {
            if (gm.kind == 0) { tot0++; if (gm.got) got0++; }
            else if (gm.kind == 1) { tot1++; if (gm.got) got1++; }
            else { tot2++; if (gm.got) got2++; }
        }
        String nm = (w.levelIndex + 1) + ". " + w.def.name;
        Art.panel(g, 4, 2, Math.max(150, PixelFont.width(nm) + 12), 13, new Color(255, 255, 255, 215), c(0x3b2033));
        PixelFont.draw(g, nm, 9, 5, c(0x5a2a4a));
        int secs = w.time / 60;
        String tm = String.format("%d:%02d", secs / 60, secs % 60);
        Art.panel(g, Main.W - 152, 2, 148, 13, new Color(255, 255, 255, 215), c(0x3b2033));
        int x = Main.W - 147;
        g.drawImage(Art.GEM_MIMI, x, 4, null);
        PixelFont.draw(g, got0 + "/" + tot0, x + 11, 5, c(0xd63d6b));
        x += 38;
        g.drawImage(Art.GEM_BIS, x, 4, null);
        PixelFont.draw(g, got1 + "/" + tot1, x + 11, 5, c(0x8e5a34));
        x += 38;
        if (tot2 > 0) {
            g.drawImage(Art.STAR, x, 4, null);
            PixelFont.draw(g, got2 + "/" + tot2, x + 11, 5, c(0xc99a1f));
        }
        x += 36;
        PixelFont.draw(g, tm, Main.W - 8 - PixelFont.width(tm), 5, w.time <= w.def.par * 60 ? c(0x3b8f5a) : c(0x8e7aa8));
    }
}

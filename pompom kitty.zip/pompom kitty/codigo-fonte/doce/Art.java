package doce;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

/** Sprites pixel art feitos a mao (strings) para a Mimi, o Biscoito e os itens. */
public final class Art {
    private Art() {}

    public static final int MIMI = 0, BISCOITO = 1;
    public static final String[] NAMES = {"Mimi", "Biscoito"};
    public static final String[] DESC = {
        "Gatinha de capuz de morango. Nada na geleia de morango sem medo!",
        "Ursinho de cachecol menta. Mergulha na calda de chocolate numa boa!"
    };
    public static final Color[] CHAR_COLOR = {new Color(0xff6f9f), new Color(0xc98a55)};
    public static final Color[] CHAR_LIGHT = {new Color(0xffd6e7), new Color(0xf6dfb8)};

    static final Map<Character, Integer> PAL = new HashMap<>();
    static {
        PAL.put('k', 0x3b2033); // contorno
        PAL.put('e', 0x2b1a2a); // olho
        PAL.put('h', 0xffffff); // brilho
        PAL.put('c', 0xff8fb4); // bochecha
        PAL.put('m', 0xa8344f); // boquinha
        // Mimi
        PAL.put('w', 0xffe3ee);
        PAL.put('p', 0xffb3d1);
        PAL.put('r', 0xe8455a);
        PAL.put('R', 0xb32c45);
        PAL.put('y', 0xffe36e);
        PAL.put('g', 0x7ad67a);
        PAL.put('G', 0x3f8f50);
        // Biscoito
        PAL.put('b', 0xc98a55);
        PAL.put('B', 0x8e5a34);
        PAL.put('u', 0xf6dfb8);
        PAL.put('n', 0x4a2b22);
        PAL.put('t', 0x7fe0c4);
        PAL.put('T', 0x45b39a);
        // itens
        PAL.put('o', 0xe8b46a);
        PAL.put('O', 0xb87a3c);
        PAL.put('Y', 0xffc83d);
        PAL.put('W', 0xfff6c8);
    }

    // ---------- Mimi (olhando para a direita) ----------
    private static final String[] MIMI_HEAD = {
        ".kk...kGGk...kk.",
        ".krk.kgggGk.krk.",
        ".krrkkkgGkkkrrk.",
        "krryrrrrrryrrrrk",
        "krrrrrrryrrrrrrk",
        "krryrwwwwwwwryrk",
        "krrwwwwwwwwwwrrk",
        "krwwweewwwweewrk",
        "krwwweewwwweewrk",
        "krwwccwwmmwccwrk",
        ".krwwwwwwwwwwrk.",
    };
    private static final String[] MIMI_BODY = {
        "..krrppppppprk..",
        ".krrppppppppprk.",
        "..kppppppppppk..",
    };
    // ---------- Biscoito ----------
    private static final String[] BIS_HEAD = {
        "..kkk......kkk..",
        ".kbBbk....kbBbk.",
        ".kbbbkkkkkkbbbk.",
        ".kbbbbbbbbbbbbk.",
        "kbbbbbbbbbbbbbbk",
        "kbbbbbbbbbbbbbbk",
        "kbbbbehbbbbehbbk",
        "kbbbbeebbbbeebbk",
        "kbbbcbuunnuubcbk",
        "kbbbbbuuuuuubbbk",
        ".kbbbbbuumuubbk.",
    };
    private static final String[] BIS_BODY = {
        "..kTtttttttttk..",
        ".kTtbbuuuuubbbk.",
        "..kTbbuuuuubbk..",
    };

    private static final String[][] FEET = {
        {"...kwwk..kwwk...", "...kkkk..kkkk..."}, // parado
        {"..kwwk....kwwk..", "..kkkk....kkkk.."}, // passo A
        {"....kwwkkwwk....", "....kkkkkkkk...."}, // passo B
        {"..kwwk....kwwk..", "..kkk......kkk.."}, // pulo
    };

    /** frames[personagem][direcao 0=dir 1=esq][frame]: 0 parado,1 piscando,2 passoA,3 passoB,4 pulo */
    private static final BufferedImage[][][] FRAMES = new BufferedImage[2][2][5];

    static {
        for (int ch = 0; ch < 2; ch++) {
            String[] head = ch == MIMI ? MIMI_HEAD : BIS_HEAD;
            String[] body = ch == MIMI ? MIMI_BODY : BIS_BODY;
            char foot = ch == MIMI ? 'w' : 'B';
            for (int f = 0; f < 5; f++) {
                String[] rows = new String[16];
                for (int i = 0; i < 11; i++) rows[i] = head[i];
                if (f == 1) { // piscar: apaga a linha de cima dos olhos
                    int er = ch == MIMI ? 7 : 6;
                    rows[er] = rows[er].replace('e', ch == MIMI ? 'w' : 'b').replace('h', ch == MIMI ? 'w' : 'b');
                }
                for (int i = 0; i < 3; i++) rows[11 + i] = body[i];
                int fi = f == 0 || f == 1 ? 0 : f == 2 ? 1 : f == 3 ? 2 : 3;
                rows[14] = FEET[fi][0].replace('w', foot);
                rows[15] = FEET[fi][1];
                if (f == 4) { // pulo: corpinho um pouco esticado
                    rows[13] = body[1];
                }
                BufferedImage r = sprite(rows);
                FRAMES[ch][0][f] = r;
                FRAMES[ch][1][f] = flipH(r);
            }
        }
    }

    public static BufferedImage frame(int ch, boolean left, int f) {
        return FRAMES[ch][left ? 1 : 0][f];
    }

    // ---------- Itens ----------
    static final BufferedImage GEM_MIMI = sprite(new String[]{
        "...gGg...",
        "..kGgGk..",
        ".krrrrrk.",
        "krryrryrk",
        "krrrrrrrk",
        "krwrryrrk",
        ".krrrrrk.",
        "..krrrk..",
        "...kkk...",
    });
    static final BufferedImage GEM_BIS = sprite(new String[]{
        "..kkkkk..",
        ".koonook.",
        "kooooonok",
        "konoooook",
        "koooonook",
        "kooooonOk",
        ".kOnooOk.",
        "..kkkkk..",
        ".........",
    });
    static final BufferedImage STAR = sprite(new String[]{
        "....k....",
        "...kYk...",
        "kkkYYYkkk",
        "kYYYWYYYk",
        ".kYYYYYk.",
        "..kYYYk..",
        ".kYYkYYk.",
        ".kYk.kYk.",
        ".kk...kk.",
    });

    public static BufferedImage gem(int kind) {
        return kind == 0 ? GEM_MIMI : kind == 1 ? GEM_BIS : STAR;
    }

    // ---------- Utilitarios ----------
    public static BufferedImage sprite(String[] rows) {
        int h = rows.length, w = rows[0].length();
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                char c = x < rows[y].length() ? rows[y].charAt(x) : '.';
                Integer col = PAL.get(c);
                if (col != null) img.setRGB(x, y, 0xff000000 | col);
            }
        return img;
    }

    public static BufferedImage flipH(BufferedImage s) {
        BufferedImage r = new BufferedImage(s.getWidth(), s.getHeight(), BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < s.getHeight(); y++)
            for (int x = 0; x < s.getWidth(); x++)
                r.setRGB(s.getWidth() - 1 - x, y, s.getRGB(x, y));
        return r;
    }

    /** Desenha um sprite com escala inteira e opcionalmente de cabeca para baixo. */
    public static void draw(Graphics2D g, BufferedImage img, int x, int y, int sc, boolean flipV) {
        int w = img.getWidth() * sc, h = img.getHeight() * sc;
        if (flipV) g.drawImage(img, x, y + h, x + w, y, 0, 0, img.getWidth(), img.getHeight(), null);
        else g.drawImage(img, x, y, w, h, null);
    }

    /** Silhueta branca (usada no brilho de escolha / dano). */
    public static BufferedImage silhouette(BufferedImage s, int rgb) {
        BufferedImage r = new BufferedImage(s.getWidth(), s.getHeight(), BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < s.getHeight(); y++)
            for (int x = 0; x < s.getWidth(); x++)
                if ((s.getRGB(x, y) >>> 24) != 0) r.setRGB(x, y, 0xff000000 | rgb);
        return r;
    }

    public static Image icon() {
        BufferedImage img = new BufferedImage(32, 32, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.drawImage(frame(MIMI, false, 0), 0, 0, 32, 32, null);
        g.dispose();
        return img;
    }

    public static Color mix(Color a, Color b, double t) {
        t = Math.max(0, Math.min(1, t));
        return new Color(
            (int) (a.getRed() + (b.getRed() - a.getRed()) * t),
            (int) (a.getGreen() + (b.getGreen() - a.getGreen()) * t),
            (int) (a.getBlue() + (b.getBlue() - a.getBlue()) * t));
    }

    public static Color alpha(Color c, int a) {
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, Math.min(255, a)));
    }

    /** Caixinha arredondada estilo "balao" de UI. */
    private static final Map<String, BufferedImage> PANELS = new HashMap<>();

    /** Caixinha arredondada estilo "balao" de UI (guardada como imagem pronta). */
    public static void panel(Graphics2D g, int x, int y, int w, int h, Color fill, Color border) {
        if (w <= 0 || h <= 0) return;
        String key = w + "x" + h + ":" + fill.getRGB() + ":" + border.getRGB();
        BufferedImage im = PANELS.get(key);
        if (im == null) {
            im = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
            Graphics2D ig = im.createGraphics();
            ig.setComposite(AlphaComposite.Src);
            panelRaw(ig, 0, 0, w, h, fill, border);
            ig.dispose();
            if (PANELS.size() > 300) PANELS.clear();
            PANELS.put(key, im);
        }
        g.drawImage(im, x, y, null);
    }

    private static void panelRaw(Graphics2D g, int x, int y, int w, int h, Color fill, Color border) {
        g.setColor(border);
        g.fillRect(x + 2, y, w - 4, h);
        g.fillRect(x, y + 2, w, h - 4);
        g.fillRect(x + 1, y + 1, w - 2, h - 2);
        g.setColor(fill);
        g.fillRect(x + 2, y + 1, w - 4, h - 2);
        g.fillRect(x + 1, y + 2, w - 2, h - 4);
        g.setColor(alpha(Color.WHITE, 70));
        g.fillRect(x + 3, y + 2, w - 6, 1);
    }

    /** Coracao 7x6 para UI. */
    public static void heart(Graphics2D g, int x, int y, Color c, int sc) {
        PixelFont.draw(g, "♥", x, y, c, sc);
    }
}
